// Display popup
const showDialogBtn = document.getElementById("imagetoggle");
showDialogBtn.addEventListener("click", () => {
  alert(
    "You must agree to external data transfer and cookie placement to view this video."
  );
});

// Toggle video display
const gCheckbox = document.getElementById("gCheckbox");
gCheckbox.addEventListener("change", function () {
  let imageContainer = document.getElementById("imagetoggle");
  let videoContainer = document.getElementById("videoContainer");

  if (gCheckbox.checked) {
    imageContainer.style.display = "none";
    const iframe = document.getElementById("iframetoggle");
    iframe.src = "https://www.youtube-nocookie.com/embed/jA5wbygIJN8";
    videoContainer.style.display = "block";
  } else {
    const iframe = document.getElementById("iframetoggle");
    iframe.src = "";
    videoContainer.style.display = "none";
    imageContainer.style.display = "block";
  }
});

// Toggle display text
function displayT() {
  let dText = document.getElementById("displayText");
  let btnText = document.getElementById("btn01");
  let displayValue = window.getComputedStyle(dText).display;

  if (displayValue === "none") {
    dText.style.display = "inline";
    btnText.innerHTML = "Read less";
  } else {
    dText.style.display = "none";
    btnText.innerHTML = "Read more";
  }
}
