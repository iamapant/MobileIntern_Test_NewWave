# Product history

Below you can find the complete product history of the HERE SDK, including all past changelog updates up to the latest release. The latest changelog for your edition is also available [here](https://www.here.com/docs/bundle/sdk-for-android-explore-edition-changelog/page/README.html) - or it can be found offline as part of the [HERE SDK package](https://platform.here.com/portal/sdk).

## Deprecations and beta versions

The team behind the HERE SDK is continuously reviewing and improving available APIs to provide both flexibility and ease of use, alongside consistent interfaces.

To ensure stable APIs across releases, we adhere to a deprecation process. Deprecated APIs are maintained for two major versions starting from the subsequent major release after their deprecation is announced in our changelog. This typically spans a period of six to nine months. You can always check the API Reference to see which versions are affected and when an interface was marked as deprecated.

Some of our new and potentially unstable APIs are designated as "beta" in our API Reference. Beta releases do not follow a deprecation process unless otherwise specified. If you choose to use beta APIs, please note that they may contain bugs and exhibit unexpected behaviors.

We value your feedback and are always interested in hearing suggestions for further improvements.

## History of changelog updates

HERE SDK {{book.hsdkVersion}} is a stable release. This is our most recent release. We usually release updates twice per month.

Below you can find all changes since the initial release.

### Version 4.23.5.0

#### Known Issues

- Map view: Modifying rendering features like ambient occlusion or shadows can trigger an OpenGL driver crash on emulators with Android 13 or later. <!-- HERESDK-4794 -->  

## Changes from Previous Releases

This section documents major changes from past releases. We encourage you to use the latest release, {{book.hsdkVersion}}.
  
### Version 4.23.4.0

#### Resolved Issues

- Offline routing: Fixed a defect where the `OfflineRoutingEngine` would ignore highway sections when using `VehicleSpecification` in offline mode. This behavior occurred only when `VehicleSpecification` was not `null`. Highway sections are now considered in the same way as with the online `RoutingEngine`. <!-- HERESUP-35464 -->
- Map view: Fixed unexpected high CPU usage when enabling `MapFeatures.TRAFFIC_FLOW` on devices with a single core, regardless of the number of available cores. Note that this issue started to appear in HERE SDK 4.22.5.0. <!-- HERESUP-34087 -->
- Offline routing: Fixed missing road shield icons when calculating an offline route. <!-- HERESDK-7689 -->

#### Known Issues

- Map view: Modifying rendering features like ambient occlusion or shadows can trigger an OpenGL driver crash on emulators with Android 13 or later. <!-- HERESDK-4794 -->  
  
### Version 4.23.3.0

#### New Features

- Routing: Added `RoutingOptions` to `IsolineOptions`. `RoutingOptions` can now be used with the `IsolineRoutingEngine`. <!-- HERESDK-8197 -->
- Map view: Starting with HERE Style Editor v1.13.0, only zipped archives (`.tar.gz`) are exported. These archives include POI categories and the JSON style files. When loading a custom style using `MapScene.loadScene(...)`, the HERE SDK supports specifying a path to a JSON file, as before, but it also allows to set a `configurationFile` pointing to the zipped archive. <!-- HERESDK-7166 -->

#### API Changes - Breaking

- EV Routing: The default value of `ElectricVehicleOptions.batterySpecifications` was changed to `null`. The field is now nullable. Note that this is a **beta** release of this feature. <!-- HERESDK-8197 -->

#### Resolved Issues

- Routing: Fixed `TaskHandle` to correctly return `FINISHED` when route calculation completes and `CANCELLED` when it’s cancelled for routing, isoline, and traffic. <!-- HERESDK-7772 -->
- Fixed a regression in data usage statistics for positioning introduced in HERE SDK 4.22.5. Previously, positioning subcategories were combined into a single value; now, `positioning` and `serviceImprovement` subcategories are correctly reported separately again. <!-- POSTI-4570 -->

#### Known Issues

- Map view: Modifying rendering features like ambient occlusion or shadows can trigger an OpenGL driver crash on emulators with Android 13 or later. <!-- HERESDK-4794 -->
- Map view: Enabling `MapFeatures.TRAFFIC_FLOW` may cause unexpected high CPU usage on devices with a single core, regardless of the number of available cores. <!-- HERESUP-34087 -->  
  
### Version 4.23.2.0

#### New Features

- Routing: Added `ViolatedRestriction.Details.maxNumberOfTires`, and `VehicleSpecification.tiresCount` to store maximum permitted number of tires. Note that this feature is also supported by the `OfflineRoutingEngine`, if available for your edition. <!-- HERESDK-8230 -->
- Routing: Added `AvoidanceOptions.zoneCategories`, `AvoidanceOptions.zoneIds` and `AvoidanceOptions.exceptZoneIds` options for isoline calculation. <!-- HERESUP-29704 -->
- Added `TruckSpecifications.currentWeightInKilograms` field to indicate the current weight of the vehicle. <!-- HERESDK-5816 -->

#### Known Issues

- Map view: Modifying rendering features like ambient occlusion or shadows can trigger an OpenGL driver crash on emulators with Android 13 or later. <!-- HERESDK-4794 -->  
  
### Version 4.23.1.0

#### New Features

- Map style update: Enriched the POI display on the map by implementing new icons for various POI categories which previously used generic iconography. <!-- CARTO-768 -->
- Search: Added `PlaceCategory.SIGHTS_LANDMARK_ATTRACTION` to use instead of `PlaceCategory.SIGHTS_LANDMARK_ATTACTION` that contains a typo. Note that this is also supported for the `OfflineSearchEngine` (if available for your license). <!-- HERESDK-8047 -->
- Map view: Improved support for transparent custom line layers to avoid darker colors when objects overlap. Added `TranslucentMapLayerGroup` class and `MapLayerPriorityBuilder.inGroup()` function to support placing custom line layers into a translucent layer group. Custom line layers within a translucent group are rendered in an offscreen translucent pass, preventing self-overlapping translucent geometry from being alpha blended. Note that this is a **beta** release of this feature. <!-- HERESDK-6208 -->

#### API Changes - Breaking

- Map view: The default zoom-level to storage-level mapping has changed: the offset is now -3 instead of -1 for all layer types, except for raster layers, which can be created using the `MapLayerBuilder` API. `MapPolyline.DashImageRepresentation` map measure support has been updated to a new range of [3–19], replacing the previous range of [1–20]. <!-- HERESDK-7816 -->
- Removed the previously deprecated `LayerConfiguration.Feature.TRAFFIC`. Please use `LayerConfiguration.Feature.RDS_TRAFFIC` instead. <!-- HERESDK-5196 -->
- Removed the previously deprecated `SDKOptions.accessKeyId` and `SDKOptions.accessKeySecret`. Please use `SDKOptions.authenticationMode` instead. <!-- HERESDK-5664 -->

#### API Changes - Deprecations

- Search: Deprecated `PlaceCategory.SIGHTS_LANDMARK_ATTACTION` that contains a typo. Please use `PlaceCategory.SIGHTS_LANDMARK_ATTRACTION` instead. <!-- HERESDK-8047 -->

#### Known Issues

- Map view: Modifying rendering features like ambient occlusion or shadows can trigger an OpenGL driver crash on emulators with Android 13 or later. <!-- HERESDK-4794 -->  
  
### Version 4.23.0.0

#### New Features

- Documentation: Since the _Explore Edition_ is a subset of the _Navigate Edition_, we plan to merge the developer guides for both into a single developer guide. Features such as HERE Positioning, Navigation, Indoor Maps, and offline capabilities will remain exclusive to Navigate users. Editions will be referenced to as "licenses". Your existing Explore and Navigate credentials will continue to work as before, and we will continue to maintain support for both licenses through dedicated frameworks and API references. This change is planned for an upcoming release and will only affect the documentation. <!-- TW-2423 -->
- Map view: Removed the **beta** label for `MapPolyline.setRepresentaion()`. The API is now considered to be stable. <!-- HERESDK-7692 -->
- Search: Added `EVChargingPool.access` that represents the accessibility level of the charging pool. Also available offline for Navigate users. <!-- HERESDK-7174 -->
- Search: Added `EVAccessRestrictionReason` that represents the restriction reason of an `EVChargingPool`. Added `EVChargingPool.accessRestrictionReasons` that contains the list of reasons for restriction, accessible by offline search when `access` is `EVAccessType.RESTRICTED_ACCESS`. <!-- HERESDK-7644 -->

#### API Changes - Breaking

- Map view: Removed deprecated enum value `MapMeasure.Kind.DISTANCE`. Please use `MapMeasure.Kind.DISTANCE_IN_METERS` instead. <!-- HERESDK-6671 -->
- Routing: Removed deprecated `sdk.routing.Toll.tollSystem`. Please use `sdk.routing.Toll.tollSystems` instead. <!-- HERESDK-4477 -->
- Search: Removed deprecated APIs: `EVChargingPoolDetails.paymentIsRequired`, `EVChargingPoolDetails.subscriptionIsRequired`, and `EVChargingStation` constructor with 12 parameters. Please use the default constructor instead. <!-- HERESDK-6529 -->
- Routing: Removed the previously deprecated `com.here.sdk.routing.Waypoint.isChargingStation` field. Please use `chargingStop` field instead. <!-- HERESDK-5165 -->
- Search: Removed deprecated APIs in `SearchEngine` and `OfflineSearchEngine`: `search(TextQuery, SearchOptions, SearchCallback)` – please use `searchByText` instead; `search(AddressQuery, SearchOptions, SearchCallback)` – please use `searchByAddress` instead; `search(CategoryQuery, SearchOptions, SearchCallback)` – please use `searchByCategory` instead; `search(GeoCoordinates, SearchOptions, SearchCallback)` – please use `searchByCoordinates` instead; `searchPickedPlace(PickedPlace, LanguageCode, PlaceIdSearchCallback)` – please use `searchByPickedPlace` instead; `search(PlaceIdQuery, LanguageCode, PlaceIdSearchCallback)` – please use `searchByPlaceId` instead; `suggest(TextQuery, SearchOptions, SuggestCallback)` – please use `suggestByText` instead. <!-- HERESDK-6529 -->
- Routing: Removed the previously deprecated `com.here.sdk.routing.RouteOptions.occupantsNumber` field. Please use `occupantsNumber` in corresponding transport mode options instead. <!-- HERESDK-4790 -->
- Map view: Renamed `BUILDING_3D_MODELS` to `ADVANCED_BUILDINGS` in the `MapFeatures` class. Renamed `BUILDING_3D_MODELS_GRAYSCALE` to `ADVANCED_BUILDINGS_GRAYSCALE`, `BUILDING_3D_MODELS_TEXTURED` to `ADVANCED_BUILDINGS_TEXTURED`, and `BUILDING_3D_MODELS_TEXTURELESS` to `ADVANCED_BUILDINGS_TEXTURELESS` in the `MapFeatureModes` class. <!-- HERESDK-7601 -->

#### API Changes - Deprecations

- The following countries have been deprecated from the CountryCode enum: `ALA`, `ATF`, `BVT`, `GGY`, `HMD`, `JEY`, `UMI`. Please use `FIN`, `FRA`, `NOR`, `GBR`, `AUS`, `GBR`, and `USA` respectively instead. <!-- HERESDK-6802 -->
- Routing: Deprecated `EVMobilityServiceProviderPreferences.excluded`. Please use other pereferences levels of `EVMobilityServiceProviderPreferences`. <!-- HERESDK-7254 -->

#### Resolved Issues

- Routing: Fixed an issue with `returnToRoute()` that may happen when using `AvoidanceOptions` options to avoid corridors, bounding boxes or polygons. <!-- HERESUP-20669 -->

#### Known Issues

- Map view: Modifying rendering features like ambient occlusion or shadows can trigger an OpenGL driver crash on emulators with Android 13 or later. <!-- HERESDK-4794 -->  
  
### Version 4.22.5.0

#### New Features

- Routing: Added `dispose()` method to `RoutingInterface` and `TransitRoutingEngine` to allow proper resources cleanup, including canceling pending requests and shutting down the background worker thread, helping to avoid potential (though unlikely) crashes due to deadlocks. <!-- HERESDK-6733 -->

#### Known Issues

- Map view: Modifying rendering features like ambient occlusion or shadows can trigger an OpenGL driver crash on emulators with Android 13 or later. <!-- HERESDK-4794 -->  
  
### Version 4.22.4.0

#### New Features

- Routing: Added support for `Waypoint.currentWeightChangeInKilograms` for changing the current weight of the vehicle at waypoints. For example, this can be used when the vehicle takes additional cargo or unloads its cargo along the route. Note that this is also supported offline for the users of _Navigate Edition_. <!-- HERESDK-6687 -->

#### Known Issues

- Map view: Modifying rendering features like ambient occlusion or shadows can trigger an OpenGL driver crash on emulators with Android 13 or later. <!-- HERESDK-4794 -->  
  
### Version 4.22.3.0

#### New Features

- Routing: Added new APIs to better support Electric Light Commercial Vehicles (eLCVs) and various types of trucks, such as light trucks under 7.5 tons. Extended the `RoutingEngine` and `OfflineRoutingEngine` to accept the new `RoutingOptions` class, which consolidates several existing option classes - including `CarOptions`, `TaxiOptions`, `TruckOptions`, and `RefreshRouteOptions` - into a unified configuration model. While the existing `RouteOptions` class can still be used as before, `RoutingOptions` provides the same capabilities in a more generic structure suitable for all supported transport modes. When creating a new route, make sure to specify `RoutingOptions.transportMode`. The new class also introduces extended routing configurations via the new classes `CommonRouteOptions`, `VehicleSpecification`,  `ElectricVehicleOptions` with the new `EmpiricalConsumptionModel` and `PhysicalConsumptionModel`, and `TransportedCargo`. For example, it is now possible to specify whether a car is carrying cargo. Previously, this was only available for trucks. The existing `RouteOptions` can now be set under `CommonRouteOptions`. Note that this is a **beta** release of the new feature. Also, the `OfflineRoutingEngine` is only available in the _Navigate Edition_. <!-- HERESDK-6725 -->
- Removed the **beta** label from the `horizontalAccuracyInMeters` field of `MapMatchedLocation`. The API is now considered to be stable. <!-- HERESDK-5750 -->
- Map style update: Added improved pedestrian and walkway path styling by adjusting color and width to enhance visual clarity. Note that this feature was already introduced with HERE SDK 4.21.4.0. <!-- CARTO-417 -->
- Map style update: Updated walkway and pedestrian road styles to ensure appropriate visibility at zoomed-out levels. Note that this feature was already introduced with HERE SDK 4.22.2.0. <!-- CARTO-715 -->
- Search for EV charging stations: The APIs `EVChargingPool`, `Details.evChargingPool`, `EVChargingStation`, `EMobilityServiceProvider`, `EVChargingPool.eMobilityServiceProviders`, `EVChargingPool.cpoId`, and `EVChargingPool.evseInfo` are now available to all customers and work with your standard credentials. Previously, these APIs were available only to our closed alpha group. Note that these APIs are also supported for the `OfflineRoutingEngine`, if available for your edition. <!-- HERESDK-7028 -->

#### Known Issues

- Map view: While changing rendering related map features like ambient occlusion and shadows, a crash in OpenGL driver happens on emulator running Android 13 or newer. <!-- HERESDK-4794 -->  
  
### Version 4.22.2.0

#### New Features

- Search: Added `PassThroughFeature` enum with `ONLINE_SEARCH` value. Enabling of this passthrough feature allows usage of online search in offline mode. <!-- HERESDK-6527 -->
- Map view: Added support for changing font in `MapMarker`. Added constructor to `MapMarker.TextStyle` with font name parameter and a new `getFontName()` method. <!-- HERESDK-5620 -->
- Map style update: Added pedestrian path styling by removing dash patterns and improving visual clarity. Reviewed unpaved walkway relevance within driving-related use cases to ensure appropriate representation. Note that this feature was already introduced with the HERE SDK 4.21.4.0. <!-- CARTO-417 -->
- Routing: Added `BatterySpecifications.maxPowerAtLowVoltageInKilowatts` to allow vehicles which support 800V to use lower voltage charging stations. <!-- HERESDK-6391 -->

#### Resolved Issues

- Fixed the mapping between certain HTTP client status codes and the corresponding SDK error messages. <!-- HERESDK-6210 -->

#### Known Issues

- Map view: While changing rendering related map features like ambient occlusion and shadows, a crash in OpenGL driver happens on emulator running Android 13 or newer. <!-- HERESDK-4794 -->  
  
### Version 4.22.1.0

#### New Features

- Map view: Added gradient support for `MapPolyline` with adjustable length progress. Transition between `MapPolyline.lineColor` and `MapPolyline.progressColor` now renders gradually. The length of that transition can be specified and queried with `MapPolyline.setProgressGradientLength` and `MapPolyline.getProgressGradientLength` specified in zoom-level dependent pixels. <!-- HERESDK-6220 -->

#### API Changes - Breaking

- Map style update: Removed the Microhood city labels from the map display because they cluttered the map and exist in just a few countries. <!-- CARTO-679 -->

#### Resolved Issues

- Search: Fixed the behavior of `Place.deserialize` to handle missing enum `PlaceType`. If the `PlaceType` is missing in the serialized data, it is now set to `PlaceType.UNKNOWN` in the deserialized object. These features are also supported for the `OfflineSearchEngine`, if available for your edition. <!-- HERESDK-6636 -->
- Map view: Fixed the behavior of `MapLayer.setPriority()` to correctly remove any previously applied priorities before applying new ones. Fixed internal behaviour of `MapLayerPriorityBuilder` and the resulting `MapLayerPriority` when a layer (category) is defined more than once with `MapLayerPriorityBuilder`.
Previously, when chaining priorities, only in the case of two consecutive priority definitions for the same layer (category), the first one was overriden. Now, any previously defined priority in the chain for the same layer (category) is overriden. <!-- HERESDK-6131 -->

#### Known Issues

- Map view: While changing rendering related map features like ambient occlusion and shadows, a crash in OpenGL driver happens on emulator running Android 13 or newer. <!-- HERESDK-4794 -->  
  
### Version 4.22.0.0

#### New Features

- Added `AssetsManager` to register custom and fallback fonts. Once registered, the font name can be used in the SVG `text` tag as the `font-family` attribute when creating a `MapImage` with `ImageFormat.SVG`. <!-- HERESDK-5619 -->
- Search: Filters in `PlaceFilter.EV` are now available to all customers, not just members of the closed alpha group. Note that this feature is also supported by the `OfflineSearchEngine`, if available for your edition. <!-- HERESDK-6243 -->
- Map view: Added gradient support for `MapPolyline` with progress to customize route-eat-up during turn-by-turn navigation. The transition between `MapPolyline.lineColor` and `MapPolyline.progressColor` can now be rendered gradually. The length of this transition can be set and retrieved using `MapPolyline.setProgressGradientLength` and `MapPolyline.getProgressGradientLength`, specified in zoom-level-dependent pixels. <!-- HERESDK-6220 -->

#### API Changes - Breaking

- Map view: Removed the previously deprecated constructor for `MapLayerMapMeasureDependentStorageLevels`. Use `MapLayerMapMeasureDependentStorageLevels.withStorageLevelOffset()` method to create `MapLayerMapMeasureDependentStorageLevels` instances instead. <!-- HERESDK-4649 -->
- Search: The **beta** property `POIPaymentDetails.acceptedCashCurrencies` is now nullable. If cash is not an accepted payment method, or if the list of accepted currencies is unavailable, this property will be set to `null`. <!-- HERESDK-6243 -->
- Map view: Removed the previously deprecated `MapViewBase.PickMapItemsCallback` and `MapViewBase.PickMapContentCallback`. Use `pick()` instead. <!-- HERESDK-5132 -->
- Routing: Removed the previously deprecated `TrafficSpeed` class. Use `DynamicSpeedInfo` instead. <!-- HERESDK-4486 -->
- Removed the previously deprecated property `SDKOptions.customEngineBaseUrls`. Use `SDKOptions.customEngineOptions` instead. <!-- HERESDK-4143 -->
- Routing: Removed the previously deprecated `AvoidanceOptions` property `avoidBoundingBoxAreas`. Use `avoidBoundingBoxAreasOptions` instead. Removed the previously deprecated `avoidPolygonAreas`. Use `avoidPolygonAreasOptions` instead. <!-- HERESDK-3798 -->

#### API Changes - Deprecations

- Search: Deprecated `WebImage.publicationDate`. Date information is no longer available for images. <!-- HERESDK-6243 -->

#### Resolved Issues

- Routing: Fixed a bug that caused missing consumption values in `TrafficOnSpan` for EV routes. <!-- HERESDK-6367 -->

#### Known Issues

- Map view: While changing rendering related map features like ambient occlusion and shadows, a crash in OpenGL driver happens on emulator running Android 13 or newer. <!-- HERESDK-4794 -->  

### Version 4.21.5.0

#### New Features

- Search: Extended search details: Added `WebImage.publicationDate` that contains the photo publication date. It is meant to replace `WebImage.date`. These features are also supported for the `OfflineSearchEngine`, if available for your edition. <!-- HERESDK-6253 -->
- Search: Added enum values `SearchError.QUERY_EMPTY`, `SearchError.INVALID_AREA`, `SearchError.FILTER_EMPTY`, `SearchError.INVALID_CORRIDOR_POLYLINE`, `SearchError.INVALID_URL`, `SearchError.INVALID_CUSTOM_OPTION_FORMAT`, `SearchError.INVALID_TRUCK_CLASS`, `SearchError.BAD_REQUEST`. These features are also supported for the `OfflineSearchEngine`, if available for your edition. <!-- HERESDK-5688 -->
- Added a `NameID` data type to represent name-id pairs. <!-- HERESUP-10514 -->
- Routing: Added the following properties to `ChargingStation`: `brand` to include the brand name and ID of a charging station, `chargePointOperator` to include the name and ID of the charging point operator, and `matchingEMobilityServiceProviders` to list the matched E-Mobility service providers. <!-- HERESUP-10514 -->
- Routing: Added support for all categories of `AvoidanceOptions.zoneCategory` and `AvoidanceOptions.zoneIds`. These features are also supported for the `OfflineRoutingEngine`, if available for your edition. <!-- HERESDK-6091 -->
- Added `SDKNativeEngine.getDeviceId(...)` to get the unique identifier assigned to the device for an application. This device ID is primarily used for tracking Monthly Active Users (MAUs). If a device has a different device ID within the same month, it is counted as a separate MAU. However, if the device ID changes across different months, it still contributes to the same overall MAU count. Note that MAUs are only counted depending on your contract. <!-- HERESDK-4708 -->

#### API Changes - Deprecations

- Search: Deprecated `WebImage.date`. Please use `WebImage.publicationDate` instead. <!-- HERESDK-6253 -->
- Search: Deprecated enum value `SearchError.INVALID_PARAMETER`. Use the other dedicated errors instead. <!-- HERESDK-5688 -->

#### Resolved Issues

- Routing: Fixed route calculation requests by ensuring departure or arrival time is included even when traffic is disabled. These times can still influence the route, as road accessibility may vary depending on the time of day. <!-- HERESDK-6120 -->
- Map view: Fixed a crash that happens when using multiple off-screen textures on PowerVR Rogue GPUs on Android platform. With these changes, `MapFeature.AMBIENT_OCCLUSION` and `MapFeature.SHADOWS` will be prohibited, even if there is a request to enable them. `MapFeature.CONGESTION_ZONES`, `MapFeature.ENVIRONMENTAL_ZONES`, `MapFeature.LOW_SPEED_ZONES` and roads in `MapScheme.HYBRID_DAY`, `MapScheme.HYBRID_NIGHT`, `MapScheme.LITE_HYBRID_DAY`, `MapScheme.LITE_HYBRID_NIGHT`, `MapScheme.LOGISTICS_HYBRID_DAY`, `MapScheme.LOGISTICS_HYBRID_NIGHT` will be displayed with overlapping geometry. Furthermore, `MapFeature.TERRAIN` with `MapFeatureModes.TERRAIN_3D` will be automatically switched to `MapFeatureModes.TERRAIN_HILLSHADE`. <!-- HERESUP-1790 -->

#### Known Issues

- Map view: While changing rendering related map features like ambient occlusion and shadows, a crash in OpenGL driver happens on emulator running Android 13 or newer. <!-- HERESDK-4794 -->  

### Version 4.21.4.0

#### New Features

- When the application detects increased memory pressure, you can call the `SDKNativeEngine.purgeMemoryCaches(...)` method to clear the HERE SDK's in-memory caches and reduce its memory footprint. Note that calling this method may temporarily impact performance. Currently, only `PurgeMemoryStrategy.FULL` is supported, which clears all cached content without preserving any data. <!-- HERESDK-5800 -->
- If an application runs in a memory-constrained environment, enable `SDKOptions.lowMemoryMode` to reduce the HERE SDK's memory footprint. When set to `true` this configures the internal memory caches to consume less memory. Note that enabling the low memory mode may also reduce the performance of the HERE SDK. <!-- HERESDK-5800 -->

#### Resolved Issues

- Map view: After losing internet connection and then reconnecting, some roads on the map now render correctly and no parts of the map will appear incomplete. <!-- HERESUP-6405 -->

#### Known Issues

- Map view: While changing rendering related map features like ambient occlusion and shadows, a crash in OpenGL driver happens on emulator running Android 13 or newer. <!-- HERESDK-4794 -->  

### Version 4.21.3.0

#### New Features

- Routing: Removed the **beta** label from taxi related methods, fields and enum items. The following APIs are now considered to be stable: `routingEngine.calculateTaxiRoute(...)`, `routingEngine.importTaxiRoute(...)` `routingEngine.importTaxiRouteWithStops(...)`, `SectionTransportMode.TAXI`, `TaxiOptions` and  `taxiOptions.allowDriveThroughTaxiRoads`. <!-- HERESDK-5780 -->
- Map view: Added `MapArrow.setVisibilityRanges(List<MapMeasureRange>)` and `MapArrow.getVisibilityRanges()` methods. These methods allow controlling the visibility of map arrows based on zoom levels by specifying a list of zoom level ranges. When the list is empty (default), the map arrows are visible at all zoom levels. <!-- HERESDK-5732 -->
- Routing: Added attribute `lastCharacterOfLicensePlate` to the following transport mode options: `CarOptions`, `EVCarOptions`, `BusOptions`, `PrivateBusOptions`, `TruckOptions`, `EVTruckOptions`, `ScooterOptions` and `TaxiOptions`. <!-- HERESDK-5613 -->

#### API Changes - Breaking

- Map view: Removed parameterless custom scale style expression `["pixel-world-scale"]`. Use instead `["pixel-world-scale", <number_expression>]`. Note that this is still a **beta** API. <!-- HERESDK-3922 -->

#### API Changes - Deprecations

- Deprecated `BusSpecifications.lastCharacterOfLicensePlate`. Use instead `BusOptions.lastCharacterOfLicensePlate`. <!-- HERE-5050 -->

#### Resolved Issues

- Map view: When multiple `MapView` instances are used in multiple activities across a single application, then no longer memory leak occurs when the first `Activity` that used a `MapView` finishes. <!-- HERESUP-10568 -->
- Fixed a crash for devices running Android 10 or lower due to faulty clock settings used in the internal network layer. <!-- HERESUP-9402 -->

#### Known Issues

- Map view: While changing rendering related map features like ambient occlusion and shadows, a crash in OpenGL driver happens on emulator running Android 13 or newer. <!-- HERESDK-4794 -->
- Map view: After losing internet connection and then reconnecting, some roads on the map may fail to render correctly, causing parts of the map to appear incomplete. <!-- HERESUP-6405 -->  

### Version 4.21.2.0

#### New Features

- Search: Added enum 'CurrentType' that represents the type of electric current (AC or DC). Added `PlaceFilter.Ev.currentType` filter to retrieve EV charging stations by the current type. <!-- HERESDK-1607 -->
- Map view: Added `TileGeoBoundsCalculator` API that allows users to compute the geodetic bounds of tiles for supported `TilingScheme`. Note that this is a **beta** release of this feature. <!-- HERESDK-4774 -->
- Routing: Removed the beta label from `fromDefaultParameterConfiguration()` method of `TransitRouteOptions`. It is now considered to be stable. <!-- HERESDK-1098 -->
- Routing: Removed the beta label from `optimizeWaypointsOrder` field of `RouteOptions`. It is now considered to be stable. <!-- HERESDK-1098 -->
- Routing: Removed the beta label from `TrafficOnSpan`, `TrafficOnSection`, and `TrafficOnRoute` classes. They are now considered to be stable. <!-- HERESDK-1098 -->
- Map style update: Enriched the POI display on the map by implementing additional icons for various POI categories which previously used a more generic iconography. <!-- CARTO-428 -->
- Routing: Removed the beta label from `returnToRoute()` method of `RoutingInterface`. It is now considered to be stable. <!-- HERESDK-1098 -->
- Routing: Removed the beta label from `fromDefaultParameterConfiguration()` and `walkSpeedInMetersPerSecond` field of `PedestrianOptions`. They are now considered to be stable. <!-- HERESDK-1098 -->
- Introduced the `PolylineSimplifier` component to reduce the complexity of long `GeoPolyline` objects. This helps minimize their size and decrease rendering effort, improving performance. <!-- HERESUP-5719 -->
- Routing: Removed the beta label from `PaymentMethod` enum. It is now considered to be stable. <!-- HERESDK-1098 -->
- Routing: Removed the beta label from `RouteHandle` class. It is now considered to be stable. <!-- HERESDK-1098 -->

#### Resolved Issues

- Routing: Fixed a bug where EV car routes would never use High-Occupancy Vehicle (HOV) lanes, even when permitted. <!-- HERESDK-5667 -->

#### Known Issues

- Map view: When multiple `MapView` instances are used in multiple activities across a single application, then a memory leak occurs when the first `Activity` that used a `MapView` finishes. <!-- HERESUP-10568 -->
- Map view: While changing rendering related map features like ambient occlusion and shadows, a crash in OpenGL driver happens on emulator running Android 13 or newer. <!-- HERESDK-4794 -->
- Map view: After losing internet connection and then reconnecting, some roads on the map may fail to render correctly, causing parts of the map to appear incomplete. <!-- HERESUP-6405 -->  

### Version 4.21.1.0

#### New Features

- Routing: Added `ViolatedRestriction.Details.maxWeight`. Added `VehicleRestrictionMaxWeight` to store the max permitted weight along with the weight restrictions type. <!-- HERESUP-6108 -->
- Map view: Added enum value `MapMeasure.Kind.DISTANCE_IN_METERS` to highlight the unit. This replaces the deprecated `MapMeasure.Kind.DISTANCE`. <!-- HERESDK-2152 -->
- Added `EngineBaseURL.ISOLINE_ROUTING_ENGINE` enum value to allow to provide a custom URL for use with the `IsolineRoutingEngine`. <!-- HERESUP-8583 -->
- Routing: Added `section.getNoThroughRestrictions()` which indicates an area allowed to enter only for residents or when vehicles make a stop. Added the related `span.getNoThroughRestrictionIndexes()`. <!-- HERESUP-6108 -->
- Routing: The `RoutingEngine` has been improved to use the `zstd` encoding when initiating requests to reduce the size of responses. <!-- HERESDK-1934 -->
- Map style update: Added a dedicated set of truck restriction icons to support all hybrid `MapScheme` styles. <!-- CARTO-418 -->
- Traffic: Added `additionalPolylines` field to `TrafficLocation` class. Traffic API v7 response data may contain a set of smaller polylines rather than a continuous polyline. The current HSDK implementation doesn't take that into account and treats the data as one contiguous polyline, which can lead to visual bugs when displaying a polyline on the map. A new `additionalPolylines` field has been introduced to store all `GeoPolyline` objects after the first gap between links. <!-- HERESUP-4954 -->

#### API Changes - Breaking

- Map style update: Enabled the diplay of POI categories that have previously not been visible on the map including the following main categories: business-services-areas; leisure-outdoor; medical POIs within the emergency category; all shopping categories. The change also includes a promotion of car parking POIs from start zoom level 18 to 17. <!-- CARTO-316 -->

#### API Changes - Deprecations

- Map view: Deprecated enum value `MapMeasure.Kind.DISTANCE`. Use `MapMeasure.Kind.DISTANCE_IN_METERS` instead. <!-- HERESDK-2152 -->
- Routing: Deprecated the attributes `Section.evDetails` and `Route.evDetails`. Use `Section.consumptionInKilowattHours` and `Route.consumptionInKilowattHours` instead. <!-- HERESDK-4431 -->
- Routing: Deprecated `maxGrossWeightInKilograms`. Use instead `maxWeight`. <!-- HERESUP-6108 -->

#### Resolved Issues

- Traffic: `TrafficEngine`: Polylines for traffic flow and incidents are now always provided as expected. Note that this issue occurred only in South Korea. <!-- HERESUP-4954 -->
- Search: Fixed an issue related to EV charging stations for `SearchEngine.searchByPickedPlace()` and `SearchEngine.searchPickedPlace(). <!-- HERESDK-5563 -->
- The global offline switch `sdkNativeEngine.isOfflineMode()` does now load map tiles after enabling the online mode again _or_ after restoring a lost network connection. <!-- OAM-1797 -->

#### Known Issues

- Map view: While changing rendering related map features like ambient occlusion and shadows, a crash in OpenGL driver happens on emulator running Android 13 or newer. <!-- HERESDK-4794 -->
- Map view: After losing internet connection and then reconnecting, some roads on the map may fail to render correctly, causing parts of the map to appear incomplete. <!-- HERESUP-6405 -->  

### Version 4.21.0.0

#### New Features

- Removed the beta tag from `SDKOptions.authenticationMode` as the API is now considered to be stable. <!-- HERESDK-5478 -->
- Search: Added attribute `id` to `EVChargingPool`, which represents a HERE ID of the charging pool. Added attributes to `Evse`: - `cpoId`, which represents the unique ID of an EVSE in the system of the CPO - `cpoEvseEmi3Id`, which represents identifier in Emi3 format of the EVSE within the Charge Point Operator (CPO) platform - `status`, which represents status of the EVSE such as `AVAILABLE`, `OCCUPIED` etc - `lastUpdated`, which represents the last update time of the dynamic connector availability information - `connectors`, which represents the list of connectors of the EVSE. <!-- HERESDK-4980 -->
- A `dataPath` field was added to `SDKOptions` which allows the HERE SDK to store data for internal use. Such data includes: offline search indices, positioning content, usage data information. More information can be found in the API Reference. <!-- HERESDK-1925 -->
- Map view: Added `PolygonTileDataSource` and `PolygonTileSource` APIs to allow users to inject custom polygon tile sources into the HERE SDK. Note that this is a `beta` release of this feature. <!-- HERESDK-438 -->
- Routing: Added `Waypoint.chargingStop`, allowing a waypoint to be designated as a charging stop. <!-- HERESDK-5142 -->

#### API Changes - Breaking

- Added support for 16 KB page sizes. Affected architectures are `x86_64` and `arm64-v8a`. In addition, the Android `compileSdk` and `targetSdkVersion` have been raised from 34 to 35. This change is backward compatible with older and current devices. To test your app in new environment, follow the [Android documentation](https://developer.android.com/guide/practices/page-sizes#16kb-emulator). <!-- HERESDK-4510 -->
- Map view: Changed behaviour of `PanListener` and `PinchRotateListener`. Pan gesture is now cancelled when pinch-rotate gesture starts. If two finger panning is detected during pinch-rotate, then pan gesture is started and both pan and pinch-rotate events are emitted. When pinch-rotate gesture finishes, then pan gesture (if in progress), also finishes. <!-- HERESDK-4845 -->
- Removed the previously deprecated `TimeRule.asString`. Use `TimeRule.timeRuleString` instead. <!-- HERESDK-5149 -->

#### API Changes - Deprecations

- Routing: Deprecated the attribute `Waypoint.isChargingStation`. Use `Waypoint.chargingStop` instead. <!-- HERESDK-5142 -->
- Deprecated the fields `accessKeyId`, `accessKeySecret` and other related constructors. Use instead the static methods offered by `AuthenticationMode`, which are now preferred when initializing `SDKOptions` and the HERE SDK. Take a look at the "HelloMap" example app on GitHub for a usage example. <!-- HERESDK-1464 -->

#### Resolved Issues

- Map view: Some customers see a "Failed to cache texture" error message in their logs. This message can be ignored. We switched the log level for texture caching failures from `ERROR` to `DEBUG` since such a caching failure doesn't affect the expected usage of a texture, for example, when being used with the `MapImage` class. <!-- HERESUP-4724 -->
- Map view: Changed behavior of `TwoFingerPanListener`. Now, we detect a two-finger-pan gesture only after a vertical movement of at least 5 mm. Previously, it was detected already after 1.5 mm which led to accidental detections of two-finger-pan gestures for some cases. <!-- HERESDK-5111 -->
- Routing: Fixed a potential ANR that could occur when destroying the `RoutingEngine` while tasks were still pending. <!-- HERESDK-4553 -->
- Map view: Fixed an issue with the pinch-rotate gesture where unintended map translation occurred during rotation in certain scenarios, ensuring consistent behavior. <!-- HERESDK-4845 -->
- MapView: Fixed `mapView.takeScreenshot()` to avoid interfering with the map renderer when called frequently, for example, during camera animations. <!-- HERESUP-3320 -->

#### Known Issues

- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again _or_ after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `TrafficEngine`: Polylines for traffic flow and incidents are not always provided as expected, sometimes polylines may be missing. <!-- HERESUP-4954 -->
- Map view: After losing internet connection and then reconnecting, some roads on the map may fail to render correctly, causing parts of the map to appear incomplete. <!-- HERESUP-6405 -->  

### Version 4.20.5.0

#### New Features

- Search: Added new attributes to `EVChargingStation` to provide more detailed connector information:
- `occupiedConnectorCount`: Number of connectors currently in use.
- `outOfServiceConnectorCount`: Number of connectors out of service.
-`reservedConnectorCount`: Number of connectors reserved.
- `lastUpdated`: Timestamp of the last update for `availableConnectorCount` and `occupiedConnectorCount`. <!-- HERESDK-4980 -->

#### API Changes - Breaking

- MapView: Updated method `LocationIndicator.setHaloColor(Color)` and `LocationIndicator.getHaloColor()` to `void LocationIndicator.setHaloColor(LocationIndicator.IndicatorStyle, Color)` and `Color LocationIndicator.getHaloColor(LocationIndicator.IndicatorStyle)`. Now, the accuracy indicator halo color of the `LocationIndicator` can be configured to specify the applicable `LocationIndicator.IndicatorStyle`. Note that this is a **beta** release of this feature. <!-- HERESDK-2354 -->

#### API Changes - Deprecations

- Deprecated `paymentIsRequired` and `subscriptionIsRequired` fields from `EVChargingPoolDetails`. Current values are always set to false. <!-- HERESDK-4549 -->
- `LayerConfiguration.Feature.TRAFFIC` has been deprecated and will be removed in v4.23.0. Please use `LayerConfiguration.Feature.RDS_TRAFFIC` instead. <!-- HERESDK-4653 -->

#### Resolved Issues

- Routing: Fixed incorrect route parsing when tolls are enabled. The problem occurred when the name of the toll systems are not available when calculating a route with tolls. <!-- HERESUP-5912 -->

#### Known Issues

- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again _or_ after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->  

### Version 4.20.4.0

#### New Features

- Map view: Added `LineTileDataSource` and `LineTileSource` APIs to allow users to inject custom line tile sources. Note that this is a **beta** release of this feature. <!-- HERESDK-4384 -->

#### API Changes - Deprecations

- Search: Deprecated `EVChargingStation` constructor with 12 parameters. Use the default constructor instead. <!-- HERESDK-4803 -->

#### Known Issues

- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again _or_ after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->  

### Version 4.20.3.0

#### New Features

- Search: Added `BUSINESS_AND_SERVICES_PETROL_GASOLINE_STATION` constant to class `PlaceCategory`. It represents businesses that sell fuel, oil, and other motoring supplies. <!-- HERESDK-4658 -->
- EV Routing: Added `EVMobilityServiceProviderPreferences` that represents sets of E-Mobility Service Providers' ID grouped by preference level. Added new field `EVCarOptions.evMobilityServiceProviderPreferences`. <!-- HERESDK-4574 -->
- Added `GeoPolygon([GeoBox] geoBox)` and `GeoPolyline([GeoBox] geoBox)` to construct a `GeoPolygon` or a `GeoPolyline` from a `GeoBox`. <!-- HERESDK-2718 -->
- Routing: Moved attribute `occupantsNumber` from `RouteOptions` to the corresponding transport mode options instead. It is added to the following transport mode options: `CarOptions`, `EVCarOptions`, `BusOptions`, `PrivateBusOptions`, `TruckOptions`, `EVTruckOptions`, `ScooterOptions`. <!-- HERESUP-367 -->
- EV Routing: Added `Waypoint.isChargingStation()` so that a waypoint added by an app needs to be used as a stop at a charging station, even if battery specifications indicate a stop is not required. <!-- HERESDK-4699 -->
- Map view: Added `locationIndicator.setHaloColor()` and `locationIndicator.getHaloColor()` to configure the color of the accuracy halo for the active `LocationIndicator.IndicatorStyle` setting. Note that this is a **beta** release of this feature. <!-- HERESDK-2354 -->
- Routing: Added `AllowOptions` class to the following transport mode options: `CarOptions`, `EVCarOptions`, `BusOptions`, `PrivateBusOptions`, `TruckOptions`, `EVTruckOptions`. It contains options that need to be explicitly allowed by a user. <!-- HERESUP-367 -->

#### API Changes - Deprecations

- Routing: Deprecated `RouteOptions.occupantsNumber`. Use `occupantsNumber` of the corresponding transport mode options instead, like `CarOptions.occupants_number`. <!-- HERESUP-367 -->

#### Resolved Issues

- Map view: Fixed memory leak on hybrid map schemes. Rendering to an offscreen texture causes a memory leak on ARM Mali Android devices with driver versions 32-38. The problem is on the GPU driver side in the memory allocator and related to AFBC (ARM Frame Buffer Compression) that needs to be disabled. <!-- HERESUP-2042 -->

#### Known Issues

- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again _or_ after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- Map view: `MapViewPin` instances do not disappear after tilting and panning the map far away. The pins still show up above the horizon. <!-- HERESDK-2102 -->  

### Version 4.20.2.0

#### New Features

- Map view: Added `MapFeature::AMBIENT_OCCLUSION` with `MapFeatureMode::AMBIENT_OCCLUSION_ALL` to enable/disable an ambient occlusion (AO) effect. This enhances the realism of a rendered 3D map scene by adding subtle shadows in areas where objects meet or where surfaces are close together. Currently, AO may result in a crash when switching to custom raster layers. Note that this is a beta release of this feature. <!-- HERESDK-3983 -->
- Map view: Added support to show multiple truck restriction icons per road segment. Note that this is a beta release of this feature. <!-- HERESDK-4372 -->
- Traffic: Added `TrafficQueryError.INVALID_IN`, `TrafficQueryError.INVALID_PARAMETER` and `TrafficQueryError.INTERNAL_ERROR`. Note that this is a beta release of this feature. <!-- HERESDK-3585 -->
- Map view: Added `PointTileDataSource` and `PointTileSource` APIs to allow users to inject custom point tile sources into the HERE SDK. A possible use case is to add a large amount of custom data, for example, adding multiple charging stations to the map. A usage example is shown in the "CustomPointTileSource" example app. Note that this is a beta release of this feature. <!-- HERESDK-4364 -->

#### API Changes - Breaking

- Traffic: Renamed `TrafficQueryError.INVALID_INCIDENT_ID` to `TrafficQueryError.INVALID_INCIDENT`. Note that this is a beta release of this feature. <!-- HERESDK-3585 -->

#### API Changes - Deprecations

- Routing: Deprecated the attribute `Toll.tollSystem`. Use the new attribute `Toll.tollSystems` instead. Note that this change was already included in HERE SDK 4.20.1.0. <!-- HERESDK-4347 -->

#### Resolved Issues

- Routing: Fixed incorrect routing when both max speed on segments and avoid segments are not empty when requesting a route. When both were set, only the former was being used. <!-- HERESUP-2314 -->
- Routing: Fixed next road numbers selection giving priority to those from signpost. <!-- HERESUP-1471 -->

#### Known Issues

- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again _or_ after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- Map view: `MapViewPin` instances do not disappear after tilting and panning the map far away. The pins still show up above the horizon. <!-- HERESDK-2102 -->  

### Version 4.20.1.0

#### New Features

- Routing: Added overload for `RoutingEngine.calculateTrafficOnRoute()` to calculate traffic also for EV car routes. Additionally, `consumptionInKilowattHours` field has been added to `TrafficOnSpan` that indicates the power consumption in kilowatt-hours (kWh) necessary to traverse the span. Also, `departurePlace` and `arrivalPlace` have been added to `TrafficOnSection` containing, among other properties, the estimated battery charge in kWh when leaving/arriving to a section. <!-- HERESDK-4231 -->
- Map view: Added `MapLayerMapMeasureDependentStorageLevels.withStorageLevelOffset()` method to create `MapLayerMapMeasureDependentStorageLevels` instances.  Updated the documentation for `MapLayerBuilder.withMapMeasureDependentStorageLevels()` method to clarify that the default mapping will now use a storage level that is one level lower than the corresponding map measure. <!-- HERESUP-543 -->
- Map view: Removed beta status for `MapMeasureDependentRenderSize`, representing a render size, described as map measure dependent values. The feature is now considered to be stable and any future changes will follow a strict deprecation process. <!-- HERESDK-3518 -->
- Routing: Added `Toll.tollSystems` to replace the deprecated `Toll.tollSystem`. <!-- HERESDK-4347 -->

#### API Changes - Breaking

- Map view: Improved gesture detection: Gesture types 'GestureType.Pan' and 'GestureType.PinchRotate' can now be detected simultaneously when using two fingers. <!-- HERESDK-4528 -->
- The minimum supported Android API level was raised from Android 23 to Android 24. <!-- HERESDK-4434 -->

#### API Changes - Deprecations

- Map view: Deprecated constructor for `MapLayerMapMeasureDependentStorageLevels`. Use `MapLayerMapMeasureDependentStorageLevels.withStorageLevelOffset()` method to create `MapLayerMapMeasureDependentStorageLevels` instances instead. <!-- HERESUP-543 -->

#### Known Issues

- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again _or_ after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- Map view: `MapViewPin` instances do not disappear after tilting and panning the map far away. The pins still show up above the horizon. <!-- HERESDK-2102 -->  

### Version 4.20.0.0

#### New Features

- Routing: Added `calculateJamFactor()` method to `com.here.sdk.routing.DynamicSpeedInfo` class. <!-- HERESDK-3696 -->
- Map view: Added `Style.update(Style)` and `HereMap.getStyle()` that supports the customization of predefined map styles. All `MapScheme` styles are supported. The new style definition `General.Labels.Scale.Factor` is made available to control the size of labels on the map. Note that this is a beta release of this feature. <!-- HERESDK-3578 -->

#### API Changes - Breaking

- Search: Removed the previously deprecated `CategoryQuery` constructor that takes only `GeoCorridor`. Please use the constructor that also accepts the coordinates. Removed SearchError.POLYLINE_TOO_LONG, as the HERE SDK resolves too long polyline issues by itself. <!-- HERESDK-2001 -->
- **Upcoming breaking change**: The minimum supported Android API version is planned to be raised from API 23 - Android 6 (Marshmallow) to API 24 - Android 7 (Nougat) with HERE SDK 4.20.1.0. <!-- ESD-123 -->
- Routing: Deprecated `RoutingEngine.calculateIsoline()`. Please use the `IsolineRoutingEngine` instead. <!-- HERESDK-3315 -->

#### API Changes - Deprecations

- Routing: Deprecated `com.here.sdk.routing.TrafficSpeed` class, please use `com.here.sdk.routing.DynamicSpeedInfo` class instead. Deprecated `getTrafficSpeed()` method in `com.here.sdk.routing.Span` class, please use `getDynamicSpeedInfo()` method instead. <!-- HERESDK-3696 -->
- Routing: Removed already deprecated `UNKNOWN` from `RoadType`. `UNKNOWN` was never returned and `null` is used instead in specific cases. <!-- HERESDK-4346 -->

#### Resolved Issues

- Map view: Fixed the rendering of SVG icons on the map when an SVG contains a `<m>` tag. <!-- HERESDK-4046 -->

#### Known Issues

- The _API Reference_ you can find on [here.com/docs](https://www.here.com/docs/category/here-sdk) is currently not formatted as expected. Please try to use instead the _API Reference_ we ship as part of the downloadable _release package_ you can find [here](https://platform.here.com/portal/sdk). <!-- TECHDOCS-3586 -->
- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again _or_ after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- Map view: `MapViewPin` instances do not disappear after tilting and panning the map far away. The pins still show up above the horizon. <!-- HERESDK-2102 -->  

### Version 4.19.5.0

#### API Changes - Breaking

- **Upcoming breaking change**: The minimum supported Android API version will be raised from API 23 - Android 6 (Marshmallow) to API 24 - Android 7 (Nougat) with the next major release HERE SDK 4.20.0.0 which is planned for end of September 2024. <!-- ESD-123 -->

#### API Changes - Deprecations

- `SDKOptions.customEngineBaseUrls` has been deprecated in favour of `SDKOptions.customEngineOptions`. The new API allows setting a specific URL for online services as well as custom authentication parameters. <!-- HERESDK-3662 -->
- Search: Deprecated methods `SearchEngine.search(TextQuery, SearchOptions, SearchCallback)` and `OfflineSearchEngine.search(TextQuery, SearchOptions, SearchCallback)`. Please use `SearchInterface.searchByText` instead. Deprecated methods `SearchEngine.search(AddressQuery, SearchOptions, SearchCallback)` and `OfflineSearchEngine.search(AddressQuery, SearchOptions, SearchCallback)`. Please use `SearchInterface.searchByAddress` instead. Deprecated methods `SearchEngine.search(CategoryQuery, SearchOptions, SearchCallback)` and `OfflineSearchEngine.search(CategoryQuery, SearchOptions, SearchCallback)`. Please use `SearchInterface.searchByCategory` instead. Deprecated methods `SearchEngine.search(GeoCoordinates, SearchOptions, SearchCallback)` and `OfflineSearchEngine.search(GeoCoordinates, SearchOptions, SearchCallback)`. Please use `SearchInterface.searchByCoordinates` instead. Deprecated methods `SearchEngine.search(PlaceIdQuery, LanguageCode, PlaceIdSearchCallback)` and `OfflineSearchEngine.search(PlaceIdQuery, LanguageCode, PlaceIdSearchCallback)`. Please use `SearchInterface.searchByPlaceId` instead. Deprecated methods `SearchEngine.searchPickedPlace` and `OfflineSearchEngine.searchPickedPlace`. Please use `SearchInterface.searchByPickedPlace` instead. Deprecated methods `SearchEngine.suggest(TextQuery, SearchOptions, SuggestCallback)` and `OfflineSearchEngine.suggest(TextQuery, SearchOptions, SuggestCallback)`. Please use `SearchInterface.suggestByText` instead. Note that the `OfflineSearchEngine` is only supported by the _Navigate Edition_. <!-- HERESDK-3856 -->

#### Resolved Issues

- Routing: Fixed insecure deletion of resources to prevent possible crashes when shutting down the `RoutingEngine`. Now, the HERE SDK will wait until all routing requests will finish before destructing affected objects. <!-- HERESDK-3875 -->
- Routing: Fixed wrong turn orientation that happened when multiple streets on a junction go straight ahead. <!-- OLPSUP-30920 -->
- Routing: Added missing specification detail about corridor radius in `AvoidanceOptions`. In addition, the limit of segments in `AvoidanceOptions` has been updated to match the routing limits provided by the backend. Please consult the API Reference for more details. <!-- HERESDK-4098 -->

#### Known Issues

- The _API Reference_ you can find on [here.com/docs](https://www.here.com/docs/category/here-sdk) is currently not formatted as expected. Please try to use instead the _API Reference_ we ship as part of the downloadable _release package_ you can find [here](https://platform.here.com/portal/sdk). <!-- TECHDOCS-3586 -->
- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again _or_ after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- Map view: `MapViewPin` instances do not disappear after tilting and panning the map far away. The pins still show up above the horizon. <!-- HERESDK-2102 -->  

### Version 4.19.4.0

#### New Features

- Search: Added `PlaceFilter.EV.eMobilityServiceProviderPartnerIDs` filter to retrieve EV charging stations with at least one e-Mobility service provider from the given list. The feature is available as closed-alpha. Note that this feature was already added with HERE SDK 4.19.3.0. <!-- HERESDK-1885 -->
- Search: Added `EMobilityServiceProvider` that represents e-Mobility service provider. Added `EVChargingPool.eMobilityServiceProviders`. The feature is available as closed-alpha. Note that this feature was already added with HERE SDK 4.19.3.0. <!-- HERESDK-3552 -->

#### API Changes - Breaking

- **Upcoming breaking change**: The minimum supported Android API version will be raised from API 23 - Android 6 (Marshmallow) to API 24 - Android 7 (Nougat) with the next major release HERE SDK 4.20.0.0 which is planned for end of September 2024. <!-- ESD-123 -->

#### Known Issues

- The _API Reference_ you can find on [here.com/docs](https://www.here.com/docs/category/here-sdk) is currently not formatted as expected. Please try to use instead the _API Reference_ we ship as part of the downloadable _release package_ you can find [here](https://platform.here.com/portal/sdk). <!-- TECHDOCS-3586 -->
- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again _or_ after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- Map view: `MapViewPin` instances do not disappear after tilting and panning the map far away. The pins still show up above the horizon. <!-- HERESDK-2102 -->  

### Version 4.19.3.0

#### New Features

- Routing: Added properties `axleCount`, `trailerCount`, and `trailerAxleCount` to `CarSpecifications`. <!-- HERESDK-3753 -->
- Routing: Added field `avoidBoundingBoxAreasOptions` and `avoidPolygonAreasOptions` to avoid rectangular and polygon shaped area during route calculation including exceptions area (rectangular and polygon shaped) for this calculation. <!-- HERESDK-3678 -->
- Routing: Added the field `AvoidanceOptions.avoidCorridorAreasOptions` to avoid corridor-shaped areas during route calculation, including exception areas (rectangular, polygonal, and corridor-shaped) for this calculation. Added corridor shape as an exception area for the `AvoidanceOptions.avoidBoundingBoxAreasOptions` and `AvoidanceOptions.avoidPolygonAreasOptions` fields. Added support for exception areas for offline routing, if supported by your edition. <!-- HERESDK-3511 -->

#### API Changes - Breaking

- The upcoming major release of the HERE SDK 4.20.0.0, scheduled for the end of September 2024, will increase the minimum supported Android API version from API 23 (Android 6, Marshmallow) to API 24 (Android 7, Nougat). <!-- ESD-123 -->

#### API Changes - Deprecations

- Routing: Deprecated `avoidBoundingBoxAreas` and `avoidPolygonAreas`. Use `avoidBoundingBoxAreasOptions.avoidBoundingBoxArea` and `avoidPolygonAreasOptions.avoidPolygonArea` respectively instead. <!-- HERESDK-3678 -->

#### Known Issues

- The _API Reference_ you can find on [here.com/docs](https://www.here.com/docs/category/here-sdk) is currently not formatted as expected. Please try to use instead the _API Reference_ we ship as part of the downloadable _release package_ you can find [here](https://platform.here.com/portal/sdk). <!-- TECHDOCS-3586 -->
- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again _or_ after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- Map view: `MapViewPin` instances do not disappear after tilting and panning the map far away. The pins still show up above the horizon. <!-- HERESDK-2102 -->  

### Version 4.19.2.0

#### New Features

- Map style update: Increased road shield icon display density. Aligned start zoom level to show the icon. <!-- CARTO-432 -->
- Routing: Added property `TruckSpecifications.trailerAxleCount` for toll cost calculation. <!-- HERESDK-3653 -->
- Map view: Added `TileKey`, `TileSource` and `RasterTileSource` APIs to allow users to inject custom raster tile sources. Added `RasterDataSource` constructor over a raster tile source. This allows you to display custom raster tiles loaded from the local file system or from a custom backend hosting a format that does not need to be known by the HERE SDK. Find a usage example in the "CustomRasterTileSource" example app. Note that this is a beta release of this feature. <!-- HERESDK-587 -->
- Routing: Added `occupantsNumber` to `RouteOptions` for bus. <!-- HERESDK-3667 -->
- Routing: Added `transponders` property to `TollFare` to publish transponder names with toll cost. <!-- HERESDK-3701 -->

#### API Changes - Breaking

- Map view: Removed `UNINITIALIZED_LIGHTS` state from the enum `AttributeSettingError`. This change is due to the implementation of a solution that ensures the Light Source API becomes available immediately after the scene load is completed. Note that this is a beta release of this feature. <!-- HERESDK-3565 -->
- Map style update: Improved the map schemes `LITE_HYBRID_DAY` and `LITE_HYBRID_NIGHT` to enhance the readability of street labels, POI labels, ski run and chair lift labels, and exit billboard. For the enriched Japan map, also road facilities billboards, traffic intersection billboards and other Japan specific billboards have been improved. <!-- CARTO-466 -->
- **Upcoming breaking change**: The minimum supported Android API version will be raised from API 23 - Android 6 (Marshmallow) to API 24 - Android 7 (Nougat) with the next major release HERE SDK 4.20.0.0 which is planned for end of September 2024. <!-- ESD-123 -->

#### Resolved Issues

- Consolidated HTTP error codes into `BAD_REQUEST` and `INTERNAL_SERVER_ERROR` and output actual codes as error log. <!-- HERESDK-3415 -->
- Map style update: Improved readability of ferry lines and labels. <!-- CARTO-399 -->
- Map view: When using `MapFeatureModes.TERRAIN_3D` then some portions of the tiles may fail to load when a zoom operation is performed while tiles are still loading. <!-- HERESDK-3135 -->

#### Known Issues

- The _API Reference_ you can find on [here.com/docs](https://www.here.com/docs/category/here-sdk) is currently not formatted as expected. Please try to use instead the _API Reference_ we ship as part of the downloadable _release package_ you can find [here](https://platform.here.com/portal/sdk). <!-- TECHDOCS-3586 -->
- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again _or_ after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- Map view: `MapViewPin` instances do not disappear after tilting and panning the map far away. The pins still show up above the horizon. <!-- HERESDK-2102 -->  

### Version 4.19.1.0

#### New Features

- Map style update: Implemented additional icons for grocery, clothing and shoe shopping POIs. <!-- CARTO-324 -->
- Map view: Added an option to specify an offset for map measure storage level mapping. Added class `MapMeasureDependentStorageLevels`. Added method `MapLayerBuilder.withMapMeasureDependentStorageLevels()` which provides a mapping between a `MapLayer` map measure to datasource storage level. <!-- HERESDK-3445 -->
- Routing: Added `CarSpecifications` to specify vehicle dimensions for `CarOptions`, `EVCarOptions`, and `TaxiOptions`. <!-- HERESDK-3461 -->
- Map style update: Implemented Japan specific roadside station icon (michi-no-eki). <!-- CARTO-461 -->
- Map view: Added `MapFeatures.LOW_SPEED_ZONES` and `MapFeatureModes.LOW_SPEED_ZONES_ALL` to show areas with reduced speed limits. Only available for Japan currently. For users of the _Explore Edition_, this feature will be available automatically with the next map update. For the _Navigate Edition_, this feature is already available. <!-- HERESDK-2485 -->

#### API Changes - Breaking

- **Upcoming breaking change**: The minimum supported Android API version will be raised from API 23 - Android 6 (Marshmallow) to API 24 - Android 7 (Nougat) with the next major release HERE SDK 4.20.0.0 which is planned for end of September 2024.

#### Known Issues

- The _API Reference_ you can find on [here.com/docs](https://www.here.com/docs/category/here-sdk) is currently not formatted as expected. Please try to use instead the _API Reference_ we ship as part of the downloadable _release package_ you can find [here](https://platform.here.com/portal/sdk). <!-- TECHDOCS-3586 -->
- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again _or_ after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- Map view: `MapViewPin` instances do not disappear after tilting and panning the map far away. The pins still show up above the horizon. <!-- HERESDK-2102 -->
- Map view: When using `MapFeatureModes.TERRAIN_3D` then some portions of the tiles may fail to load when a zoom operation is performed while tiles are still loading. <!-- HERESDK-3135 -->  

### Version 4.19.0.0

#### New Features

- Map style update: Improved readability of map elements like city center and cartography labels by increasing size and applying stronger colors, also boundaries by styling brighter colors and darkening satellite imagery. <!-- CARTO-407 -->
- Routing: Added `textUsageOption` to `RouteTextOptions`. Defines whether street name, route number and signpost direction should be used when generating maneuver text. <!-- HERESDK-2896 -->
- Unit tests: Improved the mocking JAR library, which allows now to implement custom logic for constructors. By default, the constructor initializes each public field whose name matches the name of the constructor parameter. Check the _UnitTesting_ example app on [GitHub](https://github.com/heremaps/here-sdk-examples) for more details. <!-- HERESDK-2953 -->
- Map view: Added `MapScheme.LOGISTICS_HYBRID_DAY` and `MapScheme.LOGISTICS_HYBRID_NIGHT`, hybrid map schemes with focus on fleet management content. <!-- HERESDK-2032 -->
- Map view: `MapObjectDescriptor` moved from `com.here.sdk.mapview.mapobject` to `com.here.sdk.mapview` package. Removed beta label for: `MapViewBase.pick(MapScene.MapPickFilter, Rectangle2D, MapViewBase.MapPickCallback)`, `MapView.pick(MapScene.MapPickFilter, Rectangle2D, MapViewBase.MapPickCallback)`, `MapViewBase.MapPickCallback`, `MapScene.MapPickFilter`, `MapPickResult`, `MapObjectDescriptor`. <!-- HERESDK-2976 -->
- Map view: `MapMarker` now support the display of user supplied text along with an image. Added `MapMarker.TextStyle` and `MapMarker.TextStyle.Placement` to support the encapsulation and configuration of the visual properties of the text of a `MapMarker`. Added the following APIs to `MapMarker`: `MapMarker(@NonNull final GeoCoordinates coordinates, @NonNull final MapImage image, @NonNull final String text)`, `void setText(@NonNull final String text)`, `String getText()`, `void setTextStyle(@NonNull final MapMarker.TextStyle textStyle)`, `MapMarker.TextStyle getTextStyle()`. <!-- HERESDK-3069 -->
- Map view: It is now possible, to configure the 3D light settings in a `MapScene`. Added the following APIs: `MapScene.getLights()` to retrieve the MapSceneLights instance. `MapSceneLights.Category` enum defines the different categories of lights. `MapSceneLights.AttributeSettingError` enum to define attribute errors on light APIs. `MapSceneLights.Direction` class to specify a light direction. `MapSceneLights.AttributeSettingCallback` interface for handling errors on light APIs. `MapSceneLights.reset()` to reset the attributes of all lights to their default values. `MapSceneLights.setColor(Category, Color, AttributeSettingCallback)`, `MapSceneLights.setIntensity(Category, double, AttributeSettingCallback)`, `MapSceneLights.setDirection(Category, Direction, AttributeSettingCallback)` to set the light attributes. `MapSceneLights.getColor(Category)`, `MapSceneLights.getIntensity(Category)`, `MapSceneLights.getDirection(Category)` to retrieve the light attributes. Note that this is a beta release of this feature. <!-- HERESDK-2533 -->
- Map view: Added a new `text-outline-width` attribute to the `icon-text` style technique to allow the customization of the text outline width in pixels. Note that this is a beta release of this feature. <!-- HERESDK-3310 -->

#### API Changes - Breaking

- Map view: Removed the previously deprecated: `MapCameraAnimationFactory.createAnimation(MapCameraUpdate, Duration, EasingFunction)` `MapCameraKeyframeTrack.lookAtDistance(List<ScalarKeyframe>, EasingFunction, KeyframeInterpolationMode)` `MapCameraKeyframeTrack.lookAtTarget(List<GeoCoordinatesKeyframe>, EasingFunction, KeyframeInterpolationMode)` `MapCameraKeyframeTrack.lookAtOrientation(List<GeoOrientationKeyframe>, EasingFunction, KeyframeInterpolationMode)` `MapCameraKeyframeTrack.principalPoint(List<Point2DKeyframe>, EasingFunction, KeyframeInterpolationMode)` `MapCameraKeyframeTrack.normalizedPrincipalPoint(List<Anchor2DKeyframe>, EasingFunction, KeyframeInterpolationMode)` `MapCameraKeyframeTrack.fieldOfView(List<ScalarKeyframe>, EasingFunction, KeyframeInterpolationMode)` `MapItemKeyFrameTrack.moveTo(List<GeoCoordinatesKeyframe>, EasingFunction, KeyframeInterpolationMode)` `MapItemKeyFrameTrack.polylineProgress(List<ScalarKeyframe>, EasingFunction, KeyframeInterpolationMode)` Use counterpart methods with `Easing` parameter instead.  Removed the previoulsy deprecated: `EasingFunction MapCameraKeyframeTrack.getEasingFunction()` getter. <!-- HERESDK-764 -->
- Map view: Removed the previously deprecated class `PickMapContentResult.PoiResult` and method `PickMapContentResult.getPois()`. Use `PickedPlace` and `PickMapContentResult.getPickedPlaces()` instead. <!-- HERESDK-3382 -->
- Routing: Removed the previously deprecated `instructionFormat` attribute from `RouteTextOptions`. <!-- HERESDK-106 -->
- Routing: Removed the previously deprecated `AvoidanceOptions.avoidAreas` property. Please use `AvoidanceOptions.avoidBoundingBoxAreas` instead. <!-- HERESDK-1867 -->
- Routing: Removed the previously deprecated `TextFormat`. <!-- HERESDK-106 -->
- **Upcoming breaking change**: The minimum supported Android API version will be raised from API 23 - Android 6 (Marshmallow) to API 24 - Android 7 (Nougat) with the next major release HERE SDK 4.20.0.0 which is planned for end of September 2024.

#### API Changes - Deprecations

- Map view: Deprecated: `MapViewBase.PickMapItemsCallback`, `MapViewBase.PickMapContentCallback`, `MapViewBase.pickMapItems(Point2D, double, PickMapItemsCallback)` - please use `pick()` instead, `MapViewBase.pickMapContent(Rectangle2D, PickMapContentCallback)` - please use `pick()` instead, `MapView.pickMapItems(Point2D, double, PickMapItemsCallback)` - please use `pick()` instead, `MapView.pickMapContent(Rectangle2D, PickMapContentCallback)` - please use `pick()` instead, `MapSurface.pickMapItems(Point2D, double, PickMapItemsCallback)` - please use `pick()` instead, `MapSurface.pickMapContent(Rectangle2D, PickMapContentCallback)` - please use `pick()` instead. <!-- HERESDK-2976 -->

#### Resolved Issues

- Map style update: Improved density configuration for administrative labels on the map. <!-- CARTO-414 -->

#### Known Issues

- The API Reference you can find on [here.com/docs](https://www.here.com/docs/category/here-sdk) is currently not formatted as expected. Please try to use instead the API Reference we ship as part of the downloadable _release package_ you can find [here](https://platform.here.com/portal/sdk). <!-- TECHDOCS-3586 -->
- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- Map view: `MapViewPin` instances do not disappear after tilting and panning the map far away. The pins still show up above the horizon. <!-- HERESDK-2102 -->
- Routing: An inner city `Route` for trucks carrying dangerous goods may not result in a `SectionNotice` warning when no road sign is indicating such a restriction. <!-- HERESDK-2565 -->
- Map view: When using `MapFeatureModes.TERRAIN_3D` then some portions of the tiles may fail to load when a zoom operation is performed while tiles are still loading. <!-- HERESDK-3135 -->  

### Version 4.18.5.0

#### New Features

- Map view: Added API to manage light settings in a `MapScene` with
`MapScene.LightType` enum to define a light type, `MapScene.LightAttributeSettingError` enum to define attribute errors on light APIs, `MapScene.LightDirection` object to specify a light direction, `MapScene.LightAttributeSettingCallback` interface for handling errors on light APIs, `MapScene.resetLightAttributesToDefaults()` to reset the attributes of all lights to their default values, `MapScene.setLightColor(LightType, Color, LightAttributeSettingCallback)`, `MapScene.setLightIntensity(LightType, float, LightAttributeSettingCallback)`, `MapScene.setLightDirection(LightType, LightDirection, LightAttributeSettingCallback)` to set the light attributes, `MapScene.getLightColor(LightType)`, `MapScene.getLightIntensity(LightType)`, `MapScene.getLightDirection(LightType)` to retrieve the light attributes. Note that this is a beta release of this feature. <!-- HERESDK-2533 -->

#### API Changes - Breaking

- As announced in the changelog for HERE SDK 4.18.4.0, we transitioned to a new backend for satellite-based map schemes (`SATELLITE`, `HYBRID_DAY`, `HYBRID_NIGHT`, `LITE_HYBRID_DAY`, `LITE_HYBRID_NIGHT`): <!-- markdown-link-check-disable-line -->https://maps.hereapi.com/v3/base/mc/{z}/{x}/{y}/jpeg?style=satellite.day&size=512.<!-- markdown-link-check-enable --> The new RTS (Raster Tile Service) endpoint does not support credentials from legacy developer accounts. If you have not already done so, please [migrate your account](https://www.here.com/docs/bundle/platform-migration-guide/page/topics/faq.html). As fallback option set the `EngineBaseURL.RASTER_TILE_SERVICE` to the old endpoint. See our release announcement for HERE SDK 4.18.4.0 for details. <!-- HERESDK-3169 -->
- Map view: Updated the supported map measure value range for 'DashImageRepresentation' from [0-20] to [1-20]. <!-- HERESDK-2735 -->

#### Known Issues

- The API Reference you can find on [here.com/docs](https://www.here.com/docs/category/here-sdk) is currently not formatted as expected. Please try to use instead the API Reference we ship as part of the downloadable _release package_ you can find [here](https://platform.here.com/portal/sdk). <!-- TECHDOCS-3586 -->
- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away. The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in a `SectionNotice` warning when no road sign is indicating such a restriction. <!-- IOTSDK-8521 -->
- Map view: When using `MapFeatureModes.TERRAIN_3D` then some portions of the tiles may fail to load when a zoom operation is performed while tiles are still loading. <!-- HERESDK-3135 -->  

### Version 4.18.4.0

#### New Features

- Search: Added TripAdvisor support via `SearchEngine.setCustomOption()`. Note that this option is only available for customer who own a HERE license for rich content access including TripAdvisor. <!-- HERESDK-3124 -->
- Map view: Added `MapContentType.POINT` enum value. Added `PointData`, `PointDataBuilder`, `PointDataAccessor`, `PointDataSource` and `PointDataSourceBuilder` for creating and managing custom geodetic point data sources. Note that this is a beta release of this feature. <!-- HERESDK-786 -->
- Added `EngineBaseURL.RASTER_TILE_SERVICE` enum value to set a custom base URL template for the raster tile service. The `EngineBaseURL` can be set via `SDKOptions`. This option can be used to switch back to our legacy Map Tile service starting with HERE SDK 4.18.5.0. Note that this option will do nothing until HERE SDK 4.18.5.0. For more details, see our changelog entry regarding the planned Map Tile backend switch. <!-- HERESDK-2381 -->
- Added `LayerConfiguration.implicitlyPrefetchedFeatures` to define what features are downloaded during online usage - for example, when panning the map view or during navigation (if available for your edition). Previously, the same list of features had to be enabled for offline use via `MapDownloader` (if available for your edition) and online use. See our _Optimization Guide_ for the list of features that are enabled, by default. Now it is possible to define a different list for offline use via `LayerConfiguration.enabledFeatures` versus online usage for map view via `implicitlyPrefetchedFeatures`. The features for the latter are implicitly prefetched. If an empty list is set, then implicit prefetching is disabled: Effectively, this means to enable the most minimal network consumption during online use, while for offline use downloaded regions are unaffected. Note that this is a beta release of this feature. <!-- IOTSDK-23833 -->

#### API Changes - Breaking

- **Upcoming major change:** With HERE SDK 4.18.5.0, we plan to transition to a new backend for satellite-based map schemes (`SATELLITE`, `HYBRID_DAY`, `HYBRID_NIGHT`, `LITE_HYBRID_DAY`, `LITE_HYBRID_NIGHT`). These new satellite map schemes are provided through our new Platform Raster Tile Service v3, and it is only accessible when your application is managed through the HERE platform. If you have not already done so, please [migrate your account](https://www.here.com/docs/bundle/platform-migration-guide/page/topics/faq.html) from your HERE developer account to the new HERE platform portal. Your HERE Sales representative or the HERE Support Team is available to assist you. If your account has not been migrated by then, satellite map schemes will no longer be rendered starting with HERE SDK 4.18.5.0. Need more time for the account migration to the HERE platform? Don’t worry! We also provide an option to switch back to our legacy Map Tile / Satellite service: For this, the following option needs to be set before initializing the HERE SDK:

```java
sdkOptions.customEngineBaseUrls = new HashMap<EngineBaseURL, String>() {{
    put(EngineBaseURL.RASTER_TILE_SERVICE,
        "https://1.aerial.maps.ls.hereapi.com/maptile/2.1/maptile/newest/satellite.day/{z}/{x}/{y}/512/jpg");
}};
```

Note that this option will do nothing until HERE SDK 4.18.5.0. <!-- IOTSDK-23863 -->

#### Known Issues

- The API Reference you can find on [here.com/docs](https://www.here.com/docs/category/here-sdk) is currently not formatted as expected. Please try to use instead the API Reference we ship as part of the downloadable _release package_ you can find [here](https://platform.here.com/portal/sdk). <!-- TECHDOCS-3586 -->
- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away. The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in a `SectionNotice` warning when no road sign is indicating such a restriction. <!-- IOTSDK-8521 -->
- Map view: When using `MapFeatureModes.TERRAIN_3D` then some portions of the tiles may fail to load when a zoom operation is performed while tiles are still loading. <!-- HERESDK-3135 -->  

### Version 4.18.3.0

#### New Features

- Routing: Added `TollOptions` to specify how tolls should be calculated by specifying `co2Class`, `emissionType`, `transponders` and `vehicleCategory`. <!-- IOTSDK-23879 -->
- Search: Added new place category ID constant `PlaceCategory.FACILITIES_SCHOOL`. <!-- IOTSDK-24190 -->
- Map view: Added `MapViewBase.pick(MapScene.MapPickFilter, Rectangle2D, MapViewBase.MapPickCallback)`, `MapView.pick(MapScene.MapPickFilter, Rectangle2D, MapViewBase.MapPickCallback)`, `MapViewBase.MapPickCallback`, `MapScene.MapPickFilter`, `MapPickResult`, `MapObjectDescriptor`.	Note that this feature is released as beta. <!-- IOTSDK-23699 -->

#### API Changes - Breaking

- **Upcoming major change:** With HERE SDK 4.18.5.0, we plan to transition to a new backend for satellite-based map schemes (`SATELLITE`, `HYBRID_DAY`, `HYBRID_NIGHT`, `LITE_HYBRID_DAY`, `LITE_HYBRID_NIGHT`). These new satellite map schemes are provided through our new Platform Raster Tile Service v3, and it is only accessible when your application is managed through the HERE platform. If you have not already done so, please [migrate your account](https://www.here.com/docs/bundle/platform-migration-guide/page/topics/faq.html) from your HERE developer account to the new HERE platform portal. Your HERE Sales representative or the HERE Support Team is available to assist you. If your account has not been migrated by then, satellite map schemes will no longer be rendered starting with HERE SDK 4.18.5.0. Need more time for the account migration to the HERE platform? Don’t worry! We also provide an option to switch back to our legacy Map Tile / Satellite service. This fallback option will be available with HERE SDK 4.18.4.0. More details will be shared in the upcoming changelogs. <!-- IOTSDK-23863 -->

#### Resolved Issues

- Routing: Fixed `RoutingEngine.returnToRoute(..)` method where the returned route lacked stopovers when the `lastTraveledSectionIndex` parameter was zero. <!-- IOTSDK-24164 -->

#### Known Issues

- The API Reference you can find on [here.com/docs](https://www.here.com/docs/category/here-sdk) is currently not formatted as expected. Please try to use instead the API Reference we ship as part of the downloadable _release package_ you can find [here](https://platform.here.com/portal/sdk). <!-- TECHDOCS-3586 -->
- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away. The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in a `SectionNotice` warning when no road sign is indicating such a restriction. <!-- IOTSDK-8521 -->  

### Version 4.18.2.0

#### New Features

- Routing: Added `displayLocation` to `Waypoint` and `RoutePlace` to specify the `GeoCoordiates` of a POI to indicate its physical location. <!-- IOTSDK-23461 -->
- Map view: Added `MapContentType.POLYGON` enum value. Added `PolygonData`, `PolygonDataBuilder`, `PolygonDataAccessor`, `PolygonDataSource` and `PolygonDataSourceBuilder` for creating and managing custom geodetic polygon data sources. Note that this feature is released as beta. <!-- IOTSDK-21033 -->
- Map view: Added `GeoPolygon([GeoCoordinates] vertices, [[GeoCoordinates]] innerBoundaries)` to construct a `GeoPolygon` with inner boundaries (holes) and `GeoPolygon.innerBoundaries` member to store and access the inner boundaries of a `GeoPolygon`. <!-- IOTSDK-21033 -->
- Map style update: Added dedicated roadshield icon for Indonesia. <!-- CARTODSG-8 -->

#### API Changes - Deprecations

- Deprecated `TimeRule.asString`. It will be removed in v4.21.0. Please use `TimeRule.timeRuleString` instead. <!-- IOTSDK-23669 -->

#### Known Issues

- The API Reference you can find on [here.com/docs](https://www.here.com/docs/category/here-sdk) is currently not formatted as expected. Please try to use instead the API Reference we ship as part of the downloadable _release package_ you can find [here](https://platform.here.com/portal/sdk). <!-- TECHDOCS-3586 -->
- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away. The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in a `SectionNotice` warning when no road sign is indicating such a restriction. <!-- IOTSDK-8521 -->  

### Version 4.18.1.0

#### Resolved Issues

- Routing: Fixed incorrect side of destination by exposing side of street information from routing response - if available and when `Waypoint.sideOfStreetHint` is provided when calculating a route. <!-- IOTSDK-16639 -->
- Map view: Fixed lost camera limits when calling `MapCameraLimits.setZoomRange(MapMeasureRange value)`. <!-- IOTSDK-23393 -->

#### Known Issues

- The API Reference you can find on [here.com/docs](https://www.here.com/docs/category/here-sdk) is currently not formatted as expected. Please try to use instead the API Reference we ship as part of the downloadable _release package_ you can find [here](https://platform.here.com/portal/sdk). <!-- TECHDOCS-3586 -->
- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away. The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in a `SectionNotice` warning when no road sign is indicating such a restriction. <!-- IOTSDK-8521 -->  

### Version 4.18.0.0

#### New Features

- Map style update: Enabled Z-Level road rendering. <!-- CARTODSG-432 -->
- Map view: Added `MapContext.freeResource()` to free resources used by map view objects. This feature is intended for use when system resource availability becomes low. For example, it allows to free memory when the application transitions to background. <!-- IOTSDK-23774 -->
- Removed beta status for `RoutingEngine.refreshRoute(..)` and `RoutingEngine.importRoute(..)` and their overloads, except for taxi mode which remains beta. <!-- IOTSDK-23855 -->
- EV routing: Removed beta notice for `EVChargingPool`, `EVChargingStation`, `EVChargingPoolDetails` and `EVSE`. These APIs are now considered to be stable. A charging pool for electric vehicles is an area equipped with one or more charging stations. A charging station defines a group of connectors for electrical vehicles that share a common charging connector type and max power level. <!-- IOTSDK-23680 -->
- Routing: Introduced `IsolineRoutingEngine` to support the existing routing isoline feature which was available through the `RoutingEngine` and that has been deprecated with this release. <!-- IOTSDK-23274 -->

#### API Changes - Breaking

- Map view: Removed previously deprecated getters and setters for visual properties of a `MapPolyline` as well as the related constructors. Use instead `MapPolyline.SolidRepresentation` and `MapPolyline.DashRepresentation` with `setRepresentation​(MapPolyline.Representation representation)` and the constructor `MapPolyline​(GeoPolyline geometry, MapPolyline.Representation representation)`. <!-- IOTSDK-20185 -->
- Map view: Renamed `MapFeatureModes.TERRAIN_HILLSHADING` and `MapFeatureModes.TERRAIN_HILLSHADING_WITH_3D` to `MapFeatureModes.TERRAIN_HILLSHADE` and `MapFeatureModes.TERRAIN_3D` respectively. Note that the renamed modes are released as beta. <!-- IOTSDK-23417 -->
- Routing: Removed the previously deprecated `Span.polyline`. Use instead `Span.geometry`. <!-- IOTSDK-18874 -->
- Map view: Removed the previously deprecated `LocationIndicator` implementation of `MapViewLifecycleListener`. Use `LocationIndicator.enable` and `LocationIndicator.disable` to add or remove a `LocationIndicator` from a `MapView`. <!-- IOTSDK-18871 -->
- Routing: Removed the previously deprecated `routingEngine.returnToRoute(...)` method overload which required to calculate the traveled fraction to be set as parameter. Use instead the `routingEngine.returnToRoute(...)` overload which directly consumes the `RouteDeviation` parameters to provide the same information. `routeDeviation.fractionTraveled` has been removed for the same reason. Use instead `routeDeviation.lastTraveledSectionIndex` and `routeDeviation.traveledDistanceOnLastSectionInMeters`. Note that the `RouteDeviation` event is only available for the _Navigate Edition_. <!-- IOTSDK-18420 -->

#### API Changes - Deprecations

- Search: Deprecated the `CategoryQuery.Area` constructor that only takes the corridor as parameter. Use instead the constructor that requires both the corridor and coordinates. <!-- IOTSDK-23352 -->
- Deprecated `SearchError.POLYLINE_TOO_LONG` as it can no longer occur: The HERE SDK now resolves too long polyline issues automatically under the hood. `SearchError.POLYLINE_TOO_LONG` will be removed with HERE SDK 4.20.0. <!-- IOTSDK-23697 -->
- `RoutingEngine`: Deprecated method `calculateIsoline(..)`: The functionality has been moved to the new `IsolineRoutingEngine`. <!-- IOTSDK-23274 -->

#### Resolved Issues

- _Explore Edition_ customers experienced unnecessary requests for vector and satellite tiles that have been already cached. With HERE SDK 4.18.0.0 this has been fixed and new tiles are downloaded earliest after one day based on a LRU strategy. <!-- IOTSDK-23767 -->

#### Known Issues

- The API Reference you can find on [here.com/docs](https://www.here.com/docs/category/here-sdk) is currently not formatted as expected. Please try to use instead the API Reference we ship as part of the downloadable _release package_ you can find [here](https://platform.here.com/portal/sdk). <!-- TECHDOCS-3586 -->
- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away. The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in a `SectionNotice` warning when no road sign is indicating such a restriction. <!-- IOTSDK-8521 -->  

### Version 4.17.5.0

#### New Features

- Map view: Added 'MapScheme.LOGISTICS_NIGHT', the dark equivalent to 'MapScheme.LOGISTICS_DAY' with focus on fleet management content. <!-- IOTSDK-23075 -->
- Routing: Added `timeRule` field to `TollFare` to indicate applicable times for toll costs. <!-- IOTSDK-23607 -->
- Map style update: Added additional localized bank POIs. <!-- CARTODSG-656 -->
- Map view: Added `MapContentType.LINE` enum value. Added `DataAttributeValue`, `DataAttributes` and `DataAttributesBuilder` for creating custom data attributes. Added `LineData`, `LineDataBuilder`, `LineDataAccessor`, `LineDataSource` and `LineDataSourceBuilder` for creating and managing custom geodetic line data sources. This feature allows to consume less memory for large data sets - instead of using `MapPolyline`. It allows also finer control over the style and layer stacking, for example, to show a line before map labels. See also our _style guide for custom map styles_ for more information - which is part of the Developer Guide. Note that this feature is a beta release of this feature. <!-- IOTSDK-21031 -->

#### API Changes - Breaking

- Map view: Removed the beta status for `MapScene.enableFeatures(..)`, `MapScene.disableFeatures(..)`, `MapScene.getSupportedFeatures()` and `MapScene.getActiveFeatures()`. The API is now considered to be stable. <!-- IOTSDK-23457 -->

#### Resolved Issues

- Map view: Fixed density independent pixel scaling for 'MapMarker3d'. <!-- IOTSDK-23191 -->

#### Known Issues

- The API Reference you can find on [here.com/docs](https://www.here.com/docs/category/here-sdk) is currently not formatted as expected. Please try to use instead the API Reference we ship as part of the downloadable _release package_ you can find [here](https://platform.here.com/portal/sdk). <!-- TECHDOCS-3586 -->
- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away. The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in a `SectionNotice` warning when no road sign is indicating such a restriction. <!-- IOTSDK-8521 -->  

### Version 4.17.4.0

#### New Features

- Added `pitchInDegrees` to `Location` class and `DEAD_RECKONING` to `LocationTechnology` enum. Note that these values are not set by the HERE SDK, but applications can now make use of such fields - for example, when special hardware is attached that is capable of providing such data. The new fields are also useful when recording GPX files with the HERE SDK - if available for your edition. <!-- IOTSDK-23242 -->
- Map style update: Added outline display for polygonal roads in Japan. <!-- CARTODSG-6 -->
- Map style update: Implemented dynamic label placement for embedded Carto POIs. Depending on the available space, labels can appear top, left or right around the POI icon to improve readability. <!-- CARTODSG-607 -->
- `RoutingEngine`: Added `RoutingConnectionSettings` option as overloaded constructor parameter to allow custom network connection settings, for example, to specify the retry logic when connecting the HERE routing backend. Note that this change was already introduced with HERE SDK 4.17.3.0. <!-- IOTSDK-23138 -->

#### Known Issues

- The API Reference you can find on [here.com/docs](https://www.here.com/docs/category/here-sdk) is currently not formatted as expected. Please try to use instead the API Reference we ship as part of the downloadable _release package_ you can find [here](https://platform.here.com/portal/sdk). <!-- TECHDOCS-3586 -->
- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away. The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in a `SectionNotice` warning when no road sign is indicating such a restriction. <!-- IOTSDK-8521 -->  

### Version 4.17.3.0

#### New Features

- Search: Added a closed-alpha feature `SearchOptions.highDensityEncodingEnabled`.
  Enabling high density encoding allows input parameters of type `GeoCorridor` to be encoded with higher density of coordinates in `SearchEngine` requests. <!-- IOTSDK-23076 -->
- Introduced visual improvements for the roads in a hybrid scheme on a zoom-in level. Now transparent roads are displayed without round cap artifacts at the intersection of road segments. <!-- CARTODSG-715 -->
- Search: Added `CategoryQuery.Area` constructor that takes `GeoCorridor` and `GeoCoordinates` as parameters. <!-- IOTSDK-23334 -->

#### Known Issues

- The API Reference you can find on [here.com/docs](https://www.here.com/docs/category/here-sdk) is currently not formatted as expected. Please try to use instead the API Reference we ship as part of the downloadable _release package_ you can find [here](https://platform.here.com/portal/sdk). <!-- TECHDOCS-3586 -->
- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away. The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in a `SectionNotice` warning when no road sign is indicating such a restriction. <!-- IOTSDK-8521 -->  

### Version 4.17.2.0

#### New Features

- Map view: Added `DrawOrderType` to represent the type of a draw order. Added `MapPolyline.setDrawOrderType(DrawOrderType)` and `MapPolyline.getDrawOrderType()`. For example, with `MAP_SCENE_ADDITION_ORDER_INDEPENDENT` you can specify that the draw order should not depend on the order of when an item is added. Instead, multiple map items of the same type with the same draw order can be drawn in an arbitrary order and map items with similar attributes like color can be grouped and drawn together all at once to improve the rendering performance. <!-- IOTSDK-23108 -->
- Map style update: Enabled display of outlines for water polygons and polylines. <!-- CARTODSG-686 -->
- Routing: Added more route violation codes with `SectionNoticeCode.VIOLATED_AVOID_DIFFICULT_TURNS`, `SectionNoticeCode.POTENTIAL_CARPOOL`, `SectionNoticeCode.POTENTIAL_TURN_RESTRICTION`, `SectionNoticeCode.POTENTIAL_VEHICLE_RESTRICTION`, `SectionNoticeCode.POTENTIAL_ZONE_RESTRICTION`, `SectionNoticeCode.VIOLATED_CHARGING_STATION_OPENING_HOURS` and `SectionNoticeCode.TOLLS_DATA_TEMPORARILY_UNAVAILABLE`. <!-- IOTSDK-42 -->
- Added `PlaceFilter.EV.minPowerInKilowatts` that enables retrieving EV charging stations with the given minimum charging power. Note that this is released as closed-alpha for selected customers. By default, this feature results in a `SearchError.FORBIDDEN` when your credentials are not enabled. <!-- IOTSDK-22954 -->
- Routing: Added `ViolatedRestriction.Details.timeRule` to inform on the time intervals during which restrictions are enforced. <!-- IOTSDK-22117 -->

#### API Changes - Breaking

- Map view: Changed the allowed range for the camera's field of view (FoV) for `MapCameraKeyframeTrack.fieldOfView()` and `MapCameraUpdateFactory.setVerticalFieldOfView()` - the value for the FoV will be clamped to the range [1deg, 150deg]. <!-- IOTSDK-20796 -->

#### Known Issues

- The API Reference you can find on [here.com/docs](https://www.here.com/docs/category/here-sdk) is currently not formatted as expected. Please try to use instead the API Reference we ship as part of the downloadable _release package_ you can find [here](https://platform.here.com/portal/sdk). <!-- TECHDOCS-3586 -->
- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away. The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in a `SectionNotice` warning when no road sign is indicating such a restriction. <!-- IOTSDK-8521 -->  

### Version 4.17.1.0

#### New Features

- `MapImageOverlay` and related APIs are considered to be stable. Removed the beta status. <!-- IOTSDK-18994 -->
- Added `PickMapContentResult.getPickedPlaces()` to return a list of `PickedPlace` results. A `PickedPlace` can be use more efficiently to search for a `Place` when an embedded map marker is picked from the map. Take a look at the _CartoPOIPicking_ example app for a possible usage scenario. <!-- IOTSDK-19054 -->
- Search: Added `Address.stateCode` that contains a state code for the address. <!-- IOTSDK-22871 -->
- Search: Added `PickedPlace.offlineSearchId` that holds a place ID. Note that the parameter is meant to be consumed by the HERE SDK internally when passing a `PickedPlace` as argument to a search engine. <!-- IOTSDK-19054 -->
- Map style update: Added new embedded Carto POIs for the following categories: _Golf Shop_, _EV Dealership - New Vehicles_, _EV Dealership - Used Vehicles_, _EV Repair_ and _Urgent Care Center_. <!-- CARTODSG-667 -->

#### API Changes - Breaking

- Map style update: Increased the density for city labels. City labels are now shown 1 or 2 zoom levels earlier. <!-- CARTODSG-706 -->

#### API Changes - Deprecations

- Deprecated `PickMapContentResult.PoiResult` and `PickMapContentResult.getPois()`. Use `sdk.core.PickedPlace` and `PickMapContentResult.getPickedPlaces()` instead. <!-- IOTSDK-19054 -->

#### Resolved Issues

- Fixed an issue for the map schemes `ROAD_NETWORK_DAY` and `ROAD_NETWORK_NIGHT` where `MapMarker` items are not rendered as expected. <!-- IOTSDK-22629 -->

#### Known Issues

- The API Reference you can find on [here.com/docs](https://www.here.com/docs/category/here-sdk) is currently not formatted as expected. Please try to use instead the API Reference we ship as part of the downloadable _release package_ you can find [here](https://platform.here.com/portal/sdk). <!-- TECHDOCS-3586 -->
- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away. The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in a `SectionNotice` warning when no road sign is indicating such a restriction. <!-- IOTSDK-8521 -->  

### Version 4.17.0.0

#### New Features

- Routing: Added property `avoidPolygonAreas` to `AvoidanceOptions` to enable avoiding polygon-shaped areas during route calculation. <!-- IOTSDK-19958 -->
- Added `GeoBox.intersection(GeoBox)` and `static GeoBox.intersection(List<GeoBox>)` to detect an intersection of two or more geo boxes - also known as collision check. <!-- IOTSDK-20559 -->
- `TrafficEngine`: Added `queryForFlow()` methods for querying traffic flow data within a bounding box, a circle, or a corridor. Via `TrafficFlowQueryOptions` you can specify the min/max jam factor. The callback provides a list of `TrafficFlow` objects that contain details on the traffic flow. The data may differ from the traffic flow feature shown on the map view. Note that this is a beta release of this feature. <!-- IOTSDK-20554 -->
- `MapView`: Added `Easing` class representing an easing function to be used with animations. This will deprecate the existing use of `EasingFunction`. Added `MapCameraAnimationFactory.createAnimation(MapCameraUpdate, Duration, Easing)`. Added `MapCameraKeyframeTrack.lookAtDistance(List<ScalarKeyframe>, Easing, KeyframeInterpolationMode)`. Added `MapCameraKeyframeTrack.lookAtTarget( List<GeoCoordinatesKeyframe>, Easing, KeyframeInterpolationMode)`. Added `MapCameraKeyframeTrack.lookAtOrientation(List<GeoOrientationKeyframe>, Easing, KeyframeInterpolationMode)`. Added `MapCameraKeyframeTrack.principalPoint(List<Point2DKeyframe>, Easing, KeyframeInterpolationMode)`. Added `MapCameraKeyframeTrack.normalizedPrincipalPoint(List<Anchor2DKeyframe>, Easing, KeyframeInterpolationMode)`. Added `MapCameraKeyframeTrack.position(List<GeoCoordinatesKeyframe>, Easing, KeyframeInterpolationMode)`. Added `MapCameraKeyframeTrack.orientation(List<GeoOrientationKeyframe>, Easing, KeyframeInterpolationMode)`. Added `MapCameraKeyframeTrack.fieldOfView(List<ScalarKeyframe>, Easing, KeyframeInterpolationMode)`. Added `MapItemKeyFrameTrack.moveTo(List<GeoCoordinatesKeyframe>, Easing, KeyframeInterpolationMode)`. Added `MapItemKeyFrameTrack.polylineProgress(List<ScalarKeyframe>, Easing, KeyframeInterpolationMode)`. <!-- IOTSDK-19638 -->
- `MapView`: Added two new `MapScheme` layers: `ROAD_NETWORK_DAY` and `ROAD_NETWORK_NIGHT` which highlight roads without showing other content such as labels or buildings. It is designed for usage as an additional zoomed-in mini-maps display to help drivers to orientate during navigation and to focus on the maneuver arrows which can be highlighted on top of these new map schemes. <!-- IOTSDK-19842 -->
- Custom raster layer: Added a `Style` class to update visual properties of a raster layer at runtime - such as transparency. Added `JsonStyleFactory` to create a `Style` from JSON sources. Added `MapLayerBuilder.withStyle(Style)` method to provide a custom style when creating a `MapLayer`. Added `MapLayer.setStyle(Style)` method to update a custom layer style. Note: This is a beta release of this feature, so there could be a few bugs and unexpected behaviors. Related APIs may change for new releases without a deprecation process. <!-- IOTSDK-20190 -->
- Custom backends: Added enum `EngineBaseURL.TRAFFIC_VECTOR_TILE_SERVICE` to provide a custom traffic vector tile service URL. This impacts the traffic flow feature shown on the `MapView`. <!-- IOTSDK-19023 -->

#### API Changes - Breaking

- Removed deprecated `MapViewOptions` constructors `public MapViewOptions(@NonNull MapProjection)`, `public MapViewOptions(@Nullable Color)`, `public MapViewOptions(@NonNull MapProjection, @Nullable Color)`. Instead, use the default constructor and change the desired fields on the resulting `MapViewOptions` object. <!-- IOTSDK-17543 -->
- Routing: Removed the previously deprecated `Span.getRouteNumber()`. Use instead `Span.getRoadNumbers()`. <!-- IOTSDK-20564 -->
- The HERE SDK is now using `compileSdkVersion` and `targetSdkVersion` 34 instead of 33. Apps should update the version in the app's `build.gradle` file. <!-- IOTSDK-19810 -->
- Custom raster tiles: Removed the previously deprecated `templateUrl` from `RaterDataSourceConfiguration.Provider` along with the corresponding constructors. Use instead `urlProvider` and the corresponding constructors which were previously beta APIs and are now modified to use the non-optional `urlProvider` as first parameter. `TileUrlProviderFactory.fromXyzUrlTemplate()` can be used to generate a URL provider callback for an xyz URL template. `TileUrlProviderCallback` and `TileUrlProviderFactory` are no longer beta APIs and are now considered to be stable. <!-- IOTSDK-18988 -->

#### API Changes - Deprecations

- Routing: Deprecated `AvoidanceOptions.avoidAreas`. Use `AvoidanceOptions.avoidBoundingBoxAreas` instead. <!-- IOTSDK-19958 -->
- Deprecated `MapCameraAnimationFactory.createAnimation(MapCameraUpdate, Duration, EasingFunction)`. Use `MapCameraAnimationFactory.createAnimation(MapCameraUpdate, Duration, Easing)` instead. Deprecated `MapCameraKeyframeTrack.easingFunction` property. Deprecated `MapCameraKeyframeTrack.lookAtDistance(List<ScalarKeyframe>, EasingFunction, KeyframeInterpolationMode)`. Use `MapCameraKeyframeTrack.lookAtDistance(List<ScalarKeyframe>, Easing, KeyframeInterpolationMode)` instead. Deprecated `MapCameraKeyframeTrack.lookAtTarget(List<GeoCoordinatesKeyframe>, EasingFunction, KeyframeInterpolationMode)` Use `MapCameraKeyframeTrack.lookAtTarget(List<GeoCoordinatesKeyframe>, Easing, KeyframeInterpolationMode)` instead. Deprecated `MapCameraKeyframeTrack.lookAtOrientation(List<GeoOrientationKeyframe>, EasingFunction, KeyframeInterpolationMode)`. Use `MapCameraKeyframeTrack.lookAtOrientation(List<GeoOrientationKeyframe>, Easing, KeyframeInterpolationMode)` instead. Deprecated `MapCameraKeyframeTrack.principalPoint(List<Point2DKeyframe>, EasingFunction, KeyframeInterpolationMode)`. Use `MapCameraKeyframeTrack.principalPoint(List<Point2DKeyframe>, Easing, KeyframeInterpolationMode)` instead. Deprecated `MapCameraKeyframeTrack.normalizedPrincipalPoint(List<Anchor2DKeyframe>, EasingFunction, KeyframeInterpolationMode)`. Use `MapCameraKeyframeTrack.normalizedPrincipalPoint(List<Anchor2DKeyframe>, Easing, KeyframeInterpolationMode)` instead. Deprecated `MapCameraKeyframeTrack.position(List<GeoCoordinatesKeyframe>, EasingFunction, KeyframeInterpolationMode)`. Use `MapCameraKeyframeTrack.position(List<GeoCoordinatesKeyframe>, Easing, KeyframeInterpolationMode)` instead. Deprecated `MapCameraKeyframeTrack.orientation(List<GeoOrientationKeyframe>, EasingFunction, KeyframeInterpolationMode)`. Use `MapCameraKeyframeTrack.orientation(List<GeoOrientationKeyframe>, Easing, KeyframeInterpolationMode)` instead. Deprecated `MapCameraKeyframeTrack.fieldOfView(List<ScalarKeyframe>, EasingFunction, KeyframeInterpolationMode)`. Use `MapCameraKeyframeTrack.fieldOfView(List<ScalarKeyframe>, Easing, KeyframeInterpolationMode)` instead. Deprecated `MapItemKeyFrameTrack.moveTo(List<GeoCoordinatesKeyframe>, EasingFunction, KeyframeInterpolationMode)`. Use `MapItemKeyFrameTrack.moveTo(List<GeoCoordinatesKeyframe>, Easing, KeyframeInterpolationMode)` instead. Deprecated `MapItemKeyFrameTrack.polylineProgress(List<ScalarKeyframe>, EasingFunction, KeyframeInterpolationMode)`. Use `MapItemKeyFrameTrack.polylineProgress(List<ScalarKeyframe>, Easing, KeyframeInterpolationMode)` instead. <!-- IOTSDK-19638 -->
- Deprecated `RouteTextOptions.instructionFormat` as it is not supported. <!-- IOTSDK-4468 -->

#### Resolved Issues

- Routing: Fixed missing `Maneuver` items that occurred sometimes for specific locations with highway splits. <!-- IOTSDK-19906 -->
- Routing: Fixed too long shield text for road shields in Japan when English language is used. <!-- OLPSUP-27378 -->

#### Known Issues

- The API Reference you can find on [here.com/docs](https://www.here.com/docs/category/here-sdk) is currently not formatted as expected. Please try to use instead the API Reference we ship as part of the downloadable _release package_ you can find [here](https://platform.here.com/portal/sdk). <!-- TECHDOCS-3586 -->
- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away. The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in a `SectionNotice` warning when no road sign is indicating such a restriction. <!-- IOTSDK-8521 -->  

### Version 4.16.4.0

#### New Features

- Routing: Added `BUILT_UP_AREA` and `CONTROLLED_ACCESS_HIGHWAY` to `StreetAttributes` enum. <!-- IOTSDK-20220 -->
- Map style update: Added a new coach icon and improved the existing tram icon. <!-- CARTODSG-682 -->
- Routing: Added `trafficOptimizationMode` to `RouteOptions` to completely disable traffic optimization. Furthermore, the newly introduced `TrafficOptimizationMode` will replace the deprecated `RouteOptions.enableTrafficOptimization` flag. <!-- IOTSDK-17972 -->
- Map style update: Improved toll tunnel styling in Japan for the day, night and logistics map schemes. <!-- CARTODSG-673 -->
- Search: Added `POIPaymentDetails`, `POIPaymentMethod` and `Details.payment` to show the available payment options at a POI. This is a beta feature and thus subject to change. <!-- IOTSDK-19892 -->
- Map style update: Improved state and county capital label priority. <!-- CARTODSG-675 -->

#### API Changes - Breaking

- Removed closed-alpha APIs `sdk.search.EVPaymentMethod` and `sdk.search.PlaceFilter.EV.paymentMethods`. <!-- IOTSDK-20465 -->

#### API Changes - Deprecations

- Deprecated `RouteOptions.enableTrafficOptimization`. Use `RouteOptions.trafficOptimizationMode` instead. <!-- IOTSDK-17972 -->
- Deprecated `CONTROLLED_ACCESS` enum value in `StreetAttributes`. Use instead `CONTROLLED_ACCESS_HIGHWAY`. <!-- IOTSDK-20220 -->

#### Known Issues

- The API Reference you can find on [here.com/docs](https://www.here.com/docs/category/here-sdk) is currently not formatted as expected. Please try to use instead the API Reference we ship as part of the downloadable _release package_ you can find [here](https://platform.here.com/portal/sdk). <!-- TECHDOCS-3586 -->
- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away. The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in a `SectionNotice` warning when no road sign is indicating such a restriction. <!-- IOTSDK-8521 -->  

### Version 4.16.3.0

#### New Features

- Routing: Added `minChargetAtFirstChargingStationInKilowattHours` to `BatterySpecifications`. It indicates the minimum charge in kWh when arriving at the first charging station. <!-- IOTSDK-19369 -->
- Added `SHADOWS` constant to `MapFeatures` as well as `SHADOWS_ALL` constant to `MapFeatureModes` to enable/disable shadows for 3D buildings. Added enum `ShadowQuality`. Added `MapView.setShadowQuality(@Nullable ShadowQuality shadowQuality)` and `MapView.getShadowQuality()` to set and get shadow quality. Added `MapSurface.setShadowQuality(@Nullable ShadowQuality shadowQuality)` and `MapSurface.getShadowQuality()` to set and get shadow quality. Note that this is a beta release of this feature. <!-- IOTSDK-19109 -->
- Map style update: Added mountain peak elevation visualization. <!-- CARTODSG-20 -->
- Routing: Added `maxWeightPerAxleGroupInKilograms` to `ViolatedRestriction`. Indicates where the max permitted weight per axle group during the trip in kilograms is exceeded. <!-- IOTSDK-19780 -->
- Routing: Added support for private bus routing. Private buses are vehicles that are operated by a private transport company and that do not have access to bus-only lanes reserved for public transit. Use `BusSpecifications` to determine the properties of a private bus. Added `CalculationOptionsType.PRIVATE_BUS`. Added `CalculationOptions.privateBusOptions`. Added `PrivateBusOptions` struct. Added `RoutingInterface.calculateRoute(..)` method for private bus transport mode. Added `RoutingEngine.importRoute(..)` method for private bus routing. Added `RefreshRouteOptions` constructor for private bus routing. <!-- IOTSDK-19575 -->

#### Known Issues

- The API Reference you can find on [here.com/docs](https://www.here.com/docs/category/here-sdk) is currently not formatted as expected. Please try to use instead the API Reference we ship as part of the downloadable _release package_ you can find [here](https://platform.here.com/portal/sdk). <!-- TECHDOCS-3586 -->
- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away. The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in a `SectionNotice` warning when no road sign is indicating such a restriction. <!-- IOTSDK-8521 -->  

### Version 4.16.2.0

#### New Features

- Added new overloads to import bicycle, scooter and pedestrian routes to the `RoutingEngine`. There are two overloads - one without `RouteStop` and one with a `RouteStop` parameter. <!-- IOTSDK-19694 -->
- Added `ViolatedRestriction.Details.routingZoneReference` to provide more details of a restricted routing zone that has been violated. It will be set when `AvoidanceOptions.zoneCategories` is not empty. <!-- IOTSDK-19405 -->
- Added `Details.foodTypes` to show the available food types of a `Place` such as a restaurant while searching for a `Place`. <!-- IOTSDK-19551 -->
- Added a green and white road shield icon to indicate a Trans-Canada highway on the `MapView`. <!-- CARTODSG-118 -->
- Added two new language codes for `ES_AR` (Argentinian Spanish) and `NL_BE` (Flemish) to `LanguageCode`. <!-- IOTSDK-6227 -->
- Added `ViolatedRestriction.Details.maxPayloadCapacityInKilograms` to provide details of the maximum permitted payload capacity that has been violated. <!-- IOTSDK-19601 -->
- Added `BusOptions.BusSpecifications` to specify the properties of a bus for route calculation, such as weight or vehicle dimensions. <!-- IOTSDK-19366 -->

#### Resolved Issues

- Fixed missing maneuver generation when turning while navigation. <!-- IOTSDK-19256 -->

#### Known Issues

- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away. The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in a `SectionNotice` warning when no road sign is indicating such a restriction. <!-- IOTSDK-8521 -->

### Version 4.16.1.0

#### New Features

- Added `SDKNativeEngine.setPassThroughFeatures(Set<PassThroughFeature>)` and `SDKNativeEngine.getPassThroughFeatures()` to allow traffic services to access online data although the `offlineMode` is globally activated via `SDKOptions` or the shared instance of `SDKNativeEngine`. <!-- IOTSDK-18442 -->
- `MapView`: The APIs for `MapPolyline.Representation` and `MapPoyline.setRepresentation(MapPolyine.Representation representation)` are now production-ready. Removed the beta status. <!-- IOTSDK-18505 -->
- Routing: Added method `getId()` to `TrafficIncidentOnRoute`. <!-- IOTSDK-19406 -->
- Added `MapPolyline.SolidRepresentation` and `MapPolyline.DashRepresentation` to encapsulate the visual properties of a `MapPolyline`. <!-- IOTSDK-18505 -->
- Routing: Added `payloadCapacityInKilograms` to `TruckSpecifications` to specify the allowed payload capacity, including trailers. The provided value must be >= 0. By default, it is set to `null`, which means that the value will be ignored for route calculation with the `RoutingEngine` or the `OfflineRoutingEngine` (if available for your edition). <!-- IOTSDK-19368 -->
- `MapView`: The `MapMeasureDependentRenderSize` API is now production-ready: Removed the beta status. The API represents a render size - described as map-measure dependent values. <!-- IOTSDK-18505 -->
- `SearchEngine`: Added `PlaceFoodType`, `CategoryQuery.includeFoodTypes` and `CategoryQuery.excludeFoodTypes` to support food type filtering. <!-- IOTSDK-14081 -->
- Deprecated getters and setter for visual properties of a `MapPolyline` as well as the related constructors. Use `MapPolyline.SolidRepresentation` and `MapPolyline.DashRepresentation` with `setRepresentation​(MapPolyline.Representation representation)` and the constructor `MapPolyline​(GeoPolyline geometry, MapPolyline.Representation representation)` instead. List of all deprecated methods: `MapPolyline​(GeoPolyline geometry, double widthInPixels, Color color)`,
`MapPolyline​(GeoPolyline geometry, double widthInPixels, Color color, double outlineWidthInPixels, Color outlineColor)`, `double MapPolyline.getLineWidth()`, `MapPolyline.setLineWidth(double)`, `Color MapPolyline.getLineColor()`, `MapPolyline.setLineColor(Color)`, `LineCap MapPolyline.getLineCap()`, `MapPolyline.setLineCap(LineCap)`, `java.util.Map<MapMeasure,​java.lang.Double> MapPolyline.getMeasureDependentLineWidth()`, `MapPolyline.setMeasureDependentLineWidth(java.util.Map<MapMeasure,​java.lang.Double>)`, `double MapPolyline.getOutlineWidth()`, `MapPolyline.setOutlineWidth(double)`, `Color MapPolyline.getOutlineColor()`, `MapPolyline.setOutlineColor(Color)`, `java.util.Map<MapMeasure,​java.lang.Double> MapPolyline.getMeasureDependentOutlineWidth()`, `MapPolyline.setMeasureDependentOutlineWidth(java.util.Map<MapMeasure,​java.lang.Double>)`, `DashPattern MapPolyline.getDashPattern()`, `MapPolyline.setDashPattern(DashPattern)`, `Color MapPolyline.getDashFillColor()`, `MapPolyline.setDashFillColor(Color)`. <!-- IOTSDK-18505 -->
- Map style update: Improved visualization of truck restrictions icons related to the amount of axles, weight per axle group, weight per axle number and axle group restriction. <!-- CARTODSG-490 -->

#### API Changes - Breaking

- Removed deprecated log levels: `LogLevel.LOG_LEVEL_TRACE` and `LogLevel.LOG_LEVEL_DEBUG`. Removed `SDKNativeEngine.setLogAppender(LogAppender)` method, use the `LogControl` API instead. <!-- IOTSDK-16982 -->
- `RoadTexts`: Removed the previously deprecated `numbers`, `towards` members and constructors with arguments. Use the `numbersWithDirection` field instead. <!-- IOTSDK-18062 -->

#### Resolved Issues

- Map style update: Reverted the font used for text rendering of Carto POIs from bold to regular. This issue was introduced accidentally with HERE SDK 4.14.5.0. <!-- IOTSDK-18808 -->
- The method `MapContentSettings.setTrafficRefreshPeriod(@NonNull Duration value)` now correctly updates the refresh frequency for upcoming requests. <!-- IOTSDK-19480 -->

#### Known Issues

- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in a `SectionNotice` warning when no road sign is indicating such a restriction. <!-- IOTSDK-8521 -->

### Version 4.16.0.0

#### New Features

- Added `MapContentSettings.setTrafficRefreshPeriod(@NonNull final Duration value)` method to adjust the traffic refresh period for the traffic flow and incidents `MapFeatures` and `MapContentSettings.resetTrafficRefreshPeriod()` to reset the applied traffic refresh period. <!-- IOTSDK-18111 -->
- Added `MapMeasureDependentRenderSize` to represent a render size, described as map-measure dependent values. Note that this is a beta release of this feature. <!-- IOTSDK-18504 -->
- Map style update: Improved showing traffic icons for road closures, when a road is closed - independent of the actual incident type. <!-- CARTODSG-532 -->
- Custom maps: Added enum `EngineBaseURL.TRAFFIC_DATA` to provide a custom traffic backend URL. <!-- IOTSDK-19023 -->
- Added `GeoBox.envelope(GeoBox)` and `static GeoBox.envelopeGeoBoxes(List<GeoBox>)` to encompass two or more geo boxes into one box. <!-- IOTSDK-19385 -->
- Added `CertificateSettings` class to specify parameters to set-up a Mutual Transport Layer Security (mTLS) connection. Note that this change was already introduced with HERE SDK 4.15.4.0. <!-- IOTSDK-18549 -->

#### API Changes - Breaking

- Removed deprecated function `com.here.sdk.core.engine.CatalogVersionHint.latest()`. Use instead `com.here.sdk.core.engine.CatalogVersionHint.latest(boolean)`. <!-- IOTSDK-17205 -->
- Removed deprecated log levels: `LogLevel.LOG_LEVEL_TRACE` and `LogLevel.LOG_LEVEL_DEBUG`. Removed `SDKNativeEngine.setLogAppender(LogAppender)` method, use the `LogControl` API instead. <!-- IOTSDK-16982 -->
- Changed beta API `MapPolyline.DashImageRepresentation` to be immutable. Use `MapMeasureDependentRenderSize` type as size input parameter instead of a map of `(double, double)`. <!-- IOTSDK-18504 -->
- Removed deprecated method `MapViewBase.setWatermarkPlacement(@NonNull final WatermarkPlacement placement, final int bottomMargin)`. <!-- IOTSDK-18987 -->

#### API Changes - Deprecations

- Removed deprecated Maneuver.FERRY. This maneuver is not supported. <!-- IOTSDK-16021 -->
- Removed the deprecated option `routeOptions.enableEnterHighwayManeuverAction()`. The feature is now enabled, by default. <!-- IOTSDK-18061 -->

#### Known Issues

- The new method `MapContentSettings.setTrafficRefreshPeriod(@NonNull Duration value)` might have no effect, as the specified period could potentially be overridden internally over time. <!-- IOTSDK-19480 -->
- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in a `SectionNotice` warning when no road sign is indicating such a restriction. <!-- IOTSDK-8521 -->

### Version 4.15.5.0

#### New Features

- Search: Added `EVChargingPool.cpoId` and `EVChargingPool.evseInfo` as _closed-alpha_. The fields contain info on the _CPO_ ID (Charge Point Operator ID) and the _Electric Vehicle Supply Equipment_ ID (EVSE ID). This is useful for drivers of electric vehicles to determine the charging infrastructure at a charging point. Note: The new fields are only set for participants of the closed-alpha group who got access from HERE to use this feature. <!-- IOTSDK-18993 -->
- Added two `MapCameraUpdateFactory.lookToMatch(..)` functions that match the given `GeoCoordinates` to a given `viewPoint` in order to position the map camera. This does not change the principal point. Note that this is a beta release of this feature. <!-- IOTSDK-18772 -->
- Map style update: Improved the density of city labels. For this, the visibility range of certain city labels has been adjusted. <!-- CARTODSG-629 -->
- `MapView`: Added `MapCameraUpdateFactory.compositeUpdate(List<MapCameraUpdate>)` to support the creation of a composite `MapCameraUpdate` instance that allows to execute all given updates sequentially in the order they were provided in the list. <!-- IOTSDK-17968 -->
- Search: Added `PlaceFilter.ev.paymentMethods` and `EVPaymentMethod` as `closed-alpha`. This allows to filter search results based on the available payment methods at a charging station for electric vehicles. Currently, it is not possible to verify the payment methods for the resulting `Place`. Note: The new filter is only available for participants of the closed-alpha group who got access from HERE to use this feature. If your credentials are not enabled, a [SearchError.FORBIDDEN] will be propagated. <!-- IOTSDK-19042 -->
- Truck routing: Added `TruckRoadTypes` enum that specifies the Swedish types `BK1`, `BK2`, `BK3`, `BK4` and the Mexican types `A2`, `A4`, `B2`, `B4`, `C`, `D`, `ET2`, `ET4`. This is useful for truck-specific road networks that define complex restrictions. The listed types correlate to detailed LAT vehicle specifications which are usually known to truck drivers. For example, truck drivers in Sweden have to know the BK class of their truck to know on which roads they are allowed to drive. Set a `avoidedTruckRoadTypes` list via `TruckOptions` or `EVTruckOptions`. If these options are violated, find a warning in the `SectionNotice` of a `Route`: Added `VIOLATED_AVOID_TRUCK_ROAD_TYPE` to `SectionNoticeCode` and `forbiddenTruckRoadTypes` to `ViolatedRestriction.Details`. <!-- IOTSDK-19027 -->
- Map style update: Added bathymetry ocean visualization for the `NORMAL_DAY` and `NORMAL_NIGHT` map schemes. <!-- CARTODSG-542 -->

#### Resolved Issues

- Routing: Fixed cases where a wrong `ManeuverAction` is generated for forks on highways. <!-- OLPSUP-24250 -->

#### Known Issues

- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.15.4.0

#### New Features

- `SearchEngine`: Added `PlaceFilter.ev.supplierNames` and `PlaceFilter.ev.connectorTypeIDs` as closed-alpha: Participants of the closed-alpha group can get access from HERE to use this feature. If your credentials are not enabled, a [SearchError.FORBIDDEN] will be propagated. <!-- IOTSDK-18519 -->
- Map style update: Country borders are now visually improved - increasing the line width with a more saturated color. State borders will now change from a solid to a dashed line based on the current zoom level. <!-- CARTODSG-520 -->
- Custom map styles: Added `mapScene.reloadScene()` to ensure that an entire scene is reloaded again without using any cached data. This can be useful, when local changes are done on a JSON style file and the same file should be loaded again. This method skips internal optimization checks and enforces a reload of the scene. <!-- IOTSDK-19108 -->
- A `Route` object contains now a list of `RouteRailwayCrossing` elements which indicate the `GeoCoordinates`, a `RouteOffset` and the `RouteRailwayCrossingType` of a railway for a train or a tram line that is crossing the route. Note that this change was already introduced with HERE SDK 4.15.3.0.<!-- IOTSDK-18632 -->
- Map style update: Added Carto POIs for the place category "Business Facility". <!-- CARTODSG-604 -->
- Pick Carto POIs: You can now use the `SearchEngine` or the `OfflineSearchEngine` (not available for all editions) to retrieve a `Place` object containing more details: use the `PickMapContentResult` as data to create a `PickedPlace` object that can be used to search for the `Place`. Added `PickedPlace` that is accepted by the new methods `SearchEngine.searchPickedPlace(..)` and `OfflineSearchEngine.searchPickedPlace(..)` (not available for all editions). <!-- IOTSDK-18731 -->
- `RoutingEngine`: Added an overload of the `importRoute(..)` method to specify a list of `RouteStop` elements. When importing a route just from a list of coordinates, the information on stopover waypoints is usually lost. Use the `RouteStop` class to specify such stops. It allows to specify a `locationIndex` and a `stopDuration`. This will influence the overall ETA - and during navigation the `RouteStop` will be treated as a stopover waypoint so that it will be reported as a `Milestone` when passing-by (note that navigation is only supported for the `Navigate Edition`). <!-- IOTSDK-18910 -->
- Map style update: The `MapScheme.LITE_NIGHT` was improved with dark street colors. Other map elements were styled accordingly to fit the new design. <!-- CARTODSG-618 -->
- `NetworkSettings`: Added client `CertificateSettings` to specify parameters to set-up connections that allow to authenticate during the initial connection of an SSL/TLS handshake via Mutual Transport Layer Security (mTLS). Note that this is a beta release of this feature. <!-- IOTSDK-18549 -->

#### API Changes - Breaking

- `RoutingEngine`: Removed unsupported transport modes for `importRoute(..)` overloads for _bicycles_, _pedestrians_ and _scooters_ when importing routes from a list of `Location` objects. In addition, removed support for `importRoute(..)` overloads that use `RefreshRouteOptions` constructed from `BicycleOptions`, `PedestrianOptions`, or `ScooterOptions`. <!-- IOTSDK-18911 -->

#### Resolved Issues

- Map style update: Improved map labels for political views. <!-- IOTSDK-17085 -->

#### Known Issues

- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.15.3.0

#### New Features

- Added `sdk.core.NetworkEndpoint` class to specify a DNS server and extended `sdk.core.engine.NetworkSettings` with a new `domainNameSystemServers` field to allow setting a list of `NetworkEndpoint` servers to use for HTTP requests. The settings can be set when initializating the HERE SDK to specify alternative endpoints. Check the API Reference for more details. Note that this is an advanced feature that can be ignored by most users. <!-- IOTSDK-18883 -->
- Added debug symbols for Android, which can be found in the release package of the HERE SDK. A customer may use this with Google Play (or any other crash analytics service) to retrieve symbolicated crash logs. Take a look at the _Key Concepts_ section in the Developer Guide for more details. <!-- IOTSDK-14310 -->

#### API Changes - Deprecations

- `MapView`: Using a `LocationIndicator` as a `MapViewLifecycleListener` has been deprecated. Instead, `locationIndicator.enable(..)` and `locationIndicator.disable()` can be used to add/remove a `LocationIndicator` to/from a `MapViewBase`. <!-- IOTSDK-17259 -->
- Routing: Deprecated 'Span.getPolyline'. Use 'Span.getGeometry' instead. <!-- IOTSDK-16557 -->

#### Known Issues

- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.15.2.0

#### New Features

- Android Auto: Added a `MapSurface.RenderListener` interface that allows to hook into the render loop in order to inject custom render commands on top of a frame. Added `MapSurface.setSurface(Context, Surface, width, height, RenderListener)` to configure a `MapSurface` with a `RenderListener`. Take a look at the accompanying `HelloMapSurface` example app for a usage example. Note that this is a beta release of this feature. <!-- IOTSDK-18401 -->
- Custom raster layers: Added a `TileUrlProviderCallback` that can be set to get notified when a new tile is requested from the specified tile data source. Added the convenience function  `TileUrlProviderFactory.fromXyzUrlTemplate()` that can be set as `urlProvider` if the new callback feature is not needed. Take a look at the Developer Guide for a usage example. Note that this is a beta release of this feature. <!-- IOTSDK-17398 -->
- `RoutingEngine`: Improved the routing algorithm for trucks. Now, roads with a `FunctionalRoadClass` of 3 or 4 are penalized more than before. As a result, smaller roads are a bit more often avoided. Overall, this will result in routes that are better suited for trucks. <!-- PBJIRA-3430 -->
- Map style update: Added public transit Carto POIs specific for each country. <!-- CARTODSG-273 -->
- Search: Added `sdk.search.CategoryQuery.placeFilter`, `sdk.search.TextQuery.placeFilter` and `sdk.search.PlaceFilter` that is used to specify place filtering options. <!-- IOTSDK-18489 -->

#### API Changes - Breaking

- Search: Removed `sdk.search.CategoryQuery.fuelTypes`, `sdk.search.CategoryQuery.truckFuelTypes`, `sdk.search.CategoryQuery.truckClass`. Use instead `sdk.search.CategoryQuery.placeFilter`. <!-- IOTSDK-18489 -->
- Search: Removed `sdk.search.TextQuery.fuelTypes`, `sdk.search.TextQuery.truckFuelTypes`, `sdk.search.TextQuery.truckClass`. Use instead `sdk.search.TextQuery.placeFilter`. <!-- IOTSDK-18486 -->
- Custom raster layers: Deprecated the `Provider` constructors for `RasterDataSourceConfiguration` in favor of newly added constructors that consume the new 	`urlProvider` parameter to set the newly added `TileUrlProviderCallback`. Deprecated also the field that holds the `templateUrl` member. Use the newly introduced `urlProvider` instead. <!-- IOTSDK-17398 -->
- The behavior of `MapViewOptions.initialBackgroundColor` has changed: The color is applied as `MapView` background color only between rendering the first frame without a scene config and _before_ rendering the first frame after loading a scene config. To have this color displayed as backgound of an initializing `MapView`, platform specific means must be used like enveloping the `MapView` in a view container with a background color. Note that this change has been already introduced with HERE SDK 4.14.5.0. <!-- IOTSDK-18457 -->

#### Known Issues

- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.15.1.0

#### New Features

- `MapView`: It is now possible to specify initial attrbutes like the desired `MapScheme` already in the Android layout file. Example: `<com.here.sdk.mapview.MapView ... android:id="@+id/map_view" app:map_scheme="normal_day" app:on_load_scene="onLoadScene"/>`. Here an initial `MapScheme` is loaded together with an optional `MapScene.LoadSceneCallback`. All schemes from `MapScheme` are supported and can be selected using the name of the scheme written in snake_case and in lower case. Example: `normal_day`. For now, only the following custom XML attributes are supported: `map_scheme` and `on_load_scene`. <!-- IOTSDK-5753 -->
- Improved readability of logs: Now, all HERE SDK log messages are prefixed with "hsdk-" to make it easier to identify which messages are coming from the HERE SDK. <!-- IOTSDK-17323 -->
- Map style update: Improved polygone outline styling for environmental and congestion zones. <!-- CARTODSG-548 -->
- Map style update: Restricted access roads are now styled according to the properties of a road segment. The HERE Style Editor exposes the following values: `Private`, `Service Road`, or `Public Access = no`. <!-- CARTODSG-474 -->

#### API Changes - Breaking

- The previously deprecated `InitProvider` needs to be removed from the `AndroidManifest.xml` file. From now on, the `InitProvider` should be no longer used, unless for cases where it may be more convenient to initialize the HERE SDK with this class: For example, for integration tests. Removed the previously deprecated methods `InitProvider.destroyLockingProcess()`, `InitProvider.makeSDKNativeEngine()` and `InitProvider.getAndroidContext()`. Note that the shared instance of the `SDKNativeEngine` isn't created automatically on startup and instead it must be created explicitly as shown in the accompanying example apps. <!-- IOTSDK-13832 -->
- Feature configurations and other properties can be no longer set via `AndroidManifest.xml` file. The `OptionReader` class has been removed. Also, a related constructor of the `SDKNativeEngine` has been removed. <!-- IOTSDK-13832 -->
- By default, `SDKOptions.cachePath` and `SDKOptions.persistentMapStoragePath` are now empty - even after the HERE SDK was initialized. Setting a new string, will overwrite the internally used default path, `Context.getCacheDir().getPath()`. After initialization, whatever is set by a user is returned. Note that relative and absolute paths can be set. A relative path will use the internally used default path as parent. <!-- IOTSDK-13832 -->

#### Known Issues

- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.15.0.0

#### New Features

- `MapView`: It is now possible to show traffic flow and a route side-by-side at any zoom level. The line width for `MapArrow` and `MapPolyline` can now be specified per zoom level. Added `MapPolyline.setMeasureDependentLineWidth()`, `MapPolyline.getMeasureDependentLineWidth()`, `MapPolyline.setMeasureDependentOutlineWidth()`, `MapPolyline.getMeasureDependentOutlineWidth()` and `MapArrow.setMeasureDependentTailWidth()`, `MapArrow.getMeasureDependentTailWidth()` to set and get the line and outline width of a `MapPolyline` and the tail width of a `MapArrow` depending on camera zoom level. Note that this is a beta release of this feature. <!-- IOTSDK-13048 -->
- Added `ROAD_EXIT_LABELS` constant to `MapFeatures` as well as `ROAD_EXIT_LABELS_NUMBERS_ONLY` and `ROAD_EXIT_LABELS_ALL` constants to `MapFeatureModes` to enable/disable rendering of road exit labels on the map. <!-- IOTSDK-17484 -->
- Added `isOffRoad` method to the `RoutePlace` that indicates if a route place is off-road or not. <!-- IOTSDK-17445 -->
- Added `MapScheme.LOGISTICS_DAY`, a day version map scheme with focus on fleet management content. <!-- IOTSDK-16237 -->
- Added support for dashed polylines: Added class `MapPolyline.Representation` that is a base class for classes defining visual appearance of `MapPolyline`. Added class `MapPolyline.DashImageRepresentation` used to render `MapPolyline` as a series of images placed along a polyline. Added contructor `MapPolyline(GeoPolyline geometry, MapPolyline.Representation representation)` that allows to create a polyline that is using a `MapPolyline.Representation` for defining the visual appearance of line. Added `MapPolyline.setRepresentation(MapPolyline.Representation representation)` to change the visual appearance of a polyline. <!-- IOTSDK-17427 -->
- Added `UsageStats` class that gathers statistics of the HERE SDK network usage to count all uploaded and downloaded data. Use `SDKNativeEngine.getSdkUsageStats()` and `SDKNativeEngine.enableUsageStats()` to retrieve the network statistics. Added `SDKNativeEngine.clearPersistentUsageStats()` and `SDKNativeEngine.clearUsageStatsCache()` to clear statistics. Note that this is a beta release of this feature. <!-- IOTSDK-16164, IOTSDK-16327 -->
- Pass-through waypoints can now be retrieved from a `Route`: Added class `PassThroughWaypoint` and `Section.getPassthroughWaypoints()` method. <!-- IOTSDK-17886 -->
- Improved visual map styles: City center labels for small villages (hamlets) are now already visible starting from zoom level 13 - instead of 14. <!-- CARTODSG-551 -->
- Routing: Added `offsetStart` and `offsetEnd` properties to `SegmentReference` class. <!-- IOTSDK-18045 -->

#### API Changes - Breaking

- Removed `SDKOptions.enableIndexing` flag. Use instead `OfflineSearchEngine.setIndexOptions()`. Note that the `OfflineSearchEngine` is not available for all editions. <!-- IOTSDK-17978 -->
- `MapCamera`: The altitude value (if set) of the _lookAt_ target `GeoCoordinates` is ignored. Any subsequent camera updates and animations will consider the target coordinates as being located on the ground. Impacted methods (including overloads): `MapCameraAnimationFactory.flyTo()`, `MapCamera.lookAt()` and `MapCameraUpdateFactory.lookAt()`. <!-- IOTSDK-14988 -->
- Removed Dart constructor for `TransitSectionDetails`. Please use other available contructors instead. <!-- IOTSDK-18048 -->
- Removed deprecated `TextQuery.includeChains` and `TextQuery.includeChains`. Please use `CategoryQuery.includeChains` and `CategoryQuery.excludeChains` instead. <!-- IOTSDK-15537 -->
- Removed depracated `RoadFeatures.DIFFICULT_TURNS` and `SectionNoticeCode.VIOLATED_AVOID_DIFFICULT_TURNS` enums. Use other available options instead such as `U_TURNS`. <!-- IOTSDK-13833 -->
- Removed deprecated `MapScene.Layers`. `MapScene.setLayerVisibility` can no longer be used to enable/disable map features. Please use `MapScene.enableFeatures` and `MapScene.disableFeatures` instead. <!-- IOTSDK-13835 -->
- Removed the previously deprecated `MapCameraKeyframeTrack.focalLength()` method. Use `MapCameraKeyframeTrack.fieldOfView() instead`.
Removed the previously deprecated `MapCameraKeyframeTrack.setFocalLength()` method. Use `MapCameraKeyframeTrack.setVerticalFieldOfView() instead`. <!-- IOTSDK-18269 -->
- Removed deprecated `MapFeatureMode.TRAFFIC_FLOW_REGION_SPECIFIC`. Please use `MapFeatureModes.TRAFFIC_FLOW_JAPAN_WITHOUT_FREE_FLOW` instead. <!-- IOTSDK-14409 -->
- Removed the previously deprecated `TruckSpecifications.type`. Please use `TruckSpecifications.truckType` instead. <!-- IOTSDK-17507 -->

#### Resolved Issues

- Fixed missing support for `place.getBoundingBox()` when serializing a `Place` via `Place.serializeCompact()`. <!-- IOTSDK-18326 -->

#### Known Issues

- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.14.5.0

#### New Features

- Added support for road shield icons. With `iconProvider.createRoadShieldIcon(...)` you can now asynchronously create a `Bitmap` that depicts a road number such as "A7" or "US-101" - as it already appears on the map view. Added `IconProvider.IconCallback` to receive the resulting image or an error. The icon is generated offline from `RoadShieldIconProperties` that require parameters such as `RouteType` and `LocalizedRoadNumber`. These parameters can be retrieved from the `Span` of a `Route` object. Added `span.getShieldText(..)` to get the `shieldText` for use with `RoadShieldIconProperties`. Added `span.getRoadNumbers()` to get a list of `LocalizedRoadNumber` items with additional information such as `RouteType` (level 1 to 6, indicating whether a road is a major road or not) and `CardinalDirection` (such as in "101 West"). Note: This is a beta release of this feature. <!-- IOTSDK-17270 -->
- Android Auto: Added `MapSurface(android.content.Context)` and `MapSurface(android.content.Context, MapViewOptions)` to allow a "warm-up" of the _HERE Rendering Engine_. <!-- IOTSDK-15720 -->
- Updated map styles: Improved the visual styling of tunnels. <!-- CARTODSG-119 -->
- Android Auto: Added `MapSurface.redraw(Runnable redrawFinished)` that enforces a redraw of the `MapSurface`. Upon completion it will execute the given `Runnable`. This can be useful to fix issues with a black screen that may occur in rare cases when an app is relaunched from a killed state. <!-- IOTSDK-15720 -->
- Added `WeightPerAxleGroup` to `TruckSpecifications`. Allows specification of axle weights in a more fine-grained way than `weightPerAxleInKilograms`. <!-- IOTSDK-16022 -->
- All `MapViewOptions` can now also be specified from an XML layout file for the `<com.here.sdk.mapview.MapView>` tag: Added custom XML attributes for all members of `MapViewOptions`. Attribute `projection` controls which projection is used, can be one of `globe` or `web_mercator`. Attribute `initial_background_color` of type `color` determines the initial color of the background. Attribute `render_mode` controls if `MapView` component encapsulates a `SurfaceView` (`surface`) or a `TextureView` (`texture`). <!-- IOTSDK-11557 -->

#### Resolved Issues

- Fixed IPv6 support. Added `networkInterface` field to `ProxySetting` to improve compatibility. <!-- IOTSDK-17819 -->

#### Known Issues

- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.14.4.0

#### New Features

- `MapView`: It is now possible to hide icons from the `MapFeatures.VEHICLE_RESTRICTIONS` layer when they cross the path of a `MapPolyline`: Added `MapPolyline.setMapContentCategoriesToBlock(List<MapContentCategory>)` and `MapPolyline.getMapContentCategoriesToBlock()` methods. Added `MapContentCategory` enum. <!-- IOTSDK-17282 -->
- Added gesture support for Android Auto: Added `ScrollHandler`, `ScaleHandler` and `FlingHandler` interfaces. These handlers can be retrieved from the `Gestures` class by calling their corresponding getters, for example: `Gestures.getScaleHandler`. Each handler offers a single method to trigger the gesture handling: `onScroll(float distanceX, float distanceY)` pans the map, `onScale(float focusX, float focusY, float scaleFactor)` zooms by a factor around given point while `onFling(float velocityX, float velocityY)` results in a kinetic move of the given initial velocity. These handlers are useful for processing gestures when using a `MapSurface` with Android Auto. Find a usage example in the `HelloMapAndroidAuto` app on [GitHub](https://github.com/heremaps/here-sdk-examples). <!-- IOTSDK-12419 -->

#### API Changes - Breaking

- `MapView`: Removed the previously deprecated `surfaceCreated(SurfaceHolder)`, `surfaceChanged(SurfaceHolder, int, int, int)` and `surfaceDestroyed(SurfaceHolder holder)` from `MapView`. `MapView` no longer implements the `SurfaceHolder.Callback` interface. <!-- IOTSDK-17420 -->

#### Known Issues

- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.14.3.0

#### New Features

- Improved log messages. Now more information is printed when a fatal error occurs on the native side via JNI / Java. <!-- IOTSDK-17534 -->
- Added 'MapScheme.LITE_DAY', 'MapScheme.LITE_NIGHT', 'MapScheme.LITE_HYBRID_DAY', 'MapScheme.LITE_HYBRID_NIGHT' schemes, which are the simplified versions of the respective normal map schemes. These simplified scheme variants serve well as background for more complex content such as public transit lines. <!-- IOTSDK-17336 -->
- `MapView`: Added option to choose surface or texture view. Added `MapRenderMode` enum and `MapViewOptions.renderMode` field, which allows choosing `SurfaceView` or `TextureView` for map rendering. By default, `SurfaceView` is used, which offers best performance, but can suffer from various graphical glitches that may occur on Android 12 and newer. For applications with complex and dynamic UI and/or with multiple `MapView` instances, using `MapRenderMode.TEXTURE` fixes these graphical glitches. Use the newly introduced `MapViewOptions` to specify the `renderMode`. <!-- IOTSDK-17105 -->
- `MapView`: Added default constructor for `MapViewOptions` which initializes it with default values. <!-- IOTSDK-17105 -->

#### API Changes - Deprecations

- Deprecated `MapViewOptions(MapProjection)`, `MapViewOptions(Color)` and `MapViewOptions(MapProjection, Color)` constructors. Instead, use the default constructor and change desired fields on the resulting `MapViewOptions` object. <!-- IOTSDK-17542 -->

#### Known Issues

- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.14.2.0

#### New Features

- `MapView`: Added more mountain range labels for all preconfigured `MapScheme` styles. <!-- CARTODSG-526 -->
- `MapView`: Improved the visualization and the hierarchy of city labels for the preconfigured map styles. <!-- CARTODSG-524 -->

#### Known Issues

- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.14.1.0

#### New Features

- Custom catalogs: Added `AuthenticationMode` in `SDKOptions`. This feature is useful when `customEngineBaseUrls` are used to self-host backend services. Use 	`AuthenticationMode.withToken(String accessToken)` to set a custom bearer token as string. If `AuthenticationMode.withExternal()` is called, the authentication must be done fully by the client. With `AuthenticationMode.withKeySecret​(String accessKeyId, String accessKeySecret)` you bring back the default behavior, where for each online request a bearer token is set in the header of a request - consisting of the provided credentials. Usually, this is done by the HERE SDK internally. Note: This is a beta release of this feature. <!-- IOTSDK-15681 -->
- `MapView`: Improved map design by adding public transit _access_ icons as embedded Carto POIs based on the General Transit Feed Specification ([GTFS](https://gtfs.org)). Entrances to transit stations are indicated with a small entrance symbol. These icons are clustered, based on the zoom level, together with the transit station icons we added in our last release. Note that this map feature requires OCM version 79 or higher. <!-- CARTODSG-173 -->

#### API Changes - Breaking

- Removed deprecated geo fields and constructors of `sdk.search.TextQuery` and `sdk.search.CategoryQuery`. Use newly added constructors taking `sdk.search.TextQuery.Area` and `sdk.search.CategoryQuery.Area` instead. <!-- IOTSDK-14246 -->
- Removed deprecated `CategoryQuery.withExcludeCategories`. Please set `excludeCategories` directly using `categoryQueryObject.excludeCategories`. <!-- IOTSDK-14246 -->
- `SDKNativeEngine`: Changed `ProxySettings.port` type from `long` to `int`. <!-- IOTSDK-17123 -->

#### Resolved Issues

- `MapView`: Improved visualization and names for traffic styles. <!-- CARTODSG-516 -->

#### Known Issues

- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.14.0.0

#### New Features

- `MapView`: Improved the map design for deserts with a polygon display. Note that this is only available for OCM based maps. <!-- CARTODSG-96 -->
- `MapView`: Improved the map design with an updated style for unpaved roads. The fill and outline color and the labels of unpaved roads are now styled with a brownish tint. <!-- CARTODSG-475 -->
- `RoutingEngine`: `RoadFeatures.U_TURNS` are now supported for cars, taxis and buses and can be avoided. <!-- IOTSDK-14541 -->
- `MapPolygon`: Added `setOutlineColor()`, `getOutlineColor()`, `setOutlineWidth()` and `getOutlineWidth()` methods to enable polygon outlines. <!-- IOTSDK-16922 -->
- `MapView`: Improved the map design by adding public transit embedded Carto POIs based on the General Transit Feed Specification ([GTFS](https://gtfs.org)). The icons are automatically clustered based on the zoom level. Note that this map feature requires OCM version 78 or higher. <!-- CARTODSG-67 -->

#### API Changes - Breaking

- Removed deprecated methods `MapSurface.pickMapFeatures`, `MapView.pickMapFeatures` and class `PickMapFeaturesResult`. Use `MapSurface.pickMapContent`, `MapView.pickMapContent` and `PickMapContentResult` instead. <!-- IOTSDK-12995 -->
- Routing: Removed deprecated `Section.getTrafficSpeeds()` method. Use instead `Span.getTrafficSpeed()`. Removed deprecated `TrafficSpeed.offset`. Use instead `Span.getSectionPolylineOffset()`. <!-- IOTSDK-16921 -->
- Removed the previously deprecated `mapView.setWatermarkPosition()` method. Use instead `mapView.setWatermarkLocation()`. Removed the previously deprecated `mapSurface.setWatermarkPosition()` method. Use instead `mapSurface.setWatermarkLocation()`. <!-- IOTSDK-13061 -->
- Search: Removed deprecated `ACCOMODATION`, `ACCOMODATION_HOTEL_MOTEL` and `ACCOMODATION_LODGING` constants from `PlaceCategory`. `ACCOMMODATION`, `ACCOMMODATION_HOTEL_MOTEL` and `ACCOMMODATION_LODGING` should be used instead. <!-- IOTSDK-13680 -->
- Removed deprecated methods `MapCamera.lookAt(GeoCoordinates, double)` and `MapCamera.lookAt(GeoCoordinates, GeoOrientationUpdate, double)`. Use `MapCamera.lookAt(GeoCoordinates, MapMeasure)` and `MapCamera.lookAt(GeoCoordinates, GeoOrientationUpdate, MapMeasure)` instead. <!-- IOTSDK-11527 -->

#### Resolved Issues

- A `MapViewPin` is now shown outside the initial view port after resizing the map view. <!-- IOTSDK-16477 -->
- When `MapFeatures.vehicleRestrictions` is activated, the map view will no longer show an icon for truck speed limits - also the related purple line is no longer shown. <!-- IOTSDK-16389 -->
- Outlines for `MapPolyline` lines no longer show a minimal gap at certain zoom levels. <!-- HARP-15072 -->
- `RoutingEngine`: Fixed a `RoutingError` that happens for the Slovenian language definition when calling `importRoute()`. <!-- IOTSDK-16997 -->

#### Known Issues

- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.13.5.0

#### New Features

- Routing: Added `Span.countryCode` property to obtain a country code per span. <!-- IOTSDK-16458 -->
- Added `LocationIndicator.setOpacity(double value)` and `LocationIndicator.getOpacity()` to set and get the opacity of a location indicator. <!-- IOTSDK-15656 -->
- Enhanced information on route restrictions: Added `violatedRestrictions: List<ViolatedRestriction>` property to class `SectionNotice`. `ViolatedRestriction.Details` contains, for example, height restrictions or forbidden `TruckType` values. This feature works online, but is also supported for use with the `OfflineRoutingEngine` - if supported by your HERE SDK edition. Note: This is a beta release of this feature. <!-- IOTSDK-16357 -->
- Added `LogControl` to filter HERE SDK log messages. This allows to disable HERE SDK related console logs or to set a custom `LogAppender` to receive only selected log messages from the HERE SDK. <!-- IOTSDK-14868 -->
- Routing: Enhanced `RoadTexts` accessible from a `Maneuver`. `RoadTexts` contains now a list of `LocalizedRoadNumbers` and a `numbersWithDirection` field to contain road numbers with direction. The latter replaces the deprecated `numbers` field. <!-- IOTSDK-13008 -->
- This version of the HERE SDK is delivered with map version 73 and map version 67 for the extended Japan map. <!-- IOTSDK-16560 -->
- Added read-only property `signpost` to get signpost information. `SignpostLabel.direction` will replace `RoadTexts.towards` for getting information about directions. <!-- IOTSDK-13004 -->
- Routing: Added `turnAngleInDegrees` (-180 to 180) and `roundaboutAngleInDegrees` (-360 to 360) to `Maneuver` class to indicate information on the turn angle for all turn related actions. If not applicable for the maneuver, the value will be `null`. `roundaboutAngleInDegrees` indicates the amount of the roundabout that needs to be traversed - it is positive in right-driving countries and negative in left-driving countries. <!-- IOTSDK-16644 -->

#### API Changes - Deprecations

- The `numbers` field in `RoadTexts` has been deprecated and will be removed with HERE SDK version 4.16.0. Use the newly introduced `numbersWithDirection` field instead. <!-- IOTSDK-13008 -->
- Deprecated `setLogAppender()` in `SDKNativeEngine`. Use the newly introduced `LogControl` API instead. Deprecated `Debug` and `Trace` log levels as such messages are not relevant. <!-- IOTSDK-14868 -->

#### Resolved Issues

- `ManeuverAction.ENTER_HIGHWAY_FROM_LEFT` and `ManeuverAction.ENTER_HIGHWAY_FROM_RIGHT` are now properly generated when `RouteOptions.enableEnterHighwayManeuverAction` is set. <!-- IOTSDK-15292 -->

#### Known Issues

- Outlines for `MapPolyline` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->
- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.13.4.0

#### New Features

- Added `MapMarker.setVisibilityRanges(List<MapMeasureRange>)` and `MapMarker.getVisibilityRanges() : List<MapMeasureRange>` methods. <!-- IOTSDK-16118 -->
- `MapMarker3D` objects can now be picked from the map view: Added `PickMapItemsResult.getMarkers3d()` method to retrieve the list of picked `MapMarker3D` instances. <!-- IOTSDK-14570 -->
- Added zoom `visibilityRanges` property to `MapPolyline`. <!-- IOTSDK-5058 -->
- Added `SDKNativeEngine.getProxySettings()` and `SDKNativeEngine.setProxySettings()` methods to get/set the `ProxySettings` that will be used by the HERE SDK for all network requests. By setting a proxy server, you can specify, for example, the IP address and port number of your proxy. By default, no proxy is set. Note: This is a beta release of this feature. <!-- IOTSDK-15417 -->
- This version of the HERE SDK is delivered with map data v71 for the main (ROW) map catalog and v67 for the extended Japan catalog. <!-- IOTSDK-16329 -->
- Added `offlineMode` to `SDKOptions` to initialize the HERE SDK in offline mode. This complements the existing global offline switch via the shared instance of the `SDKNativeEngine` to switch at runtime. <!-- IOTSDK-15993 -->
- Added `MapMarker3D.setVisibilityRanges(List<MapMeasureRange>)` and `MapMarker3D.getVisibilityRanges() : List<MapMeasureRange>` methods. <!-- IOTSDK-7787 -->

#### Resolved Issues

- `MapView`: Fixed handling of `MapFeatures` when an invalid `MapFeatureModes` value has been set. Now features with an invalid mode are silently ignored. <!-- IOTSDK-13916 -->

#### Known Issues

- Outlines for `MapPolyline` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->
- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.13.3.0

#### New Features

- Added opacity factor which specifies the translucency of a `MapMarker3D`. The factor is applied to the alpha channel of the resulting texture of the marker: Added `opacity` and `renderInternalsEnabled` properties. The `renderInternalsEnabled` flag indicates whether to render the internal geometry of a 3D map marker occluded by its front facing polygons. <!-- IOTSDK-15655 -->
- Added property to control the visibility of a `MapPolygon` dependent on a given zoom range: Added `MapPolygon.setVisibilityRanges(List<MapMeasureRange>)` and `MapPolygon.getVisibilityRanges()` methods. <!-- IOTSDK-5783 -->
- Added property to control the visibility of a `MapMarker3D` dependent on a given zoom range: Added `MapMarker3D.setVisibilityRanges(List<MapMeasureRange>)` and `MapMarker3D.getVisibilityRanges()` methods. <!-- IOTSDK-7787 -->
- This version of the HERE SDK is shipped with map data version 69 (OCM). <!-- IOTSDK-16148 -->

#### Resolved Issues

- Polylines are now pickable independent of alpha color values: `MapViewBase.pickMapItems()` now can pick `MapPolyline` items with `fillColor.alpha = 0`. <!-- IOTSDK-15665 -->
- `MapScene.Layers.TRAFFIC_FLOW` and `MapScene.Layers.INCIDENTS` are now visible on the map. This was a license issue which affected all _Navigate_ and _Explore Edition_ users. <!-- PRCAT-33 -->

#### Known Issues

- Outlines for `MapPolyline` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->
- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.13.2.0

#### New Features

- Route calculation: Added more error codes to `RoutingError` to provide more detailed failure reasons. <!-- IOTSDK-15932 -->
- The HERE watermark can now be freely positioned on the map view: Added `mapView.setWatermarkLocation(@NonNull Anchor2D anchor, @NonNull Point2D offset)`,
`@NonNull Size2D mapView.getWatermarkSize()` and `mapSurface.setWatermarkLocation(@NonNull Anchor2D anchor, @NonNull Point2D offset)`, `@NonNull Size2D mapSurface.getWatermarkSize()`. <!-- IOTSDK-15334 -->
- Applied several map style improvements (no API changes involved): Updated the road shield icon for Turkey & Jamaica. Adjusted the visibility of public transport POIs and subway and tram lines in Japan. Improved visibility of intersections and traffic lights in Japan. Added dedicated traffic incident marker for type 'lane-restriction'. Visualized land parcels in Victoria, Australia (applies only to _Navigate Edition_). Added map data attribute 'National Importance' for priority and visibility settings of POIs (applies only to _Explore Edition_). Note that these changes have been already applied for HERE SDK 4.13.1.0. <!-- CARTODSG-91 -->
- Detailed map for Japan: Improved the visibility of labels by reducing duplicated labels for POIs and landuse labels. <!-- CARTODSG-414 -->
- Added `hasShower` attribute in `TruckAmenities` struct and changed `showerCount` attribute to optional. <!-- IOTSDK-15936 -->

#### API Changes - Deprecations

- Deprecated `MapView.setWatermarkPlacement(@NonNull WatermarkPlacement placement, int bottomMargin)` and `MapSurface.setWatermarkPlacement(@NonNull WatermarkPlacement placement, int bottomMargin)`. Use the new APIs instead. <!-- IOTSDK-15334 -->
- Deprecated `FERRY` from `ManeuverAction` enum. It was never used. <!-- IOTSDK-15885 -->

#### Resolved Issues

- Map view: `pickMapItems()` now also picks `MapPolygons` with `fillColor.alpha = 0`. <!-- IOTSDK-15664 -->

#### Known Issues

- Outlines for `MapPolyline` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->
- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- By default, `MapScene.Layers.TRAFFIC_FLOW` and `MapScene.Layers.INCIDENTS` are no longer visible on the map. This is a license issue which affects all _Navigate_ and _Explore Edition_ users. Please [contact us](https://www.here.com/contact) and ask for a HERE SDK license update to get traffic flow data. Your credentials will then be enabled to get access. Explore users can go directly to [developer.here.com](https://developer.here.com/) (instead of the HERE platform self-serve portal) as only the self-serve portal is affected. <!-- PRCAT-33 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.13.1.0

#### New Features

- Added `MapMarkerCluster.setOpacity(double value)` to set and `MapMarkerCluster.getOpacity()` to get the opacity of cluster image. <!-- IOTSDK-15662 -->
- Added optional `billingTag` field to `SDKOptions` to track your HERE platform usage across the various HERE services your application may contact. For more information on the billing tag, see our [cost management guide](https://developer.here.com/documentation/cost-management/dev_guide/topics/tutorials-billing-tags.html). The tag needs to follow the format as described in the guide or it will be ignored. The parameter defaults to `null`, which also means that the tag is ignored for all requests. Note: The billing tag is optional, but when set, it can help you to understand how often your app uses certain services, for example, the number of hits to our HERE backend routing services. For more details on tracking such details, please consult the _cost management guide_ or get in touch with the HERE billing team. <!-- IOTSDK-15294 -->
- Added `BUSINESS_AND_SERVICES_EV_CHARGING_STATION` enum value to `PlaceCategory` to allow searching for EV charging stations via a `CategoryQuery`. <!-- IOTSDK-14059 -->

#### Known Issues

- Outlines for `MapPolyline` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->
- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- By default, `MapScene.Layers.TRAFFIC_FLOW` and `MapScene.Layers.INCIDENTS` are no longer visible on the map. This is a license issue which affects all _Navigate_ and _Explore Edition_ users. Please [contact us](https://www.here.com/contact) and ask for a HERE SDK license update to get traffic flow data. Your credentials will then be enabled to get access. Explore users can go directly to [developer.here.com](https://developer.here.com/) (instead of the HERE platform self-serve portal) as only the self-serve portal is affected. <!-- PRCAT-33 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.13.0.0

#### New Features

- Adding support for transparent `MapMarker` items: Added `MapMarker.setOpacity(final double value)` and `MapMarker.getOpacity()` to set and get opacity of the map markers. <!-- IOTSDK-7163 -->
- Added methods `MapScene.addMapImageOverlay(MapImageOverlay)` and `MapScene.removeMapImageOverlay(MapImageOverlay)`. <!-- IOTSDK-15206 -->
- You can now overwrite the base speeds on a `Route` per segment. After route calculation, you can use the segment reference IDs to set new values per route span and then calculate a new route with the updated values: Added collection of `MaxSpeedOnSegment` instances to all motor-vehicle based route calculation options (`BusOptions`, `CarOptions`, `EVCarOptions`, `EVTruckOptions`, `ScooterOptions`, `TaxiOptions`, and `TruckOptions`) to set restrictions for segments which affects route calculation and the ETA. For the `SegmentReference` parameter, beside the `segmentId`, the `travelDirection` can be optionally set, other values are ignored. Note that this feature is not available for offline use. <!-- IOTSDK-15006 -->
- Added global offline switch to make the HERE SDK radio-silent. This offline mode prevents the HERE SDK from initiating any online connection. `sdkNativeEngine.isOfflineMode()` method added to enable/disable this functionality. Note that this setting is not persisted. This is a beta release of this feature. <!-- IOTSDK-14980 -->
- Add `segmentHint` and `onRoadThreshold` properties to `Waypoint` class to improve waypoint matching. <!-- IOTSDK-15005 -->
- This version of the HERE SDK is delivered with map data version 60. <!-- IOTSDK-15393 -->
- Added `MapViewBase.isValid()` to check the validity of the corresponding `MapView` instance. This will return `false`, when the instance is in an invalid state because it was, for example, destroyed. <!-- IOTSDK-14588 -->
- Added `TransitSectionDetails` constructor that takes 1 parameter. <!-- IOTSDK-12062 -->
- Added class `MapImageOverlay` that allows to show icons on top of the map view that do not move, scale or tilt together with the map. You can use this to show, for example, informative icons on a map view or a map surface view for in-car use. <!-- IOTSDK-15206 -->

#### API Changes - Breaking

- Removed previously deprecated enum `sdk.routing.TunnelCategory`. Please use `sdk.transport.TunnelCategory` instead. Removed previously deprecated `sdk.routing.TruckOptions.tunnelCategory`. Please use `sdk.routing.TruckOptions.linkTunnelCategory`instead.
Removed previously deprecated `sdk.routing.EVTruckOptions.tunnelCategory`. Please use `sdk.routing.EVTruckOptions.linkTunnelCategory`instead. <!-- IOTSDK-12410 -->
- Removed deprecated `Location.timestamp_since_boot_in_milliseconds`. Use `Location.timestamp_since_boot` instead. <!-- IOTSDK-15504 -->
- Remove deprecated 'sdk.routing.Route.getPolyline()'. Use 'sdk.routing.Route.getGeometry()' instead. Remove deprecated 'sdk.routing.Section.getPolyline()'. Use 'sdk.routing.Section.getGeometry()' instead. <!-- IOTSDK-15505 -->
- Removed deprecated enum entries of `MapError`: `DUPLICATE_LAYER`, `INVALID_DATA_SOURCE`, `INVALID_CONTENT`, `UNKNOWN_LAYER`, `UNKNOWN`. <!-- IOTSDK-12535 -->
- Removed deprecated `GeoPlace` constructors. Use the default constructor instead. <!-- IOTSDK-12062 -->
- Removed deprecated `Attribution` constructor that takes all parameters. Use the constructor with 3 parameters instead. Removed deprecated `TransitStop` constructor that takes all parameters. Use the constructor with 1 parameters instead. <!-- IOTSDK-12062 -->
- Removed the previously deprecated `FarePrice.validityPeriodInSeconds`. Use instead `FarePrice.validityPeriod`. <!-- IOTSDK-15504 -->
- Removed deprecated `AuthenticationData.expiry_time_in_seconds`. Use `AuthenticationData.expiry_time` instead. <!-- IOTSDK-15504 -->
- Removed deprecated `AvoidanceOptions` constructor that takes all parameters. Use the default constructor instead. Removed deprecated `CarOptions` constructor that takes all parameters. Use the default constructor instead. Removed deprecated `EVCarOptions` constructor that takes all parameters. Use the default constructor instead. Removed deprecated `EVConsumptionModel` constructor that takes all parameters. Use the default constructor instead. Removed deprecated `FarePrice` constructor that takes all parameters. Use the default constructor instead. Removed deprecated `PedestrianOptions` constructor that takes all parameters. Use the default constructor instead. Removed deprecated `PostAction` constructor that takes all parameters. Use the default constructor instead. Removed deprecated `PreAction` constructor that takes all parameters. Use the default constructor instead. Removed deprecated `RouteTextOptions` constructor that takes all parameters. Use the default constructor instead. Removed deprecated `ScooterOptions` constructor that takes all parameters. Use the default constructor instead. Removed deprecated `TransitRouteOptions` constructor that takes all parameters. Use the default constructor instead. <!-- IOTSDK-12062 -->
- Removed the previously deprecated `PostAction.durationInSeconds`. Use instead `PostAction.duration`. <!-- IOTSDK-15504 -->
- Removed previously deprecated `sdk.routing.TruckType` enum. Please use `sdk.transport.TruckType` enum instead. Removed previously deprecated variable `TruckSpecifications.type`. Please use `TruckSpecifications.truckType` instead. <!-- IOTSDK-12485 -->
- Removed deprecated `AuthenticationData` constructor that takes all parameters. Use the default constructor instead. <!-- IOTSDK-12062 -->
- Removed the previously deprecated `Section.getTrafficDelayInSeconds`. Use instead `Section.getTrafficDelay`. <!-- IOTSDK-15504 -->
- Removed the previously deprecated `Maneuver.getDurationInSeconds`. Use instead `Maneuver.getDuration`. <!-- IOTSDK-15504 -->
- Removed previously deprecated `TruckSpecifications` constructor that takes all parameters. Use the default constructor instead. <!-- IOTSDK-12485 -->
- Removed the previously deprecated `Span.getDurationInSeconds`. Use instead `Span.getDuration`. <!-- IOTSDK-15504 -->
- Removed previously deprecated enum `sdk.routing.HazardousGood`. Please use `sdk.transport.HazardousMaterial`instead. Removed previously deprecated variable `sdk.routing.TruckOptions.hazardousGoods`. Please use `sdk.routing.TruckOptions.hazardousMaterials`instead.
Removed previously deprecated variable `sdk.routing.EVTruckOptions.hazardousGoods`. Please use `sdk.routing.EVTruckOptions.hazardousMaterials`instead. <!-- IOTSDK-12411 -->
- Removed the previously deprecated `Route.getDurationInSeconds`. Use instead `Route.getDuration`. <!-- IOTSDK-15504 -->
- Removed deprecated`TruckOptions` constructor that takes all parameters. Use the default constructor instead. Removed deprecated`EVTruckOptions` constructor that takes all parameters. Use the default constructor instead. <!-- IOTSDK-12062 -->
- Removed deprecated `MapCameraObserver` interface, `MapCamera.addObserver(MapCameraObserver)` and `MapCamera.removeObserver(MapCameraObserver)` methods. Use `MapCamera.addListener(MapCameraListener)` and `MapCamera.removeListener(MapCameraListener)` instead. <!-- IOTSDK-12941 -->
- Removed deprecated `MapCamera.flyTo()` methods and related `MapCamera.FlyToOptions`. Use one of the `MapCameraAnimationFactory.flyTo()` methods to create a fly-to camera animation and `MapCamera.startAnimation(MapCameraAnimation)` to initiate it. <!-- IOTSDK-12944 -->
- Removed `MapCameraUpdateFactory.setPrincipalPointOffset(Point2D)` method. Use `MapCameraUpdateFactory.setNormalizedPrincipalPoint(Anchor2D)` instead. <!-- IOTSDK-12534 -->
- Removed the previously deprecated `BatterySpecifications.chargingSetupDurationInSeconds`. Use instead `BatterySpecifications.chargingDetupDuration`. <!-- IOTSDK-15504 -->
- Removed the previously deprecated `Section.getDurationInSeconds`. Use instead `Section.getDuration`. <!-- IOTSDK-15504 -->
- Removed the previously deprecated `Route.getTrafficDelayInSeconds`. Use instead `Route.getTrafficDelay`. <!-- IOTSDK-15504 -->
- Removed deprecated `Address` constructor that takes all parameters. Use the default constructor instead. <!-- IOTSDK-12013 -->
- Removed the previously deprecated `SearchOptions` constructor. Use default constructor instead. <!-- IOTSDK-12040 -->
- Removed deprecated methods `MapCameraLimits.setMinTilt` and `MapCameraLimits.setMinTilt`, use `MapCameraLimits.tiltRange` instead. Removed deprecated methods `MapCameraLimits.setMinZoomLevel` and `MapCameraLimits.setMaxZoomLevel`, use `MapCameraLimits.zoomRange` instead. Removed enum 'MapCameraLimits.ErrorCode' and exception `MapCameraLimitsException.MapCameraLimitsException` which have become obsolete. <!-- IOTSDK-12943 -->
- Removed `RasterDataSourceFactory` class. Use the constructor instead. <!-- IOTSDK-12536 -->
- Removed deprecated `TransitWaypoint` constructor that takes 2 parameters. Use the constructor that takes 1 parameter instead. <!-- IOTSDK-12062 -->
- Removed the previously deprecated `TransitStop.durationInSeconds`. Use instead `TransitStop.duration`. <!-- IOTSDK-15504 -->
- Removed deprecated `TransitSectionDetails` constructor that takes 6 parameters. Use the constructor that takes 1 parameter instead. <!-- IOTSDK-12062 -->
- Removed deprecated `MapCamera.cancelAnimation()` method. Use `MapCamera.cancelAnimations()` instead. <!-- IOTSDK-12942 -->
- Removed the previously deprecated `Waypoint.durationInSeconds`. Use instead `Waypoint.duration`. <!-- IOTSDK-15504 -->
- Removed deprecated and unsupported method `RasterDataSource.changeConfiguration(String)`. <!-- IOTSDK-12535 -->
- Removed the previously deprecated `PreAction.durationInSeconds`. Use instead `PreAction.duration`. <!-- IOTSDK-15504 -->

#### API Changes - Deprecations

- Deprecated methods to manipulate the focal length of the 'MapCamera'. Methods 'setFocalLength()' of class 'com.here.sdk.mapview.MapCameraUpdateFactory' and 'focalLength()' of class 'com.here.sdk.mapview.MapCameraKeyframeTrack'. Modify the field of view to achieve a similar visual change. <!-- IOTSDK-15220 -->
- Deprecated `TransitSectionDetails` constructor that takes 5 parameters. Use the one that takes 1 parameter instead. <!-- IOTSDK-12062 -->

#### Resolved Issues

- When all types of gesture actions are disabled using the `Gestures.disableDefaultAction(GestureType)` method the start of a gesture will no longer cancel ongoing camera animations. <!-- IOTSDK-14924 -->

#### Known Issues

- Outlines for `MapPolyline` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->
- The global offline switch `sdkNativeEngine.isOfflineMode()` does not load map tiles after enabling the online mode again or after restoring a lost network connection. As a workaround the map view has to be panned & zoomed a bit to activate the online mode again. <!-- OAM-1797 -->
- By default, `MapScene.Layers.TRAFFIC_FLOW` and `MapScene.Layers.INCIDENTS` are no longer visible on the map. This is a license issue which affects all _Navigate_ and _Explore Edition_ users. Please [contact us](https://www.here.com/contact) and ask for a HERE SDK license update to get traffic flow data. Your credentials will then be enabled to get access. Explore users can go directly to [developer.here.com](https://developer.here.com/) (instead of the HERE platform self-serve portal) as only the self-serve portal is affected. <!-- PRCAT-33 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.12.11.0

#### New Features

- `LocationIndicator`: Added visual halo support to indicate the accuracy of the GPS signal. The default 3D assets have been updated. By default, the halo is not visualized. In this case the accuracy indicator has a fixed and zoom level independent size. For values smaller than 20 meters the halo is hidden. Enable the halo by calling `locationIndicator.setAccuracyVisualized(boolean)`.
If enabled, `location.horizontalAccuracyInMeters` defines the size of the halo around the location indicator - after calling `locationIndicator.updateLocation(location)`. Use `isAccuracyVisualized()` to check if the halo feature is currently enabled. <!-- IOTSDK-9118 -->
- This version of the HERE SDK is delivered with map data version 59. <!-- IOTSDK-15239 -->
- Added a way to filter the content shown for the `MapFeatures.trafficIncidents` layer on the map view: Added `MapContentSettings.filterTrafficIncidents(@NonNull List<TrafficIncidentType> trafficIncidents)` method to filter the displayed traffic incidents and `MapContentSettings.resetTrafficIncidentFilter()` method to reset the applied traffic incident filter. <!-- IOTSDK-14742 -->

#### API Changes - Breaking

- The HERE SDK is now using `compileSdkVersion` and `targetSdkVersion` 33 instead of 31. Apps should update the version in the app's `build.gradle` file. <!-- IOTSDK-14564 -->

#### Known Issues

- Outlines for `MapPolyline` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->
- By default, `MapScene.Layers.TRAFFIC_FLOW` and `MapScene.Layers.INCIDENTS` are no longer visible on the map. This is a license issue which affects all _Navigate_ and _Explore Edition_ users. Please [contact us](https://www.here.com/contact) and ask for a HERE SDK license update to get traffic flow data. Your credentials will then be enabled to get access. Explore users can go directly to [developer.here.com](https://developer.here.com/) (instead of the HERE platform self-serve portal) as only the self-serve portal is affected. <!-- PRCAT-33 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.12.10.0

#### New Features

- This version of the HERE SDK is delivered with map data version 57. <!-- IOTSDK-15091 -->

#### Resolved Issues

- Fixed rare crashes during route calculation with traffic caused by weak global reference table overflow. <!-- IOTSDK-15123 -->

#### Known Issues

- Outlines for `MapPolyline` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->
- By default, `MapScene.Layers.TRAFFIC_FLOW` and `MapScene.Layers.INCIDENTS` are no longer visible on the map. This is a license issue which affects all _Navigate_ and _Explore Edition_ users. Please [contact us](https://www.here.com/contact) and ask for a HERE SDK license update to get traffic flow data. Your credentials will then be enabled to get access. Explore users can go directly to [developer.here.com](https://developer.here.com/) (instead of the HERE platform self-serve portal) as only the self-serve portal is affected. <!-- PRCAT-33 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.12.9.0

#### New Features

- Added bulk operation support for `MapPolylines`: Multiple lines can now be added / removed with `addMapPolylines(@NonNull List<MapPolyline> mapPolylines)` and `removeMapPolylines(@NonNull List<MapPolyline> mapPolylines)`. <!-- IOTSDK-12666 -->
- `SDKOptions.customEngineBaseUrls`: Added support for configurable URLs with the new enum value `EngineBaseURL.AUTHENTICATION` that can be used to specify custom URLs for authentication instead of the default URLs. Example URL (do not add endpoints): <!-- markdown-link-check-disable --> "https://account.api.yourcompany.com". <!-- markdown-link-check-enable --> <!-- IOTSDK-14819 -->
- Added `VehicleProfile` class to define the properties of a vehicle. In the future, this profile is planned to be used for routing. Right now, the profile is only relevant for users of the _Navigate Edition_. <!-- IOTSDK-14327 -->
- `SDKOptions.customEngineBaseUrls`: Added support for configurable endpoints with the new enum value `EngineBaseURL.DS_PROXY` that can be used to specify custom endpoints to set a _DS Proxy_ instead of the default endpoints. Example URL (with added endpoints): <!-- markdown-link-check-disable --> "https://data.api.platform.yourcompany.com/direct/v1/test". <!-- markdown-link-check-enable --> <!-- IOTSDK-14821 -->
- `MapMarker` clusters: The beta status for `MapMarkerCluster.ImageStyle`, `MapMarkerCluster.CounterStyle` and the related `MapMarkerCluster` constructor has been removed: The feature has become stable. <!-- IOTSDK-14241 -->
- Added `SDK_ENGINE_ALREADY_DISPOSED` to `InstantiationErrorCode` enum to indicate that `SDKNativeEngine.dispose()` was already called. <!-- IOTSDK-14910 -->

#### API Changes - Breaking

- `MapPolyline`: Removed the beta feature `AlphaBlendType` enum and the related setters/getters. <!-- HARP-19646 -->

#### API Changes - Deprecations

- `MapCamera`: When setting `GeoCoordinates` for any camera operation such as `lookAt()` or `flyTo()`, then the `altitude` value will be ignored starting with release of HERE SDK 4.15.0 - for now, the value has been deprecated. <!-- HARP-19636 -->

#### Known Issues

- Outlines for `MapPolyline` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->
- By default, `MapScene.Layers.TRAFFIC_FLOW` and `MapScene.Layers.INCIDENTS` are no longer visible on the map. This is a license issue which affects all _Navigate_ and _Explore Edition_ users. Please [contact us](https://www.here.com/contact) and ask for a HERE SDK license update to get traffic flow data. Your credentials will then be enabled to get access. Explore users can go directly to [developer.here.com](https://developer.here.com/) (instead of the HERE platform self-serve portal) as only the self-serve portal is affected. <!-- PRCAT-33 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.12.8.0

#### New Features

- Added animation support for `MapPolyline` instances. Now, they can be moved and the progress can be animated (for example, to animate a route-eat-up progress) - added `MapPolylineAnimation` class to represent an animation that can be applied to a `MapPolyline` object. Added static `startAnimation(MapPolylineAnimation, AnimationListener listener)` to `MapPolyline` to start an animation. Added `cancelAnimation(MapPolylineAnimation)` to `MapPolyline` to cancel an animation. Added `MapItemKeyFrameTrack polylineProgress(List<ScalarKeyframe> keyframes, EasingFunction easingFunction, KeyframeInterpolationMode interpolationMode)` to create a keyframe track for the progress property of a 'MapPolyline'. <!-- HARP-19604 -->

#### Known Issues

- Outlines for `MapPolyline` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->
- By default, `MapScene.Layers.TRAFFIC_FLOW` and `MapScene.Layers.INCIDENTS` are no longer visible on the map. This is a license issue which affects all _Navigate_ and _Explore Edition_ users. Please [contact us](https://www.here.com/contact) and ask for a HERE SDK license update to get traffic flow data. Your credentials will then be enabled to get access. Explore users can go directly to [developer.here.com](https://developer.here.com/) (instead of the HERE platform self-serve portal) as only the self-serve portal is affected. <!-- PRCAT-33 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.12.7.0

#### New Features

- `SearchEngine`: Added `connectorTypeId` to `EVChargingStation`. More information on the IDs and the corresponding type can be found [here](https://developer.here.com/documentation/charging-stations/dev_guide/topics/resource-type-connector-types.html). <!-- IOTSDK-14529 -->
- Added `MapView.setSecondaryLanguage(@Nullable LanguageCode languageCode)` and `MapView.getSecondaryLanguage()` to set and get a secondary map language to support places that can show dual labels. If the text for primary and secondary language is the same, then only the primary language will be shown. If a requested language is not supported, then the local language is used. For example, some cities in India show a dual label with Latin (English) & Hindi text - at the same time. <!-- HARP-19524 -->
- Added `MapPolyline.getProgressOutlineColor()` and `MapPolyline.setProgressOutlineColor(@NonNull final Color value)` methods to style the outline of the progress part of a polyline. <!-- HARP-18454 -->
- This version of the HERE SDK is delivered with map data version 54. <!-- IOTSDK-14428 -->

#### Resolved Issues

- `MapPolyline` instances no longer interprete an alpha color setting of 0.0 as fully opaque. <!-- IOTSDK-14645 -->

#### Known Issues

- Outlines for `MapPolyline` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->
- By default, `MapScene.Layers.TRAFFIC_FLOW` and `MapScene.Layers.INCIDENTS` are no longer visible on the map. This is a license issue which affects all _Navigate_ and _Explore Edition_ users. Please [contact us](https://www.here.com/contact) and ask for a HERE SDK license update to get traffic flow data. Your credentials will then be enabled to get access. Explore users can go directly to [developer.here.com](https://developer.here.com/) (instead of the HERE platform self-serve portal) as only the self-serve portal is affected. <!-- PRCAT-33 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.12.6.0

#### New Features

- Added `AlphaBlendType` enum, `MapPolyline.setAlphaBlendType(AlphaBlendType)` and `MapPolyline.getAlphaBlendType()` methods. The `AlphaBlendType` specifies how translucent `MapPolyline` instances are rendered on top of each other. The default type is `OVERWRITE`. Note that this is a beta release of this feature. <!-- HARP-19498 -->
- Search: Added `CategoryQuery.fuelTypes` and `TextQuery.fuelTypes`, which can be used to filter `FuelStation` results based on available fuel types. Added also `TextQuery.truckFuelTypes` and `CategoryQuery.truckFuelTypes`, which can be used to filter `FuelStation` results based on available truck fuel types. <!-- IOTSDK-14287 -->
- Added `MapPolyline.getProgress()`, `MapPolyline.setProgress(final double value)`, `MapPolyline.getProgressColor()` and `MapPolyline.setProgressColor(@NonNull final com.here.sdk.core.Color value)` methods to style two parts of a polyline with different colors. <!-- HARP-18454 -->
- Added `CategoryQuery.truckClass` and `TextQuery.truckClass`, which can be used to filter `FuelStation` results with the minimum supported `TruckClass`. This filter is only available for use with the `SearchEngine`. The `OfflineSearchEngine` (not available for all editions) ignores this filter. <!-- IOTSDK-14287 -->
- Added `RoutePlace.sideOfDestination` to identify the side of a street where the destination waypoint resides. <!-- IOTSDK-9989 -->
- Map style update: Optimized the map view representation for `MapScheme.HYBRID_DAY` and `MapScheme.HYBRID_NIGHT`: The day and night schemes have been unified and the readability has been improved. <!-- HARP-19471 -->

#### API Changes - Deprecations

- Deprecated `MapFeatureModes.TRAFFIC_FLOW_REGION_SPECIFIC`, it will be removed in version 4.15.0. Use the newly introduced `MapFeatureModes.TRAFFIC_FLOW_JAPAN_WITHOUT_FREE_FLOW` instead, if you are using the rich map for Japan. This is the adapted mode for Japan based on  `TRAFFIC_FLOW_WITHOUT_FREE_FLOW` to exclude green lines for no traffic. <!-- IOTSDK-14172 -->

#### Resolved Issues

- `RoutingEngine`: The `importRoute()` feature via a list of `Locations` can be used now as expected. <!-- BAMSUPP-2008 -->
- `MapPolyline` instances no longer ignore alpha color settings. <!-- IOTSDK-5364 -->

#### Known Issues

- Outlines for `MapPolyline` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->
- By default, `MapScene.Layers.TRAFFIC_FLOW` and `MapScene.Layers.INCIDENTS` are no longer visible on the map. This is a license issue which affects all _Navigate_ and _Explore Edition_ users. Please [contact us](https://www.here.com/contact) and ask for a HERE SDK license update to get traffic flow data. Your credentials will then be enabled to get access. Explore users can go directly to [developer.here.com](https://developer.here.com/) (instead of the HERE platform self-serve portal) as only the self-serve portal is affected. <!-- PRCAT-33 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- `MapPolyline` instances interprete an alpha color setting of 0.0 as fully opaque. As a workaround, set an alpha value of 0.01 to make the polyline translucent. Non-zero alpha values work as expected. <!-- IOTSDK-14645 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.12.5.0

#### New Features

- Added `MapFeatures.ENVIRONMENTAL_ZONES` and `MapFeatureModes.ENVIRONMENTAL_ZONES_ALL`. <!-- IOTSDK-13902 -->
- Added `MapFeatures.CONGESTION_ZONES` and `MapFeatureModes.CONGESTION_ZONES_ALL`. <!-- IOTSDK-14302 -->
- All map view features now have a named default mode. Constants for those were added to `MapFeatureModes`: `BUILDING_FOOTPRINTS_ALL`, `EXTRUDED_BUILDINGS_ALL`, `ENVIRONMENTAL_ZONES_ALL`, `TRAFFIC_INCIDENTS_ALL`, `SAFETY_CAMERAS_ALL` (only available for the _Navigate Edition_). <!-- IOTSDK-14172 -->
- `SearchEngine`: Added the property `Details.fuelStation` that contains fuel station attributes. Added struct `sdk.search.FuelStation`,`sdk.search.FuelAdditive`, `sdk.search.GenericFuel`, `sdk.search.TruckFuel`. Currently it is supported only for online search. It can be enabled by adding `show=fuel` as custom option. This is a beta feature and thus subject to change. <!-- IOTSDK-13264 -->
- Optimized the map view representation for extruded buildings and building footprints across zoom levels. <!-- HARP-8049 -->

#### Known Issues

- Outlines for `MapPolyline` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->
- By default, `MapScene.Layers.TRAFFIC_FLOW` is no longer visible on the map. This is a license issue which affects all _Navigate_ and _Explore Edition_ users. Please [contact us](https://www.here.com/contact) and ask for a HERE SDK license update to get traffic flow data. Your credentials will then be enabled to get access. Explore users can go directly to [developer.here.com](https://developer.here.com/) (instead of the HERE platform self-serve portal) as only the self-serve portal is affected. <!-- IOTSDK-1 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- `MapPolyline` instances ignore alpha color settings and will appear fully opaque. <!-- IOTSDK-5364 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->
- `RoutingEngine`: The `importRoute()` feature via a list of `Locations` cannot be used yet commercially and requires custom access credentials. Please contact your sales representative to get access. <!-- BAMSUPP-2008 -->

### Version 4.12.4.0

#### New Features

- Added `ENTER_HIGHWAY_FROM_LEFT` and `ENTER_HIGHWAY_FROM_RIGHT` values to `ManeuverAction` enum. They indicate the maneuver action for a driver to perfom on entering a highway either from the left or right side. These enum values are only generated when setting the `enableEnterHighwayManeuverAction` flag in `RouteOptions` to true. By default, the flag is set to false. With HERE SDK 4.14.0 we plan to set it to true, by default. <!-- IOTSDK-13199 -->
- Added `sdk.search.AreaType` enum which represents the type of an area such as country, state or district. Added `sdk.search.Place.getAreaType()` method which gets the area type for the respective `Place`. <!-- IOTSDK-7592 -->
- Added `EVChargingStation.hasFixedCable` field to know if a charging station for electric vehicles supports fixed cables. <!-- IOTSDK-14196 -->

#### Resolved Issues

- Increased size limit from 10000 to 50000 for `routingEngine.importRoute()` when setting a list of `Location` points. <!-- IOTSDK-14102 -->
- `RoutingEngine`: Improved the time to calculate `Route` results for very large routes. <!-- IOTSDK-13756 -->
- `RoutingEngine`: Fixed missing toll information for bus or taxi online routes. <!-- IOTSDK-12676 -->

#### Known Issues

- Outlines for `MapPolyline` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->
- By default, `MapScene.Layers.TRAFFIC_FLOW` is no longer visible on the map. This is a license issue which affects all _Navigate_ and _Explore Edition_ users. Please [contact us](https://www.here.com/contact) and ask for a HERE SDK license update to get traffic flow data. Your credentials will then be enabled to get access. Explore users can go directly to [developer.here.com](https://developer.here.com/) (instead of the HERE platform self-serve portal) as only the self-serve portal is affected. <!-- IOTSDK-1 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- `MapPolyline` instances ignore alpha color settings and will appear fully opaque. <!-- IOTSDK-5364 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->
- `RoutingEngine`: The `importRoute()` feature via a list of `Locations` cannot be used yet commercially and requires custom access credentials. Please contact your sales representative to get access. <!-- BAMSUPP-2008 -->

### Version 4.12.3.0

#### New Features

- Introduced a new `MapMarkerCluster.CounterStyle` that indicates the number of contained `MapMarker` items in a cluster. The style allows various options to customize how this will be rendered on top of a cluster image. A new `MapMarkerCluster()` constructer has been added to set the style. In addition, an `Anchor2D` can be used to position the counter and the cluster image. An usage example can be found in the `MapItems` example app. Note that this is a beta release of this feature. <!-- IOTSDK-10207 -->
- Added the `onResume()`/`onPause()` lifecycle methods to the `MapSurface` class. <!-- IOTSDK-13977 -->
- Added `CategoryQuery.includeChains` and `CategoryQuery.excludeChains` that support search filtering by [chains](https://developer.here.com/documentation/geocoding-search-api/dev_guide/topics-places/places-chain-system-full.html). <!-- IOTSDK-14080 -->
- The properties for `EVChargingPoolDetails` and `EVChargingStation` have been extended. Such information is available when using the online `SearchEngine` and the `OfflineSearchEngine` (for users of the _Navigate Edition_). <!-- IOTSDK-13786 -->
- `SearchEngine`: Added `TruckAmenities` to the `Details` of a `Place` to inform on amenities such as truck wash or the number of available showers. Currently, this is supported only for online search. For now, this can be enabled by calling `searchEngine.setCustomOption()` with "show" as `name` and "truck" as `value`. This is a beta release of this feature. <!-- IOTSDK-13263 -->

#### API Changes - Breaking

- Search for EV charging stations: Moved and renamed `Place.Details.EVChargingStationAttributes` to `Place.Details.EVChargingPool.EVChargingPoolDetails`. <!-- IOTSDK-13786 -->
- `MapFeatureModes.TRAFFIC_FLOW_REGION_SPECIFIC` is only rendered for credentials that enable detailed map data for Japan. By default, use `MapFeatureModes.TRAFFIC_FLOW_WITH_FREE_FLOW` instead. <!-- IOTSDK-13903 -->

#### API Changes - Deprecations

- Deprecated `TextQuery.includeChains` and `TextQuery.excludeChains`. Please use `CategoryQuery.includeChains` and `CategoryQuery.excludeChains` instead. <!-- IOTSDK-14080 -->

#### Known Issues

- Outlines for `MapPolyline` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->
- By default, `MapScene.Layers.TRAFFIC_FLOW` is no longer visible on the map. This is a license issue which affects all _Navigate_ and _Explore Edition_ users. Please [contact us](https://www.here.com/contact) and ask for a HERE SDK license update to get traffic flow data. Your credentials will then be enabled to get access. Explore users can go directly to [developer.here.com](https://developer.here.com/) (instead of the HERE platform self-serve portal) as only the self-serve portal is affected. <!-- IOTSDK-1 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- `MapPolyline` instances ignore alpha color settings and will appear fully opaque. <!-- IOTSDK-5364 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->
- The newly introduced `TruckAmenities` feature is not highlighted as a beta API in the API Reference. <!-- IOTSDK-14199 -->
- `RoutingEngine`: The route import feature via a list of `Locations` cannot be used yet commercially and requires custom access credentials. Please contact your sales representative to get access. <!-- PBJIRA-2012 -->

### Version 4.12.2.0

#### New Features

- Search `Details` now contain `EVChargingStationAttributes` - if applicable for a `Place`. <!-- IOTSDK-13786 -->

#### API Changes - Breaking

- Removed `connectorTypeId` from the search type `EVChargingStation`. The API is still in beta state. <!-- IOTSDK-13786 -->

#### Resolved Issues

- `SearchEngine`: Corrected the allowed range of `SearchOptions.maxItems` to [1, 100]. When not set, results will be limited to 20, by default. This applies also to auto suggestion results. <!-- IOTSDK-13617 -->

#### Known Issues

- Outlines for `MapPolyline` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->
- By default, `MapScene.Layers.TRAFFIC_FLOW` is no longer visible on the map. This is a license issue which affects all _Navigate_ and _Explore Edition_ users. Please [contact us](https://www.here.com/contact) and ask for a HERE SDK license update to get traffic flow data. Your credentials will then be enabled to get access. Explore users can go directly to [developer.here.com](https://developer.here.com/) (instead of the HERE platform self-serve portal) as only the self-serve portal is affected. <!-- IOTSDK-1 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- `MapPolyline` instances ignore alpha color settings and will appear fully opaque. <!-- IOTSDK-5364 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->
- `RoutingEngine`: The route import feature via a list of `Locations` cannot be used yet commercially and requires custom access credentials. Please contact your sales representative to get access. <!-- PBJIRA-2012 -->

### Version 4.12.1.0

#### New Features

- EV routing: Added `PostAction.chargingDetails` to get `ChargingActionDetails`, which supports additional parameters for EV charging such as `arrivalChargeInKilowattHours` and `targetChargeInKilowattHours`. The latter indicates the kWh level to which a vehicle's battery should be charged at a stop. <!-- IOTSDK-13551 -->
- Added support for our new web-based unified [HERE Style Editor](https://platform.here.com/style-editor/) that is available on the HERE platform. With the HERE Style Editor you can create highly [customizable map styles](https://developer.here.com/documentation/flutter-sdk-navigate/dev_guide/topics/custom-map-styles.html#create-and-load-custom-map-styles). Note that custom map styles that have been made with the legacy desktop editor need to be migrated to the new HERE Style Editor format. [Get in touch](https://www.here.com/contact) with your HERE representative to convert your existing styles. The HERE Style Editor is available via self-serve on the HERE platform. <!-- IOTSDK-1000 -->
- Replaced `MapScene.Layers` with a more flexible solution: All map layers can now be enabled or disabled as `MapFeatures` specifying one ore more `MapFeatureModes`. Pass a map of key / value pairs to the new `MapScene` method `void enableFeatures(@NonNull Map<String, String> features)`. Hide a layer via `void disableFeatures(@NonNull final List<String> features)`. Query supported map features via `@NonNull Map<String, List<String>> getSupportedFeatures()` and check currently active map features with `@NonNull Map<String, String> getActiveFeatures()`. Note that this is a beta release of this feature. <!-- IOTSDK-13580 -->
- Added a simplified way to initialize the HERE SDK manually. Using the default automatic initialization is still possible, but has been deprecated. Added `SDKNativeEngine.makeSharedInstance()` to safely initialize a shared instance of the  `SDKNativeEngine`. Calling this method also gracefully destroys any previous instance (if any). In order to deactivate auto-init, for now it is still required to disable the deprecated `InitProvider` via `AndroidManifest`. For this it is also required to remove credentials from manifest and to set them instead via `SDKOptions`. As a result, the HERE SDK SDK will not be created automatically at startup. In addition to `InitProvider`, also the `OptionsReader` has been deprecated. Note that now also an `android.content.Context` needs to be provided. If, in rare cases, there's a need for multiple instances of the `SDKNativeEngine`, a new constructor has been added with `SDKNativeEngine(android.content.Context, SDKOptions)`. The existing constructor `SDKNativeEngine(SDKOptions)` that does not require a context has been deprecated. <!-- IOTSDK-12047 -->
- Search: Added `TextQuery.includeChains` and `TextQuery.excludeChains` that support search filtering by adding a list of `PlaceChain` items. More information on chain IDs that correlate to specific places such as shops or stores can be found [here](https://developer.here.com/documentation/geocoding-search-api/dev_guide/topics-places/places-chain-system-full.html). <!-- IOTSDK-13719 -->

#### API Changes - Deprecations

- In rare cases an application using the HERE SDK may crash due to a `Storage.LevelDB` error or the initialization of the HERE SDK may fail with a `FAILED_TO_LOCK_CACHE_FOLDER` error. Deprecated the related 'void InitProvider.destroyLockingProcess(SDKOptions options, long maxTimeoutInMilliseconds)' and `SDKNativeEngine.getLockingProcessId(SDKOptions options)`. Use instead the `LockingProcess` class to prevent such crashes. The related function `OptionsReader.getActionOnCacheLock(Context context)` and `OptionsReader.ActionOnCacheLock` have been removed as they are no longer needed. <!-- IOTSDK-12047 -->
- Deprecated all constants defined in `MapScene.Layers`. Instead of using those constants with `MapScene.setLayerVisibility()`, use the newly introduced `MapScene.enableFeatures()` and `MapScene.disableFeatures()` with the constants from `MapFeatures` and `MapFeatureModes`. Note that unlike layer visibility state, a map feature state is reset on `loadScene()`. <!-- IOTSDK-13668 -->
- Online `RoutingEngine`: Deprecated `RoadFeatures.DIFFICULT_TURNS`. Use instead `RoadFeatures.U_TURNS`. <!-- IOTSDK-12531 -->

#### Resolved Issues

- The response time to calculate routes with the `RoutingEngine` has been heavily improved. <!-- IOTSDK-13756 -->

#### Known Issues

- Outlines for `MapPolyline` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->
- By default, `MapScene.Layers.TRAFFIC_FLOW` is no longer visible on the map. This is a license issue which affects all _Navigate_ and _Explore Edition_ users. Please [contact us](https://www.here.com/contact) and ask for a HERE SDK license update to get traffic flow data. Your credentials will then be enabled to get access. Explore users can go directly to [developer.here.com](https://developer.here.com/) (instead of the HERE platform self-serve portal) as only the self-serve portal is affected. <!-- IOTSDK-1 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- `MapPolyline` instances ignore alpha color settings and will appear fully opaque. <!-- IOTSDK-5364 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->
- `RoutingEngine`: The route import feature via a list of `Locations` cannot be used yet commercially and requires custom access credentials. Please contact your sales representative to get access. <!-- PBJIRA-2012 -->

### Version 4.12.0.0

#### New Features

- We have launched a web-based [HERE Style Editor](https://platform.here.com/style-editor/) to create custom map styles. The editor will be available for use with the upcoming release of **HERE SDK 4.12.1.0**. <!-- IOTSDK-1000 -->
- This version of the HERE SDK is delivered with map data version 45. <!-- IOTSDK-13621 -->

#### API Changes - Breaking

- Removed previously deprecated `void MapScene.setLayerState​(@NonNull java.lang.String layerName, @NonNull MapScene.LayerState newState)`. Use `MapScene.setLayerVisibility(java.lang.String, com.here.sdk.mapview.VisibilityState)` instead. Removed previously deprecated enum `MapScene.LayerState`, use `VisibilityState` instead. <!-- IOTSDK-11528 -->
- The style for `MapScheme.NORMAL_NIGHT` has been updated to improve readability: Increased brightness, saturation and contrast and reduced the number of different color tones. <!-- HARP-16820 -->
- A new web-based unified [HERE Style Editor](https://platform.here.com/style-editor/) was made available on the HERE platform. The editor will be available for use with the upcoming release of **HERE SDK 4.12.1.0**. It is compatible with the [Maps API for JavaScript (JSAPI)](https://developer.here.com/develop/javascript-api) and the HERE SDK. Custom map styles that have been made with the legacy desktop editor need to be migrated to the new HERE Style Editor format. [Get in touch](https://www.here.com/contact) with your HERE representative to discuss potential style updates until then. HERE SDK 4.12.0.0 is the last release that supports the old desktop format. <!-- IOTSDK-1000 -->
- Monthly active users (MAU) are no longer counted when the HERE SDK is initialized. Instead, only usage counts, for example, when a `MapView` is shown, or when any engine like `SearchEngine`, `RoutingEngine` or any other engine - including `MapDownloader`, `RoutePrefetcher`, `Navigator` and `VisualNavigator` (for users of the _Navigate Edition_) - is _instantiated_. If credentials are changed at runtime, then usage is counted again. <!-- IOTSDK-12843 -->

#### API Changes - Deprecations

- Deprecated `ACCOMODATION`, `ACCOMODATION_HOTEL_MOTEL` and `ACCOMODATION_LODGING` constants in `PlaceCategory`. Use the newly added `ACCOMMODATION`, `ACCOMMODATION_HOTEL_MOTEL` and `ACCOMMODATION_LODGING` constants instead. <!-- IOTSDK-13360 -->

#### Known Issues

- Outlines for `MapPolyline` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->
- By default, `MapScene.Layers.TRAFFIC_FLOW` is no longer visible on the map. This is a license issue which affects all _Navigate_ and _Explore Edition_ users. Please [contact us](https://www.here.com/contact) and ask for a HERE SDK license update to get traffic flow data. Your credentials will then be enabled to get access. Explore users can go directly to [developer.here.com](https://developer.here.com/) (instead of the HERE platform self-serve portal) as only the self-serve portal is affected. <!-- IOTSDK-1 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- `MapPolyline` instances ignore alpha color settings and will appear fully opaque. <!-- IOTSDK-5364 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->
- `RoutingEngine`: The route import feature via a list of `Locations` cannot be used yet commercially and requires custom access credentials. Please contact your sales representative to get access. <!-- PBJIRA-2012 -->

### Version 4.11.4.0

#### New Features

- This version of the HERE SDK is delivered with map data version 44. <!-- IOTSDK-13213 -->
- A `Route` contains now indexes for traffic incidents: Added `getTrafficIncidentIndexes()` to `Span`. The indexes are related to the traffic incidents in the parent `Section`. This helps to find the exact positions of traffic incidents on a route. <!-- IOTSDK-13098 -->
- EV routing: Added `availableConnectorCount` to `EVChargingStation`. It represents the number of available physical connectors at a charging station. <!-- IOTSDK-13446 -->
- Added `setGeoCoordinates()` and `getGeoCoordinates()` to `Metadata`. <!-- APIGEN-1520 -->

#### API Changes - Breaking

- Aligned the return value of `PickMapContentResult.TrafficIncidentResult.getOriginalId()` to return a `String` instead of an integer. <!-- IOTSDK-13383 -->
- The zoom level behavior of the `MapCamera` has been aligned: Internally, the HERE SDK calculates now a zoom level with a pixel scale as reference instead of ppi. As a result, when a zoom level is set, the `MapView` is zoomed in a bit less than previously. Note that this affects only the zoom level and not the camera's distance setting to earth. In addition, the maximum zoom level has been increased from 22 to 23. <!-- IOTSDK-13117 -->

#### Resolved Issues

- A `Route` created with the `RoutingEngine` differentiates now between sections for stops and sections created due to a transport mode change: The `waypointIndex` of the first departure place and the last arrival place are now set according to the waypoints indexes. <!-- IOTSDK-13187 -->

#### Known Issues

- Outlines for `MapPolyline` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->
- By default, `MapScene.Layers.TRAFFIC_FLOW` is no longer visible on the map. This is a license issue which affects all _Navigate_ and _Explore Edition_ users. Please [contact us](https://www.here.com/contact) and ask for a HERE SDK license update to get traffic flow data. Your credentials will then be enabled to get access. Explore users can go directly to [developer.here.com](https://developer.here.com/) (instead of the HERE platform self-serve portal) as only the self-serve portal is affected. <!-- IOTSDK-1 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- `MapViewPin` instances do not disappear after tilting and panning the map far away: The pins still show up above the horizon. <!-- IOTSDK-7051 -->
- `MapPolyline` instances ignore alpha color settings and will appear fully opaque. <!-- IOTSDK-5364 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->
- `RoutingEngine`: The route import feature via a list of `Locations` cannot be used yet commercially and requires custom access credentials. Please contact your sales representative to get access. <!-- PBJIRA-2012 -->

### Version 4.11.3.0

#### New Features

- Added class `PickMapContentResult.TrafficIncidentResult` containing all data of a picked traffic incident. Added `PickMapContentResult.getTrafficIncidents` for retrieving picked traffic incidents. <!-- IOTSDK-12427 -->
- This version of the HERE SDK is delivered with map data version 41. <!-- IOTSDK-13213 -->
- Added `void MapCamera.lookAt(GeoCoordinates, MapMeasure)` and `void MapCamera.lookAt(GeoCoordinates, GeoOrientationUpdate, MapMeasure)`. <!-- IOTSDK-10913 -->
- Added `sdk.transport.TruckSpecifications` as replacement for the deprecated `sdk.routing.TruckSpecifications`. <!-- HARP-18336 -->

#### API Changes - Deprecations

- Deprecated `sdk.routing.TruckSpecifications` class. Use 'sdk.transport.TruckSpecifications' instead. <!-- HARP-18336 -->
- Deprecated `void MapCamera.lookAt(GeoCoordinates, double)` and `void MapCamera.lookAt(GeoCoordinates, GeoOrientationUpdate, double)`. Use instead the newly added `lookAt()` methods to set a `MapMeasure`, which allows now to specify if distance, scale or zoom level should be changed. <!-- IOTSDK-10913 -->
- Added `EVTruckOptions.truck_specifications` as replacement for the deprecated `EVTruckOptions.specifications`. <!-- HARP-18336 -->
- Added `TruckOptions.truck_specifications` as replacement for deprecated `TruckOptions.specifications`. <!-- HARP-18336 -->
- Deprecated `TruckOptions.specifications`. Use `TruckOptions.truck_specifications`instead. <!-- HARP-18336 -->
- Deprecated `EVTruckOptions.specifications`. Use `EVTruckOptions.truck_specifications`instead. <!-- HARP-18336 -->

#### Known Issues

- Outlines for `MapPolyline` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- `MapPolyline` instances ignore alpha color settings and will appear fully opaque. <!-- IOTSDK-5364 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->
- `RoutingEngine`: The route import feature via a list of `Locations` cannot be used yet commercially and requires custom access credentials. Please contact your sales representative to get access. <!-- PBJIRA-2012 -->
- By default, `MapScene.Layers.TRAFFIC_FLOW` is no longer visible on the map. This is a license issue which affects all _Navigate_ and _Explore Edition_ users. Please [contact us](https://www.here.com/contact) and ask for a HERE SDK license update to get traffic flow data. Your credentials will then be enabled to get access. Explore users can go directly to [developer.here.com](https://developer.here.com/) (instead of the HERE platform self-serve portal) as only the self-serve portal is affected.

### Version 4.11.2.0

#### New Features

- Added method `setCustomOptions()` to `RoutingEngine` which allows adding custom options to each routing query. Use this feature at your own risk to experiment with [Routing API v8 backend features](https://developer.here.com/documentation/routing-api/dev_guide/index.html) that are not yet supported by the HERE SDK. <!-- IOTSDK-13168 -->

#### API Changes - Deprecations

- `SearchEngine`: Deprecated existing constructors of `sdk.search.TextQuery` and `sdk.search.CategoryQuery`. Use newly added constructors taking `sdk.search.TextQuery.Area` and `sdk.search.CategoryQuery.Area` instead. <!-- IOTSDK-13013 -->
- Deprecated `Section.getDepartureTime()` and `Section.getArrivalTime()` methods. Use `Section.getDepartureLocationTime()` and `Section.getArrivalLocationTime()` methods instead. Added `LocationTime` class which provides the local time, UTC time and the UTC offset, including DST time variations. <!-- IOTSDK-12926 -->
- Deprecated `MapViewBase.pickMapFeatures(Rectangle2D, MapViewBase.PickMapFeaturesCallback)`, `MapView.pickMapFeatures(Rectangle2D, MapViewBase.PickMapFeaturesCallback)`, `MapSurface.pickMapFeatures(Rectangle2D, MapViewBase.PickMapFeaturesCallback)`, `MapViewBase.PickMapFeaturesCallback`, `PickMapFeaturesResult`. Use instead the newly introduced `MapViewBase.pickMapContent(Rectangle2D, MapViewBase.PickMapContentCallback)`, `MapView.pickMapContent(Rectangle2D, MapViewBase.PickMapContentCallback)`, `MapViewBase.PickMapContentCallback`, `PickMapContentResult`. <!-- IOTSDK-12981 -->

#### Resolved Issues

- Fixed failing traffic incident queries for `TrafficEngine`. <!-- IOTSDK-13245 -->
- Bus routes may not be fully accurate and the `TransportMode` of such routes is incorrectly changed to `CAR`. Fixed value returned by the `getSectionTransportMode()` method of a `Section` for bus routes. <!-- IOTSDK-13104 -->

#### Known Issues

- Outlines for `MapPolyline` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- `MapPolyline` instances ignore alpha color settings and will appear fully opaque. <!-- IOTSDK-5364 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->
- `RoutingEngine`: The route import feature via a list of `Locations` cannot be used yet commercially and requires custom access credentials. Please contact your sales representative to get access. <!-- PBJIRA-2012 -->

### Version 4.11.1.0

#### New Features

- Added 'MapImage(@NonNull byte[] imageData, @NonNull ImageFormat imageFormat, long width, long height)' to set a custom size. It will also accept PNG image data. <!-- IOTSDK-13016 -->
- Search: Added `Suggestion.getId()` that returns an auto suggest item ID. <!-- IOTSDK-13014 -->
- Added methods to `MapView` to set a HERE watermark margin with `mapView.setWatermarkPlacement(@NonNull final WatermarkPlacement placement, final int bottomMargin)` and `mapSurface.setWatermarkPlacement(@NonNull final WatermarkPlacement placement, final int bottomMargin)`. <!-- IOTSDK-12703 -->

#### API Changes - Breaking

- Removed the previously deprecated constructor `Location(@NonNull final GeoCoordinates coordinates, @NonNull final Date timestamp)`, the class `Location.Builder` and the
field `Location.timestamp`. Use the default constructor instead and set the values afterwards. <!-- IOTSDK-12988 -->

#### API Changes - Deprecations

- Deprecated the methods `MapView.setWatermarkPosition(final WatermarkPlacement placement, final long bottomCenterMargin)` and `MapSurface.setWatermarkPosition(final WatermarkPlacement placement, final long bottomCenterMargin)`. Use the related `setWatermarkPlacement()` method instead. <!-- IOTSDK-12703 -->

#### Resolved Issues

- Dark background issue fixed for `MapView` when using a `webMercator` projection. <!-- IOTSDK-12971 -->
- Fixed: Finding traffic on a route via `trafficEngine.queryForIncidents` fails unexpectedly for `GeoCorridor` objects that are much shorter than 500 km. <!-- IOTSDK-12801 -->

#### Known Issues

- Outlines for `MapPolyline` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->
- `MapDownloader`: The `sizeOnDiskInBytes` property of `Region` and `InstalledRegion` slightly differs. <!-- IOTSDK-12688 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- Bus routes may not be fully accurate and the `TransportMode` of such routes is incorrectly changed to `CAR`. <!-- IOTSDK-13104 -->
- `MapPolyline` instances ignore alpha color settings and will appear fully opaque. <!-- IOTSDK-5364 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->
- `RoutingEngine`: The route import feature via a list of `Locations` cannot be used yet commercially and requires custom access credentials. Please contact your sales representative to get access. <!-- IOTSDK-12285 -->
- Custom raster tiles may not be rendered for some cases after panning and zooming the map. <!-- HARP-18266 -->

### Version 4.11.0.0

#### New Features

- Added low-level 3D support to programmatically add custom 3D objects on the map. Added `MeshBuilder`, `TriangleMeshBuilder` and `QuadMeshBuilder` to construct different kinds of meshes from points in 3D space via `Point3D`. The resulting `Mesh` container can be used with a texture graphic to create `MapMarker3D` objects. <!-- IOTSDK-11386 -->
- `MapMarker3D` objects can now be scaled using a `RenderSize.Unit` in `meters`, `pixels` and
`densityIndependentPixels`. <!-- IOTSDK-9672 -->
- Added `CategoryQuery.excludeCategories` to add a list of `PlaceCategory` items that should be excluded from a category search for places. These categories can be set with `CategoryQuery.withExcludeCategories`. <!-- IOTSDK-12939 -->
- Added enhanced animation support for `MapMarker` objects via the new `MapMarkerAnimation` class. Such animations are based on a `MapItemKeyFrameTrack` that stores keyframes for interpolation of a map item property. It can be constructed by calling `MapItemKeyFrameTrack.moveTo(@NonNull List<GeoCoordinatesKeyframe> keyframes, @NonNull EasingFunction easingFunction, @NonNull KeyframeInterpolationMode interpolationMode)`. The animation can be started or cancelled via `mapMarker.startAnimation(mapMarkerAnimation)/cancelAnimation(mapMarkerAnimation)`. <!-- IOTSDK-10493 -->
- Added support for online Bus route calculation via `RoutingEngine`. Added `TransportMode.BUS` and `BusOptions`. <!-- IOTSDK-12696 -->
- Added fade animations for `MapMarker` by calling `setFadeDuration(Duration)`. The marker will automatically fade-in when being added to the `MapView` and fade-out when being removed. By default, this feature is disabled. The current fade duration can be retrieved by calling `getFadeDuration()`. It defaults to 0. <!-- IOTSDK-4861 -->
- Added explicit support for flat `MapMarker3D` objects. Added a convenience constructor for `MapMarker3D` with a `MapImage` parameter to create a flat map marker. Use `RenderSize.Unit` with `densityIndependentPixels` to create flat marker with a fixed size - independent of zoom level. <!-- IOTSDK-3964 -->
- Added enhanced camera animations with `MapCameraAnimationFactory.flyTo(GeoCoordinatesUpdate, double, Duration)`, `MapCameraAnimationFactory.flyTo(GeoCoordinatesUpdate, GeoOrientationUpdate, double, Duration)`, `MapCameraAnimationFactory.flyTo(GeoCoordinatesUpdate, MapMeasure, double, Duration)`, `MapCameraAnimationFactory.flyTo(GeoCoordinatesUpdate, GeoOrientationUpdate, MapMeasure, double, Duration)`. <!-- HARP-18311 -->

#### API Changes - Breaking

- Removed the previously deprecated `InstantiationErrorCode.FAILED_TO_LOCK_PERSISTENT_MAP_STORAGE_FOLDER`. Nothing to use instead: The persistent storage directory is no longer locked. <!-- IOTSDK-10993 -->
- Removed the previously deprecated `SectionNoticeCode.VIOLATED_PEDESTRIAN_OPTION` symbol. Nothing to use instead as this is no longer supported. <!-- IOTSDK-10978 -->

#### API Changes - Deprecations

- Deprecated `MapCamera.FlyToOptions`` and all `MapCamera.flyTo` APIs. Use `MapCameraAnimationFactory.flyTo` APIs instead. <!-- HARP-18311 -->
- Deprecated `Section.getTrafficSpeeds()` method. Use instead `Span.getTrafficSpeed()`. <!-- IOTSDK-10258 -->

#### Resolved Issues

- The `TrafficEngine` can handle now `GeoCorridor` objects without a radius. When the radius via `halfWidthInMeters` is unset, a default value of 30 meters is used. <!-- IOTSDK-12800 -->
- The `returnToRoute()` feature of the `RoutingEngine` now routes back to the first untravelled waypoint and the `routeFractionTraveled` parameter is no longer ignored. <!-- IOTSDK-11493 -->

#### Known Issues

- Outlines for `MapPolyline` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->
- Finding traffic on a route via `trafficEngine.queryForIncidents` fails unexpectedly for `GeoCorridor` objects that are much shorter than 500 km. <!-- IOTSDK-12801 -->
- `MapDownloader`: The `sizeOnDiskInBytes` property of `Region` and `InstalledRegion` slightly differs. <!-- IOTSDK-12688 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- `MapPolyline` instances ignore alpha color settings and will appear fully opaque. <!-- IOTSDK-5364 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->
- `RoutingEngine`: The route import feature via a list of `Locations` cannot be used yet commercially and requires custom access credentials. Please contact your sales representative to get access. <!-- IOTSDK-12285 -->
- Custom raster tiles may not be rendered for some cases after panning and zooming the map. <!-- HARP-18266 -->

### Version 4.10.5.0

#### New Features

- Added `MapMeasureRange` class to hold a `MapMeasure` range, `MapCameraLimits.setZoomRange(MapMeasureRange)` and `MapCameraLimits.getZoomRange` methods. <!-- HARP-18314 -->
- Added support for custom backends with the new `EngineBaseURL` enum and the `customEngineBaseUrls` field in `SDKOptions`. <!-- IOTSDK-12409 -->
- Added `MapCameraLimits.setTiltRange(AngleRange)` and `MapCameraLimits.getTiltRange` methods. <!-- HARP-18331 -->
- Route alternatives are now fully supported for electric vehicles. EV route alternatives are enabled when `routeOptions.alternatives` is in the range [1, 6]. Note that this feature is already available since v4.10.4.0. <!-- IOTSDK-12400 -->
- Added `MapCameraLimits.setBearingRangeAtZoom(MapMeasure, AngleRange)`, `MapCameraLimits.clearBearingRanges`, `MapCameraLimits.setTiltRangeAtZoom(MapMeasure, AngleRange)` and `MapCameraLimits.clearTiltRanges`. <!-- HARP-18274 -->
- Added `MapCamera.cancelAnimation(MapCameraAnimation)` and `MapCamera.cancelAnimations` methods. <!-- HARP-18331 -->
- Added `MapCameraListener` interface, `MapCamera.addListener(MapCameraListener)`, `MapCamera.removeListener(MapCameraListener)` and `MapCamera.removeListeners` methods. <!-- HARP-18331 -->

#### API Changes - Deprecations

- `Location.Builder` has been deprecated. Will be removed in v4.11.0. To create a new `Location` instance use a constructor. <!-- IOTSDK-12317 -->
- Deprecated `Location.timestampSinceBootInMilliseconds`. Use `Location.timestampSinceBoot` instead. <!-- IOTSDK-12317 -->
- Deprecated `MapCameraLimits.setMinTilt(double)` and `MapCameraLimits.setMaxTilt(double)`. Use `MapCameraLimits.setTiltRange(AngleRange)` instead. <!-- HARP-18331 -->
- Deprecated `MapCamera.cancelAnimation` method. Use `MapCamera.cancelAnimations` instead. <!-- HARP-18331 -->
- Deprecated `MapCameraLimits.setMinZoomLevel(double)`, `MapCameraLimits.setMaxZoomLevel(double)`, `MapCameraLimits.ErrorCode`, `MapCameraLimits.MapCameraLimitsException`. Use `MapCameraLimits.setZoomRange(MapMeasureRange)` instead. <!-- HARP-18314 -->
- Deprecated `MapCameraObserver` interface, `MapCamera.addObserver(MapCameraObserver)` and `MapCamera.removeObserver(MapCameraObserver)` methods. Use `MapCamera.addListener(MapCameraListener)` and `MapCamera.removeListener(MapCameraListener)` instead. <!-- HARP-18331 -->

#### Resolved Issues

- Fixed incorrect handling of `RouteOptions.occupantsNumber` while requesting a route. <!-- IOTSDK-12592 -->
- Routing: Fixed incorrect offset calculation for departure/arrival time that happens when converting to UTC time. <!-- IOTSDK-12799 -->

#### Known Issues

- Outlines for `MapPolyline` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->
- Finding traffic on a route via `trafficEngine.queryForIncidents` fails unexpectedly for `GeoCorridor` objects that are much shorter than 500 km. <!-- IOTSDK-12801 -->
- `MapDownloader`: The `sizeOnDiskInBytes` property of `Region` and `InstalledRegion` slightly differs. <!-- IOTSDK-12688 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- `MapPolyline` instances ignore alpha color settings and will appear fully opaque. <!-- IOTSDK-5364 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->
- `RoutingEngine`: The route import feature via a list of `Locations` cannot be used yet commercially and requires custom access credentials. Please contact your sales representative to get access. <!-- IOTSDK-12285 -->
- Custom raster tiles may not be rendered for some cases after panning and zooming the map. <!-- HARP-18266 -->

### Version 4.10.4.0

#### New Features

- Added `sdk.transport.TruckType` enum. It is meant to replace the deprecated `sdk.routing.TruckType`. <!-- IOTSDK-11015 -->
- Added `TruckOptions.hazardous_materials`. It is meant to replace the deprecated `TruckOptions.hazardous_goods`. <!-- IOTSDK-11015 -->
- Added `sdk.transport.HazardousMaterial` enum. It is meant to replace the deprecated `sdk.routing.HazardousGood`. <!-- IOTSDK-11015 -->
- Added `EVTruckOptions.hazardous_materials`. It is meant to replace the deprecated `EVTruckOptions.hazardous_goods`. <!-- IOTSDK-11015 -->
- Traffic incident queries can now be canceled by calling the `cancel()` method of the `TaskHandle` object returned by the `TrafficEngine`. <!-- IOTSDK-12489 -->
- Added `routing.TruckSpecifications.truck_type`. It is meant to replace the deprecated `routing.TruckSpecifications.type`. <!-- IOTSDK-11015 -->

#### API Changes - Deprecations

- Deprecated `routing.TruckSpecifications.type`. Use `routing.TruckSpecifications.truck_type` instead. <!-- IOTSDK-11015 -->
- Deprecated `sdk.routing.HazardousGood` enum. Use 'sdk.transport.HazardousMaterial' instead. <!-- IOTSDK-11015 -->
- Deprecated `EVTruckOptions.hazardous_goods`. Use `EVTruckOptions.hazardous_materials` instead. <!-- IOTSDK-11015 -->
- Deprecated `routing.TruckType` enum. Use `transport.TruckType` instead. <!-- IOTSDK-11015 -->
- Deprecated `TruckOptions.hazardous_goods` enum. Use 'TruckOptions.hazardous_materials' instead. <!-- IOTSDK-11015 -->

#### Known Issues

- Outlines for `MapPolyline` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->
- `MapDownloader`: The `sizeOnDiskInBytes` property of `Region` and `InstalledRegion` slightly differs. <!-- IOTSDK-12688 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- `MapPolyline` instances ignore alpha color settings and will appear fully opaque. <!-- IOTSDK-5364 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->
- `RoutingEngine`: The route import feature via a list of `Locations` cannot be used yet commercially and requires custom access credentials. Please contact your sales representative to get access. <!-- IOTSDK-12285 -->
- Custom raster tiles may not be rendered for some cases after panning and zooming the map. <!-- HARP-18266 -->

### Version 4.10.3.0

#### New Features

- Added `sdk.transport.TunnelCategory`. It is meant to replace deprecated `sdk.routing.TunnelCategory`. <!-- IOTSDK-11015 -->
- Added altitude handling for offline routing. <!-- IOTSDK-12425 -->
- Added methods `isDepthCheckEnabled()` and `setDepthCheckEnabled(final boolean value)` to `MapMarker3D` class. This improves rendering for complex 3D objects such as a torus. <!-- IOTSDK-12413 -->
- Added support for `UNKNOWN` value from `TrafficIncidentImpact` and `TrafficIncidentType` enums to enable filtering for traffic incidents. This value indicates that all types/impacts are requested from the backend and filtering will be applied thereafter by the HERE SDK. <!-- IOTSDK-12329 -->
- Added `EVTruckOptions.link_tunnel_category`. It is meant to replace deprecated `EVTruckOptions.tunnel_category`. <!-- IOTSDK-11015 -->
- Added `TruckOptions.link_tunnel_category`. It is meant to replace deprecated `TruckOptions.tunnel_category`. <!-- IOTSDK-11015 -->
- Added `MapCameraUpdateFactory.setNormalizedPrincipalPoint(Anchor2D)` method to animate camera's principal point using normalized screen coordinates. <!-- HARP-18064 -->
- Added `Anchor2DKeyframe` class to be used in animation of normalized principal point. Added `MapCameraKeyframeTrack.normalizedPrincipalPoint(List<Anchor2DKeyframe>, EasingFunction, KeyframeInterpolationMode)` that creates keyframe track for animating normalized principal point. Added `MapCameraKeyframeTrack.getAnchor2DKeyframes()` method. Added `MapCameraUpdateFactory.setNormalizedPrincipalPoint(Anchor2D)` method. <!-- HARP-18064 -->
- Visibility of embedded default Carto POIs on the map has been improved. <!-- HARP-17932 -->
- Added colors related to landuse area polygons in the night scheme have been updated. <!-- HARP-17798 -->
- Added `MapIdleListener` to detect whether the map is idle or busy. Added `HereMap.addMapIdleListener(MapIdleListener)` to start receiving idle state notifications and `HereMap.removeMapIdleListener(MapIdleListener)` to stop receiving idle state notifications. <!-- IOTSDK-11221 -->
- Added constructors to 'RasterDataSource'. <!-- HARP-17952 -->
- Added `initialBackgroundColor` to `MapViewOptions` and constructor to set initial background color. Initial background color will be shown until the first map scene has been loaded. <!-- IOTSDK-8377 -->
- Updated colors related to street network elements for the night scheme. <!-- HARP-17797 -->

#### API Changes - Deprecations

- Deprecated unsupported method `RasterDataSource.changeConfiguration(String)`. Use the another constructor instead. <!-- HARP-18139 -->
- Deprecated `BatterySpecifications.changingSetupDurationInSeconds`. Use `BatterySpecifications.changingSetupDuration` instead. <!-- IOTSDK-10084 -->
- Deprecated `TruckOptions.tunnel_category` enum. Use 'TruckOptions.link_tunnel_category' instead. <!-- IOTSDK-11015 -->
- Deprecated `Maneuver.durationInSeconds`. Use `Maneuver.duration` instead.
    - Deprecated `Section.durationInSeconds`. Use `Section.duration` instead.
    - Deprecated `Section.trafficDelayInSeconds`. Use `Section.trafficDelay` instead. <!-- IOTSDK-10084 -->
- Deprecated `RasterDataSourceFactory`. Use the existing `RasterDataSource()` constructor instead. <!-- HARP-17952 -->
- Deprecated `Waypoint.durationInSeconds`. Use `Waypoint.duration` instead. <!-- IOTSDK-10084 -->
- Deprecated `sdk.routing.TunnelCategory` enum. Use 'sdk.transport.TunnelCategory' instead. <!-- IOTSDK-11015 -->
- Deprecated `Route.durationInSeconds`. Use `Route.duration` instead.
    - Deprecated `Route.trafficDelayInSeconds`. Use `Route.trafficDelay` instead. <!-- IOTSDK-10084 -->
- Deprecated `MapCameraUpdateFactory.setPrincipalPointOffset(Point2D)` method. Use `MapCameraUpdateFactory.setNormalizedPrincipalPoint(Anchor2D)` instead. <!-- HARP-18064 -->
- Deprecated `EVTruckOptions.tunnel_category`. Use `EVTruckOptions.link_tunnel_category` instead. <!-- IOTSDK-11015 -->
- Deprecated `PostAction.durationInSeconds`. Use `PostAction.duration` instead.
    - Deprecated `PostAction` constructor with parameters. Use the default constructor instead.
    - Deprecated `PreAction.durationInSeconds`. Use `PreAction.duration` instead.
    - Deprecated `PreAction` constructor with parameters. Use the default constructor instead. <!-- IOTSDK-10084 -->
- Deprecated `TransitStop.durationInSeconds`. Use `TransitStop.duration` instead. Deprecated `TransitStop(departure, durationInSeconds)` constructor with parameters. Use the default constructor instead. <!-- IOTSDK-10084 -->
- Deprecated `getLinks` in `sdk.routing.Section`. Use `getSpans` instead. <!-- IOTSDK-12048 -->

#### Resolved Issues

- Adding custom raster layers no longer hides the HERE logo. <!-- IOTSDK-12202 -->

#### Known Issues

- Outlines for `MapPolyline` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- `MapPolyline` instances ignore alpha color settings and will appear fully opaque. <!-- IOTSDK-5364 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->
- `RoutingEngine`: The route import feature via a list of `Locations` cannot be used yet commercially and requires custom access credentials. Please contact your sales representative to get access. <!-- IOTSDK-12285 -->

### Version 4.10.2.0

#### New Features

- Find traffic along a route: Added class `TrafficIncidentOnRoute` and method `Section.getTrafficIncidents()`. It represents traffic incidents on the route that are relevant for the section. <!-- IOTSDK-12198 -->
- The `RoutingEngine` is now able to provide routes that contain altitude values along the route. <!-- IOTSDK-8226 -->
- Added support for project scopes: With the new `AndroidManifest` meta-data option to specify a `com.here.sdk.access_scope` an app can set the HRN value as defined by your project ID. Each app belongs to at least one or multiple projects. A possible use case can be to define a _debugScope_. See `SDKOptions` and the [IAM Guide](https://developer.here.com/documentation/identity-access-management/dev_guide/topics/manage-projects.html#create-a-project) for more details. <!-- IOTSDK-12107 -->
- Added `isTruckLight` flag to `TruckSpecifications`. It indicates that the truck can be classified as a car and that it is therefore excluded from legal restrictions (such as truck speed limits) for normal trucks when calculating the route. Note that specifications such as the physical dimensions, cargo, and others, are still taken into account. <!-- IOTSDK-12199 -->

#### API Changes

- Deprecated `sdk.routing.EVConsumptionModel(ascentConsumptionInWattHoursPerMeter, descentRecoveryInWattHoursPerMeter, freeFlowSpeedTable, trafficSpeedTable, auxiliaryConsumptionInWattHoursPerSecond)` constructor. Use one of the other constructors instead. <!-- IOTSDK-12269 -->
- Deprecated `sdk.routing.TransitRouteOptions(departureTime, arrivalTime, alternatives, changes, modeFilter, modes, pedestrianSpeedInMetersPerSecond, pedestrianMaxDistanceInMeters, textOptions)` constructor. Use one of the other constructors instead. <!-- IOTSDK-12269 -->
- Deprecated `sdk.routing.AvoidanceOptions(roadFeatures, countries, avoidAreas, zoneCategories, segments)` constructor. Use one of the other constructors instead. <!-- IOTSDK-12269 -->
- Deprecated `FarePrice.validityPeriodInSeconds`. Use `FarePrice.validityPeriod` instead. Deprecated `FarePrice` constructor with parameters. Use the default constructor instead. <!-- IOTSDK-10084 -->
- Deprecated `AuthenticationData.expiryTimeInSeconds`. Use `AuthenticationData.expiryTime` instead. Deprecated `AuthenticationData` constructor with parameters. Use the default constructor instead. <!-- IOTSDK-10084 -->
- Deprecated `sdk.routing.PedestrianOptions(routeOptions, textOptions, avoidanceOptions, walkSpeedInMetersPerSecond)` constructor. Use one of the other constructors instead. <!-- IOTSDK-12269 -->
- Deprecated `sdk.routing.TransitSectionDetails(transport, intermediateStops, agency, attributions, fares, incidents)` constructor. Use one of the other constructors instead. <!-- IOTSDK-12269 -->
- Deprecated `sdk.routing.RouteTextOptions(language, instructionFormat, unitSystem)` constructor. Use one of the other constructors instead. <!-- IOTSDK-12269 -->
- Deprecated `sdk.routing.FarePrice(type, estimated, currency, validityPeriodInSeconds, minimum, maximum)` constructor. Use one of the other constructors instead. <!-- IOTSDK-12269 -->
- Deprecated `sdk.routing.ScooterOptions(routeOptions, textOptions, avoidanceOptions, allowHighway)` constructor. Use one of the other constructors instead. <!-- IOTSDK-12269 -->

#### Known Issues

- Outlines for `MapPolyline` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- `MapPolyline` instances ignore alpha color settings and will appear fully opaque. <!-- IOTSDK-5267 -->
- Transparency for `MapPolylines` is not supported. <!-- IOTSDK-5364 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->
- `RoutingEngine`: The route import feature via a list of `Locations` cannot be used yet commercially and requires custom access credentials. Please contact your sales representative to get access. <!-- IOTSDK-12285 -->

### Version 4.10.1.0

#### New Features

- Routing: Route calculations can now be canceled via the returned `TaskHandle` when calling `calculateRoute()` or related methods on engines such as the `RoutingEngine`. <!-- IOTSDK-9898 -->
- BYOD: Extended `GeoPlace` to hold more information: Added `ExternalID`, `LocationDetails`, `WebDetails`, `BusinessDetails`. <!-- IOTSDK-11379 -->
- Added `matchSideOfStreet` property to `Waypoint` class. It specifies how the location set by `sideOfStreetHint` should be handled when reaching a destination. <!-- IOTSDK-12104 -->
- Added global `ParameterConfiguration` that holds default values for HERE SDK features. For now, this allows to specify a `walkingSpeedInMetersPerSecond` to define a default pedestrian movement. Added `TransitRouteOptions.fromDefaultParameterConfiguration()` and `PedestrianOptions.fromDefaultParameterConfiguration()` that allow to create `TransitRouteOptions` and `PedestrianOptions` that will use the values set via `ParameterConfiguration`. The created options can then be used as usual for route calculation. Note that this is a beta feature. <!-- IOTSDK-11021 -->
- Added a new `TrafficEngine` that allows querying for current traffic incidents. Check the _Traffic_ example app to see how it works. The `TrafficEngine` supports querying for traffic incidents in a bounding box, a circle, or a corridor. Querying for the exact traffic incident by ID. Traffic incidents can contain an incident type, an incident impact, an incident location (currently, a polyline with length), incident codes, an active time range, localized by the queried language description and summary, relevant vehicle restrictions, and more. It supports representations of traffic incident vehicle restrictions as a set of restricted vehicle properties of some vehicle category and filtering queried incidents by an incident type, an incident impact and an active time range. <!-- IOTSDK-10974 -->
- Added `RouteOptions.occupantsNumber`: An option reflecting the number of occupants in a vehicle. Supported for `CAR` and `TRUCK` transport modes. When it is higher than 1 it affects a vehicles ability to use HOV/carpool lanes. Defaults to 1. <!-- IOTSDK-8702 -->
- Extended `MapSurface` constructor to add `MapViewOptions` to support `MapProjection.GLOBE` and `MapProjection.WEB_MERCATOR` projections. <!-- IOTSDK-12083 -->

#### API Changes

- Changed type of `RefreshRouteOptions` constructor parameter from `sdk.routing.TransportMode` to `sdk.transport.TransportMode`. <!-- IOTSDK-11015 -->
- Routing: Deprecated `EVConsumptionModel(ascentConsumptionInWattHoursPerMeter, descentRecoveryInWattHoursPerMeter, freeFlowSpeedTable, trafficSpeedTable, auxiliaryConsumptionInWattHoursPerSecond)` constructor. Use the default constructor instead. <!-- IOTSDK-12269 -->
- Search: Deprecated `SearchOptions` constructor that takes all parameters. Please use the default constructor instead. <!-- IOTSDK-10988 -->
- Search: Deprecated `Address` constructor that takes all parameters. Please use the default constructor instead. <!-- IOTSDK-10988 -->
- Routing: Deprecated `TransitRouteOptions(departureTime, arrivalTime, alternatives, changes, modeFilter, modes, pedestrianSpeedInMetersPerSecond, pedestrianMaxDistanceInMeters, textOptions)` constructor. Use the default constructor instead. <!-- IOTSDK-12269 -->
- Deprecated `EVCarOptions` constructor with all parameters. Use the default constructor instead. <!-- IOTSDK-10988 -->
- Deprecated `Route.transportMode`. Use the newly introduced `Route.requestedTransportMode` instead. <!-- IOTSDK-11015 -->
- Routing: Deprecated `AvoidanceOptions(roadFeatures, countries, avoidAreas, zoneCategories, segments)` constructor. Use the default constructor instead. <!-- IOTSDK-12269 -->
- Deprecated `CarOptions` constructor with all parameters. Use the default constructor instead. <!-- IOTSDK-10988 -->
- Routing: Deprecated a route's `Link`. Use `Span` instead. <!-- IOTSDK-12048 -->
- Routing: Deprecated `PedestrianOptions(routeOptions, textOptions, avoidanceOptions, walkSpeedInMetersPerSecond)` constructor. Use the default constructor instead. <!-- IOTSDK-12269 -->
- Routing: Deprecated `TransitWaypoint` constructor that takes all parameters. Please use the default constructor instead. <!-- IOTSDK-10988 -->
- Routing: Deprecated `TransitSectionDetails(transport, intermediateStops, agency, attributions, fares, incidents)` constructor. Use the default constructor instead. <!-- IOTSDK-12269 -->
- Deprecated `TruckOptions` constructor with all parameters. Use the default constructor instead. <!-- IOTSDK-10988 -->
- Routing: Deprecated `RouteTextOptions(language, instructionFormat, unitSystem)` constructor. Use the default constructor instead. <!-- IOTSDK-12269 -->
- Deprecated `EVTruckOptions` constructor with all parameters. Use the default constructor instead. <!-- IOTSDK-10988 -->
- Deprecated `sdk.routing.TransportMode` enum. Use the newly introduced 'sdk.transport.TransportMode' instead. <!-- IOTSDK-11015 -->
- Routing: Deprecated `FarePrice(type, estimated, currency, validityPeriodInSeconds, minimum, maximum)` constructor. Use the default constructor instead. <!-- IOTSDK-12269 -->
- Routing: Deprecated `ScooterOptions(routeOptions, textOptions, avoidanceOptions, allowHighway)` constructor. Use the default constructor instead. <!-- IOTSDK-12269 -->

#### Resolved Issues

- Fixed: The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 --> <!-- HARP-8095 -->
- Fixed: Updating an existing `MapMarker` with a completely new image causes the marker to disappear for a brief moment before being drawn with the new image. <!-- IOTSDK-7197 --> <!-- IOTSDK-7197 -->
- Fixed: When `cachePath` and `persistentMapStoragePath` are changed via `SDKOptions`, then it may not change the default path. <!-- IOTSDK-11974 --> <!-- IOTSDK-11974 -->
- Fixed: Truck routes that are imported via `importRoute()` may be result in a `RoutingError.NO_ROUTE_FOUND` error as certain truck restrictions may be violated along the road. This is incorrect and instead the resulting route should contain the violated restrictions as part of the route's `SectionNotice`. <!-- IOTSDK-11864 --> <!-- IOTSDK-11864 -->
- Fixed a crash when `MapCameraAnimationFactory.createAnimation(MapCameraUpdate, Duration, EasingFunction)` was called. <!-- IOTSDK-12142 -->

#### Known Issues

- Outlines for `MapPolyline` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 --> <!-- HARP-15072 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 --> <!-- IOTSDK-7368 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 --> <!-- IOTSDK-7051 -->
- `MapPolyline` instances ignore alpha color settings and will appear fully opaque. <!-- IOTSDK-5267 --> <!-- IOTSDK-5267 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 --> <!-- IOTSDK-5364 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 --> <!-- IOTSDK-8521 -->
- `RoutingEngine`: The route import feature via a list of `Locations` cannot be used yet commercially and requires custom access credentials. Please contact your sales representative to get access. <!-- IOTSDK-12285 --> <!-- IOTSDK-12285 -->

### Version 4.10.0.0

#### New Features

- `MapView`: Added support for Mercator projection when a `MapView` is created programmatically. Note that for a future HERE SDK release it is planned to allow this also for `MapView` instances that are created from a layout file. Added `MapViewOptions` and `MapProjection` that allow to specify the map projection. Examples:
 - `mapView = new MapView(context, new MapViewOptions(MapProjection.GLOBE))`
 - `mapView = new MapView(context, new MapViewOptions(MapProjection.WEB_MERCATOR))` <!-- IOTSDK-8924 -->
- Added `MapContext` class and added `getMapContext()` method to `MapView`. A `MapContext` is needed when custom data sources for map tiles should be created, such as the new `RasterDataSource` to support custom raster layers on a `MapView`. <!-- IOTSDK-11464 -->
- `MapView`: Added support custom raster layers that can be shown as tile overlay on top of the map. Note: This is a beta release of this feature, so there could be a few bugs and unexpected behaviors. Related APIs may change for new releases without a deprecation process. The following classes have been added to support custom raster layers:
 - Added `RasterDataSourceFactory` which is used to create `RasterDataSource`
objects.
 - Added `RasterDataSource` which represents the source of raster tile data to
display. It also allows changing its configuration.
 - Added `RasterDataSourceConfiguration` which is used to specify a configuration
for the data source, including URL, tiling scheme, storage levels and caching
parameters.
 - Added `TilingScheme` enum which specifies how the tile data has to be interpreted.
 - Added `RasterDataSourceListener` interface which can be used to receive
notifications from the `RasterDataSource`.
 - Added `MapLayer` class which represents a renderable map overlay and controls
its visibility.
 - Added `MapLayerBuilder` which is used to create `MapLayer` objects.
 - Added `MapLayerPriority` which specifies the order of drawing a map layer.
 - Added `MapLayerVisibilityRange` which specifies at which zoom levels the map
layer will become visible.
 - Added `MapContentType` which specifies the type of data shown by the `MapLayer`. <!-- IOTSDK-12029 -->
- Added `HereMap` class. Added `getHereMap()` method to `MapView`. `HereMap` is used to initialize a `MapLayer` that can be used with a `MapLayerBuilder` to support custom raster layers. <!-- IOTSDK-11464 -->
- Import routes: Added `RouteHandle​(String handle)` constructor that allows to create a `RouteHandle` from a given string handle. Such a string can be provided from other backend sources such as HERE REST APIs and it is valid for a couple of hours. The string encodes a calculated route and it can be used to import this route via the newly added method `importRoute​(@NonNull RouteHandle routeHandle, @NonNull RefreshRouteOptions refreshRouteOptions, @NonNull CalculateRouteCallback callback)` of the `RoutingEngine` for further use with the HERE SDK. Note: This is a beta release of this feature. <!-- IOTSDK-10242 -->
- Search: Added a default constructor for `Address`. <!-- IOTSDK-10988 -->

#### API Changes

- Removed the previously deprecated classes `MapCamera.Orientation`, `MapCamera.OrientationUpdate`, `MapCamera.State.targetOrientation` and all methods using them. Use instead the new methods that use the new classes `GeoOrientation`, `GeoOrientationUpdate` and `MapCamera.State.orientationAtTarget`. For example, instead of the removed method `MapCamera.lookAt(GeoCoordinates target, MapCamera.OrientationUpdate orientation, double distanceInMeters)` use now `MapCamera.lookAt(GeoCoordinates target, GeoOrientationUpdate orientation, double distanceInMeters)`. <!-- IOTSDK-10619 -->
- Removed the previously deprecated `GeoCorridor.radiusInMeters` property. Use the new property `GeoCorridor.halfWidthInMeters` instead. <!-- IOTSDK-10069 -->
- Removed the previously deprecated `FarePrice.unit` property. Use instead the `FarePrice.validityPeriodInSeconds` property. <!-- IOTSDK-10004 -->
- Removed the previously deprecated `Agency.icon` property. This feature is no longer supported. <!-- IOTSDK-9980 -->
- Replaced usage of `java.time.Duration` with `com.here.time.Duration` across the HERE SDK. This ensures that the HERE SDK stays compatible with Android API level 21. Note that `com.here.time.Duration` is a subset of `java.time.Duration` and behaves identically. <!-- IOTSDK-1453 -->
- Deprecated the method `MapScene.setLayerState(String layerName, MapScene.LayerState newState)`. Use the new method `MapScene.setLayerVisibility(String layerName, VisibilityState visibility)` instead. Deprecated the enum `MapSceneLayerState`. Use the enum `VisibilityState` instead.
Deprecated the enum `MapScene.LayerState`. Use the enum `VisibilityState` instead. <!-- IOTSDK-11526 -->

#### Resolved Issues

- Routing: It is now possible to set a stop duration for each waypoint so that a better overal ETA can be given. Added 'durationInSeconds' property to `Waypoint`. It defaults to 0. Note that it will be ignored for pass-through waypoints. <!-- IOTSDK-9800 -->
- Fixed: `MapViewLifecycleListener.onAttach()` is now called once `MapView` has been fully initialized. <!-- IOTSDK-11619 -->

#### Known Issues

- Updating an existing `MapMarker` with a completely new image causes the marker to disappear for a brief moment before being drawn with the new image. <!-- IOTSDK-7197 -->
- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->
- Outlines for `MapPolyine` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->
- Truck routes that are imported via `importRoute()` may be result in a `RoutingError.NO_ROUTE_FOUND` error as certain truck restrictions may be violated along the road. This is incorrect and instead the resulting route should contain the violated restrictions as part of the route's `SectionNotice`. <!-- IOTSDK-11864 -->
- When `cachePath` and `persistentMapStoragePath` are changed via `SDKOptions`, then it may not change the default path. <!-- IOTSDK-11974 -->

### Version 4.9.4.0

#### New Features

- Routing: Added support for bicycles. Now it is possible to create bicycle routes online with the `RoutingEngine` using `BicycleOptions`. Added also `TransportMode.bicycle`. <!-- IOTSDK-11555 -->
- Routing: Added optional field `nameHint` to `Waypoint`. For cases when there are multiple places at the same geographic coordinate, this hint can help the `RoutingEngine` to find the expected place. For example, "North" can be set to differentiate between interstates "I66 North" and "I66 South". <!-- IOTSDK-8696 -->
- Routing: It's now possible to set `TaxiOptions.allowDriveThroughTaxiRoads`. It allows to calculate routes that make use of roads and lanes that are reserved for taxis. <!-- IOTSDK-11771 -->

#### Known Issues

- Updating an existing `MapMarker` with a completely new image causes the marker to disappear for a brief moment before being drawn with the new image. <!-- IOTSDK-7197 -->
- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->
- Outlines for `MapPolyine` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->
- Truck routes that are imported via `importRoute()` may be result in a `RoutingError.NO_ROUTE_FOUND` error as certain truck restrictions may be violated along the road. This is incorrect and instead the resulting route should contain the violated restrictions as part of the route's `SectionNotice`. <!-- IOTSDK-11864 -->

### Version 4.9.3.0

#### Resolved Issues

- Fixed: Picking map features such as embedded POIs and map items via `mapView.pickMapItems` and `mapView.pickMapFeatures` is currently not possible at the same time. <!-- IOTSDK-11622 -->
- Fixed `enterHigway` maneuver action which was incorrectly reported as _turn left / right_ instead of _left / right fork_. <!-- IOTSDK-11628 -->
- Fixed: The traffic layers `MapScene.Layers.TRAFFIC_FLOW` and `MapScene.Layers.TRAFFIC_INCIDENTS` may not be instantly visible when starting an app for the first time. <!-- IOTSDK-11335 -->
- Fixed: Setting the map layer `VEHICLE_RESTRICTIONS` is currently ignored and the layer is not visible. <!-- OLPSUP-16401 -->

#### Known Issues

- Updating an existing `MapMarker` with a completely new image causes the marker to disappear for a brief moment before being drawn with the new image. <!-- IOTSDK-7197 -->
- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->
- Outlines for `MapPolyine` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->

### Version 4.9.2.0

#### New Features

- Added `LocationIndicator.updateLocation(Location location, MapCameraUpdate cameraUpdate)` to update the location of the indicator and the target coordinates of the `MapView` at the same time - for example, when tracking the user's location. <!-- IOTSDK-11282 -->
- Offline Routing: Enabled a property for `RouteOptions` that allows to set an upper limit of the driving speed of a vehicle: `speedCapInMetersPerSecond` is available for car and truck transport modes. It can affect route path and ETA. Note that this property was already available for online routing. <!-- IOTSDK-9530 -->
- Added a feature to observe when a `MapCamera` animation or `flyTo()`-call has been completed: Added `AnimationListener` interface, `AnimationState` enumeration and `MapCamera.startAnimation()`. <!-- IOTSDK-11207 -->
- Added a feature to pick embedded Carto POIs. By default, embedded POIs are visible on the map and they can be picked now via `mapView.pickMapFeatures()` to get a `PickMapFeaturesResult` that contains a `PoiResult`. Check the Developer Guide for a usage example. <!-- IOTSDK-3882 -->
- Added a convenience feature to tie a `LocationIndicator` directly to the `MapView`'s life cycle'. For example, be calling the new `enable()` method, the `LocationIndicator` is visible on the map. This has the same affect as when calling `mapView.addLifecycleDelegate(locationIndicator)`. Added constructor `LocationIndicator(@NonNull final MapViewBase mapView)`, added methods `LocationIndicator.enable(@NonNull final MapViewBase mapView)`, `LocationIndicator.disable()` <!-- IOTSDK-10205 -->
- `MapMarkerCluster` items can now be picked - and when picking other map items, clustered markers are _no longer_ returned via `pickMapItemsResult.getMarkers()`. Instead, call the new `pickMapItemsResult.getClusteredMarkers()` method. See the `MapItems` example app and the Developer Guide for a usage example. <!-- IOTSDK-10206 -->

#### Known Issues

- Updating an existing `MapMarker` with a completely new image causes the marker to disappear for a brief moment before being drawn with the new image. <!-- IOTSDK-7197 -->
- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->
- The traffic layers `MapScene.Layers.TRAFFIC_FLOW` and `MapScene.Layers.TRAFFIC_INCIDENTS` may not be instantly visible when starting an app for the first time. <!-- IOTSDK-11335 -->
- Outlines for `MapPolyine` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->
- Setting the map layer `VEHICLE_RESTRICTIONS` is currently ignored and the layer is not visible. <!-- OLPSUP-16401 -->
- Picking map features such as embedded POIs and map items via `mapView.pickMapItems` and `mapView.pickMapFeatures` is currently not possible at the same time. <!-- IOTSDK-11622 -->

### Version 4.9.1.0

#### New Features

- Added `removeMapMarkers()` method to `MapScene` class. It removes multiple map markers in a batch call. <!-- IOTSDK-5669 -->

#### API Changes

- Removed deprecated tag for `PERSISTENT_MAP_STORAGE_FOLDER_ACCESS_DENIED`. `PERSISTENT_MAP_STORAGE_FOLDER_ACCESS_DENIED` is not deprecated anymore. <!-- IOTSDK-9753 -->
- Deprecated `MapCamera.FlyToOptions.durationInMs`, use `MapCamera.FlyToOptions.duration` instead. <!-- IOTSDK-10922 -->

#### Resolved Issues

- Fixed: Route imports no longer fail when `Location.time` is set. <!-- IOTSDK-11353 -->
- Fixed a short pink screen, that can appear before the first display of a `MapView`. <!-- HARP-16927 -->

#### Known Issues

- Updating an existing `MapMarker` with a completely new image causes the marker to disappear for a brief moment before being drawn with the new image. <!-- IOTSDK-7197 -->
- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->
- `MapMarkerCluster` groups are not directly pickable yet. As a workaround, overlapping markers can be identified by setting a unique `Metadata` key to the contained `MapMarker` items of a cluster. See the _MapItems_ app for an example. <!-- IOTSDK-10206 -->
- The traffic layers `MapScene.Layers.TRAFFIC_FLOW` and `MapScene.Layers.TRAFFIC_INCIDENTS` may not be instantly visible when starting an app for the first time. <!-- IOTSDK-11335 -->
- Outlines for `MapPolyine` lines can show a minimal gap at certain zoom levels. As a workaround use a round `LineCap` style. <!-- HARP-15072 -->
- Setting the map layer `VEHICLE_RESTRICTIONS` is currently ignored and the layer is not visible. <!-- OLPSUP-16401 -->

### Version 4.9.0.0

#### New Features

- Added new animation features to `MapCamera` with `startAnimation(MapCameraAnimation)`, `EasingFunction` and `KeyframeInterpolationMode`. Added related classes `GeoCoordinatesKeyframe`, `GeoOrientationKeyframe`, `Point2DKeyframe`, `ScalarKeyframe`, `MapCameraAnimation`, `MapCameraAnimationFactory` and `MapCameraKeyframeTrack`. <!-- IOTSDK-10983 -->
- Routes can now be imported: Added `routingEngine.importRoute()` to import a route from a list of `GeoCoordinates` and `RouteOptions`. <!-- IOTSDK-10954 -->
- Added support for map marker clustering with the new classes `MapMarkerCluster` and `MapMarkerCluster.ImageStyle`. A marker cluster can be added/removed with `MapScene.addMapMarkerCluster()/MapScene.emoveMapMarkerCluster`. See the _MapItems_ example app for a usage example. <!-- IOTSDK-9109 -->
- Added optional field `time` to `Location` class to specify the time when the location data was set. <!-- IOTSDK-10954 -->
- Batch support for `MapMarker`: Added method to add multiple `MapMarker` items at once. With `mapScene.addMapMarkers()` a list of `MapMarker` items can be added to a `MapScene` with a single batch call. <!-- IOTSDK-9884 -->
- Search: Added `PlaceType.INTERSECTION` to indicate an intersection of at least two streets. Note: This is a beta feature. <!-- IOTSDK-9900 -->

#### API Changes

- Removed the previously deprecated constructor in `Location` class. Use one of the other available contructors instead. <!-- IOTSDK-10954 -->
- Removed the previously deprecated `MapRepresentable` interface and `addMapRepresentable` and `removeMapRepresentable` methods from `MapView` and `MapSurface`. Use the `MapViewLifecycleListener` instead. <!-- IOTSDK-9302 -->
- Map schemes: Removed the previously deprecated scene configuration files: "legacy.grey.day.json", "legacy.grey.night.json", "legacy.hybrid.day.json", "legacy.hybrid.night.json", "legacy.normal.day.json", "legacy.normal.night.json". Use the related `MapSchemes` instead. <!-- IOTSDK-9941 -->
- Removed the previously deprecated `Notice` class, `NoticeCode` enum and `Section.getNotices()` method. Use `SectionNoticeCode`, `SectionNotice` class and `Section.getSectionNotices()` method instead. <!-- IOTSDK-10102 -->
- Search: Removed the following fields from `Address` class that have been previously deprecated: `stateName`, `countyName`, `streetName`, `additionalData`. Please use `state`, `county` and `street` instead. The field `additionalData` was already unused. <!-- IOTSDK-8376 -->
- Search: Removed the perviously deprecated `OPTION_NOT_AVAILABLE` value from the `SearchError` enum. It was replaced by the `SearchError.INVALID_PARAMETER` value. <!-- IOTSDK-9403 -->
- Removed the previously deprecated `GREY_DAY` and `GREY_NIGHT` from `MapScheme` enum. Use the _normal_ map scheme variants instead. <!-- IOTSDK-9940 -->
- Deprecated field `timestamp` in `Location` class, please use the newly introduced `time` field instead. <!-- IOTSDK-10954 -->

#### Resolved Issues

- Fixed Chinese fonts that have been displayed accidentially for Japan labels. <!-- OLPSUP-16144 -->
- Fixed: Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->

#### Known Issues

- Updating an existing `MapMarker` with a completely new image causes the marker to disappear for a brief moment before being drawn with the new image. <!-- IOTSDK-7197 -->
- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->
- `MapMarkerCluster` groups are not directly pickable yet. As a workaround, overlapping markers can be identified by setting a unique `Metadata` key to the contained `MapMarker` items of a cluster. See the _MapItems_ app for an example. <!-- IOTSDK-10206 -->
- The traffic layers `MapScene.Layers.TRAFFIC_FLOW` and `MapScene.Layers.TRAFFIC_INCIDENTS` may not be instantly visible when starting an app for the first time. <!-- IOTSDK-11335 -->

### Version 4.8.4.0

#### New Features

- Routing: Added `getDurationInSeconds` method to the `Maneuver` class to get the estimated duration of a maneuver. <!-- IOTSDK-10997 -->
- Added new factory method for [DMS](https://gisgeography.com/decimal-degrees-dd-minutes-seconds-dms/) and decimal `GeoCoordinates` to convert one into the other with `GeoCoordinates.fromString()`. <!-- IOTSDK-10260 -->
- Added support for [Android Auto](https://www.android.com/intl/de_de/auto/). Now it's possible to render the `MapView` onto a provided surface with the newly added class `MapSurface`. <!-- IOTSDK-10990 -->
- Search: Added `ResponseDetails` as result type that provides the `requestId` of a search request and a `correlationId` to identify multiple, related queries. <!-- IOTSDK-10420 -->
- Routing: Added a static `fromString` method to `SegmentReference` to generate instances of this class from a well-formatted String. Usually, `SegmentReference` instances are only accessible from the `Span` of a `Route`'s `Segment`. <!-- IOTSDK-10805 -->

#### API Changes

- Routing: For the new toll cost API, now the newly added `RouteOptions.enableTolls` flag must be set to get toll costs. It is set to `false` by default. When this flag is enabled, toll data is requested for toll applicable transport modes. <!-- IOTSDK-11004 -->

#### Known Issues

- Updating an existing `MapMarker` with a completely new image causes the marker to disappear for a brief moment before being drawn with the new image. <!-- IOTSDK-7197 -->
- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.8.3.0

#### New Features

- Public transit routes: Added support for new `PEDESTRIAN` sections to provide better information on in-station walks, for example, when walking from a place of type `ACCESS_POINT` type to a place of type `STATION`. <!-- IOTSDK-10927 -->
- Routing: Added `RouteOptions.enableTrafficOptimization` field which is true by default, and when set to false, it doesn't consider traffic information and ignores `RouteOptions.departureTime`. <!-- IOTSDK-9976 -->
- Routing: It's now possible to avoid individual segments on a `Route`. With the newly added `segments` field in `AvoidanceOptions` users can specify the parts of a route they would like to avoid after a recalculation. The segments can be identified via `Route -> Section -> Span -> SegmentReference`.
  - Added `SegmentReference` class that represents a reference to a segment id with a travel direction.
  - Added `getSegmentReference` method to the `Span` class.
  - Added `TravelDirection` enum that indicates the travel direction along a segment.
- Added enhanced APIs to control the `MapCamera` with the new classes `MapCameraUpdate`, `MapCameraUpdateFactory` and `MapMeasure`. Added the `applyUpdate` method to `MapCamera` that accepts a `MapCameraUpdate` as parameter.
- Added `VIOLATED_AVOID_SEASONAL_CLOSURE`, `VIOLATED_AVOID_TOLL_TRANSPONDER`, `SEASONAL_CLOSURE`, `TOLL_TRANSPONDER`, `TOLLS_DATA_UNAVAILABLE` and `CHARGING_STOP_NOT_NEEDED` symbols to the `SectionNoticeCode` enum.

#### API Changes

- Transit routes no longer provide fare information and the `TransitSectionDetails.fares` list is always empty. <!-- IOTSDK-10950 -->
- Routing: Deprecated `SectionNoticeCode.VIOLATED_PEDESTRIAN_OPTION` symbol. It will be removed in v4.11.0 as it is no longer supported.
- Deprecated `PERSISTENT_MAP_STORAGE_FOLDER_ACCESS_DENIED` and `FAILED_TO_LOCK_PERSISTENT_MAP_STORAGE_FOLDER` values from the `InstantiationErrorCode` enum. The persistent storage directory is no longer locked.

#### Resolved Issues

- Fixed: It is not possible to set both `RouteOptions.departureTime` and `RouteOptions.arrivalTime` at the same time. Plus, `RouteOptions.arrivalTime` is ignored when `RouteOptions.enableTrafficOptimization` is set to false. <!-- IOTSDK-9760 -->

#### Known Issues

- Updating an existing `MapMarker` with a completely new image causes the marker to disappear for a brief moment before being drawn with the new image. <!-- IOTSDK-7197 -->
- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.8.2.0

#### New Features

- Improved search for electric vehicle charging stations: Added classes `EVChargingPool` and `EVChargingStation`. A charging pool for electric vehicles is an area equipped with one or more charging stations. A charging station defines a group of connectors for electrical vehicles that share a common charging connector type and max power level. Note: This is a beta feature. <!-- IOTSDK-10800 -->
- Improved search for electric vehicle charging stations: Added property `Details.evChargingPool` that represents the details of the charging pool for electric vehicles. Note: This is a beta feature. <!-- IOTSDK-10810 -->
- Routing: Added information on toll costs with a new `PaymentMethod` enum, `TollFare` & `Toll` classes and `Section.getTolls()` method. Note: This is a beta feature. <!-- IOTSDK-10617 -->

#### Resolved Issues

- Fixed: In rare cases, `Storage.LevelDB` related crashes can occur when starting the app. <!-- IOTSDK-10512 -->

#### Known Issues

- Updating an existing `MapMarker` with a completely new image causes the marker to disappear for a brief moment before being drawn with the new image. <!-- IOTSDK-7197 -->
- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.8.1.0

#### New Features

- Routing: Added `NoRouteHandle` enum value to `RoutingError` to indicate that the route did not contain the required `RouteHandle`, which is needed, for example, to refresh a route.
- Search: Added new `name` property to `PlaceCategory` that provides a level 3 description.

#### Known Issues

- Updating an existing `MapMarker` with a completely new image causes the marker to disappear for a brief moment before being drawn with the new image. <!-- IOTSDK-7197 -->
- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->
- In rare cases, `Storage.LevelDB` related crashes can occur when starting the app. <!-- IOTSDK-10512 -->

### Version 4.8.0.0

#### API Changes

- Deprecated `MapCamera.Orientation` - replaced with `GeoOrientation`.
- Deprecated `MapCamera.OrientationUpdate`  - replaced with `GeoOrientationUpdate`.
- Deprecated `MapCamera.State.targetOrientation` - replaced with `MapCamera.State.orientationAtTarget`.
- Deprecated `MapCamera.flyTo(GeoCoordinates target, MapCamera.OrientationUpdate orientation, double distanceInMeters, MapCamera.FlyToOptions animationOptions)`  - replaced with `MapCamera.flyTo(GeoCoordinates target, GeoOrientationUpdate orientation, MapCamera.FlyToOptions animationOptions)`.
- Deprecated `MapCamera.flyTo(GeoCoordinates target, MapCamera.OrientationUpdate orientation, MapCamera.FlyToOptions animationOptions)`  - replaced with `MapCamera.flyTo(GeoCoordinates target, MapCamera.OrientationUpdate orientation, MapCamera.FlyToOptions animationOptions)`.
- Deprecated `MapCamera.flyTo(GeoCoordinates target, MapCamera.OrientationUpdate orientation, MapCamera.FlyToOptions animationOptions)` - replaced with M`apCamera.lookAt(GeoBox target, GeoOrientationUpdate orientation)`.
- Deprecated `MapCamera.lookAt(GeoCoordinates target, MapCamera.OrientationUpdate orientation, double distanceInMeters)` - replaced with `MapCamera.lookAt(GeoCoordinates target, MapCamera.OrientationUpdate orientation, double distanceInMeters)`.
- Deprecated `MapCamera.orbitBy(MapCamera.OrientationUpdate delta, Point2D origin)` - replaced with `MapCamera.orbitBy(GeoOrientationUpdate delta, Point2D origin)`.
- Deprecated `MapCamera.setTargetOrientation(MapCamera.OrientationUpdate orientation)` - replaced with `MapCamera.setOrientationAtTarget(GeoOrientationUpdate orientation)`.
- Deprecated `MapCamera.setOrientationAtTarget(GeoOrientationUpdate orientation)` - replaced with `MapCamera.lookAt(GeoBox target, GeoOrientationUpdate orientation, Rectangle2D viewRectangle)`.
- Removed the previously deprecated `updateGeometry()` methid from `MapPolyline` and `MapPolygon`.
- Search: Removed previously deprecated fields in `Contact`: `emailAddresses`, `landlinePhoneNumbers`, `mobilePhoneNumbers`, `websiteAddresses`.
- Routing: Removed the previously deprecated `Arrival` and `Departure` classes.

#### Known Issues

- Updating an existing `MapMarker` with a completely new image causes the marker to disappear for a brief moment before being drawn with the new image. <!-- IOTSDK-7197 -->
- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->
- In rare cases, `Storage.LevelDB` related crashes can occur when starting the app. <!-- IOTSDK-10512 -->

### Version 4.7.7.0

#### New Features

- Search: Added `politicalView` member to `Place` class. The optional value can be checked if it is matching the one that was set beforehand via `SDKOptions`.

#### API Changes

- The map styles for `NORMAL_DAY`, `NORMAL_NIGHT`, `HYBRID_DAY` and `HYBRID_NIGHT` have been updated to the ones that have been made available as `preview` beforehand. The new map styles feature a clean and neutral base map and a street network with improved gray scales that allow a better hierarchy of elements that can be added on top.
- `MapView`: "Simplified Chinese", "Traditional Taiwan" and "Traditional Hong Kong" language labels are now supported.
- Routing: Updated the API for the _returnToRoute_ and _refreshRoute_ feature for `RoutingEngine`:
  - Changed the parameter order of `RoutingInterface.returnToRoute()`: The `startingPoint` parameter is now the second parameter, not the third parameter. The feature is still in beta.
  - Added a `startingPoint` parameter to the `RoutingEngine.refreshRoute()` method. In return, deleted `RefreshRouteOptions.updateStartingPoint()`. The feature is still in beta.
  - Deleted the ReturnToRouteEngine. Use the newly introduced `RoutingInterface.returnToRoute()` method instead.

#### Resolved Issues

- Fixed: A `Maneuver.polyline` list of `GeoCoordinates` has only one element for the last maneuver of a route. <!-- IOTSDK-6955 -->
- Fixed: When `MapMarker.setOverlapAllowed()` is set to false and the map is zoomed, this can lead to a flickering of the marker assets. <!-- IOTSDK-9885 -->

#### Known Issues

- Updating an existing `MapMarker` with a completely new image causes the marker to disappear for a brief moment before being drawn with the new image. <!-- IOTSDK-7197 -->
- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->
- In rare cases, when an app is started a cache lock error indicated by `InstantiationErrorCode.FAILED_TO_LOCK_CACHE_FOLDER` or `InstantiationErrorCode.FAILED_TO_LOCK_PERSISTENT_MAP_STORAGE_FOLDER` can happen when another app process is locking the map cache. At the moment, this can only be resolved by reinstalling the app or by calling `InitProvider.destroyLockingProcess(sdkOptions, timeoutInMs)` before initializing the HERE SDK. <!-- IOTSDK-8997 -->

### Version 4.7.6.0

#### New Features

- Improved map rendering performance on low end devices. <!-- IOTSDK-8666 -->

#### Known Issues

- Updating an existing `MapMarker` with a completely new image causes the marker to disappear for a brief moment before being drawn with the new image. <!-- IOTSDK-7197 -->
- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- A `Maneuver.polyline` list of `GeoCoordinates` has only one element for the last maneuver of a route. <!-- IOTSDK-6955 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->
- When `MapMarker.setOverlapAllowed()` is set to false and the map is zoomed, this can lead to a flickering of the marker assets. <!-- IOTSDK-9885 -->
- In rare cases, when an app is started a cache lock error indicated by `InstantiationErrorCode.FAILED_TO_LOCK_CACHE_FOLDER` or `InstantiationErrorCode.FAILED_TO_LOCK_PERSISTENT_MAP_STORAGE_FOLDER` can happen when another app process is locking the map cache. At the moment, this can only be resolved by reinstalling the app or by calling `InitProvider.destroyLockingProcess(sdkOptions, timeoutInMs)` before initializing the HERE SDK. <!-- IOTSDK-8997 -->

### Version 4.7.5.0

#### New Features

- Routing: Added avoidance options for pedestrians with `PedestrianOptions.avoidanceOptions`.
- Search: Added support to search along _longer_ route polylines with a `GeoCorridor`. Either increase `halfWidthInMeters` when set via constructor or do not set it - by using the `GeoCorridor` constructor that only allows to set the `GeoPolyline`. The parameter `radiusInMeters` has been deprecated: Please only use `halfWidthInMeters` as constructor parameter to specify the thickness of the route corridor. When increasing `halfWidthInMeters` then a greater simplification of the polyline shape can be achieved resulting in a longer route that can be searched along. On the downside the results are less accurate and can lie farther away from the route. When `halfWidthInMeters` is not set, a suitable value is set internally based on "best guess".
- The `LocationIndicator` now supports a gray state that can be set via `LocationIndicator.isActive(boolean)`.

#### Known Issues

- Updating an existing `MapMarker` with a completely new image causes the marker to disappear for a brief moment before being drawn with the new image. <!-- IOTSDK-7197 -->
- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- A `Maneuver.polyline` list of `GeoCoordinates` has only one element for the last maneuver of a route. <!-- IOTSDK-6955 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->
- When `MapMarker.setOverlapAllowed()` is set to false and the map is zoomed, this can lead to a flickering of the marker assets. <!-- IOTSDK-9885 -->
- In rare cases, when an app is started a cache lock error indicated by `InstantiationErrorCode.FAILED_TO_LOCK_CACHE_FOLDER` or `InstantiationErrorCode.FAILED_TO_LOCK_PERSISTENT_MAP_STORAGE_FOLDER` can happen when another app process is locking the map cache. At the moment, this can only be resolved by reinstalling the app. <!-- IOTSDK-8997 -->

### Version 4.7.4.0

#### New Features

- Routing: Added `TruckType` enum to specify the type of a truck for the `TruckSpecifications`.
- Routing: Added `TruckSpecifications.trailerCount` to specify the number of trailers.
- Routing: Added `accessPoint` to `RoutePlaceType` enum. It allows to differentiate `Section`'s based on `RoutePlace.type`.
- Public transit: Added `FarePriceType` enum, `FarePrice.type`, `FarePrice.minimum` and `FarePrice.maximum` properties. `FarePrice` provides the actual price value.

#### API Changes

- Gestures: A finger down gesture stops now any ongoing animation including kinetic panning.
- Routing: Deprecated `FarePrice.unit`, use the newly introduced `FarePrice.validityPeriodInSeconds` property instead.
- Routing: Deprecated the unsupported `Agency.icon` property. This property is no longer supported and will be removed with HERE SDK release v4.10.0.

#### Known Issues

- Updating an existing `MapMarker` with a completely new image causes the marker to disappear for a brief moment before being drawn with the new image. <!-- IOTSDK-7197 -->
- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- A `Maneuver.polyline` list of `GeoCoordinates` has only one element for the last maneuver of a route. <!-- IOTSDK-6955 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->
- When `MapMarker.setOverlapAllowed()` is set to false and the map is zoomed, this can lead to a flickering of the marker assets. <!-- IOTSDK-9885 -->

### Version 4.7.3.0

#### New Features

- Routing: Added support for `EVCarOptions` and `EVTruckOptions` for the `RefreshRouteOptions` class.
- EV Routing: Added new parameters to `BatterySpecifications`:
  - `minChargeAtChargingStationInKilowattHours`: The minimum charge when arriving at a charging station.
  - `minChargeAtDestinationInKilowattHours`: The minimum charge at the final route destination.
  - `maxChargingVoltageInVolts`: The maximum charging voltage supported by the vehicle's battery.
  - `maxChargingCurrentInAmperes`: The maximum charging current supported by the vehicle's battery.
  - `chargingSetupDurationInSeconds`: The time spent after arriving at a charging station, but before actually charging.
- `SearchEngine`: For reverse geocoding it is now possible to search in a `GeoCircle` with `search(GeoCircle circle, SearchOptions options, SearchCallback callback)`.

#### Known Issues

- Updating an existing `MapMarker` with a completely new image causes the marker to disappear for a brief moment before being drawn with the new image. <!-- IOTSDK-7197 -->
- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- A `Maneuver.polyline` list of `GeoCoordinates` has only one element for the last maneuver of a route. <!-- IOTSDK-6955 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->
- When `MapMarker.setOverlapAllowed()` is set to false and the map is zoomed, this can lead to a flickering of the marker assets. <!-- IOTSDK-9885 -->

### Version 4.7.2.0

#### New Features

- Added a feature to refresh a `Route`: Added the `RouteOptions.enableRouteHandle` flag to get a `RouteHandle`, a `RefreshRouteOptions` class and a `RoutingEngine.refreshRoute()` method. Note that currently `EVRouteOptions` are not supported. See the related chapter in the Developer Guide for more information.
- `LocationIndicator`: Added a new style for _pedestrians_. The new style is added to `IndicatorStyle` and can be set to a `LocationIndicator` instance to switch the default 3D map marker model to indicate the current heading and location. Optionally, the style can be customized.
-  Added an option to affect FPS rendering of the map view by decreasing or increasing the frameRate with `MapView.get/setFrameRate()`. This can be useful to reduce CPU usage for low end devices. The default FPS is 60 frames per second. It is also possible to deactivate automatic render cycles by setting FPS to 0.

#### Resolved Issues

- Fixed: `MapMarker3D` instances are only partly rendered when the camera is positioned too far from earth. <!-- IOTSDK-7136 -->

#### Known Issues

- Updating an existing `MapMarker` with a completely new image causes the marker to disappear for a brief moment before being drawn with the new image. <!-- IOTSDK-7197 -->
- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- A `Maneuver.polyline` list of `GeoCoordinates` has only one element for the last maneuver of a route. <!-- IOTSDK-6955 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.7.1.0

#### Highlights

- Added a default 3D `LocationIndicator` to show the current location and travel direction of a user. It can be added to the map view with `MapView.addMapLifecycleListener()`. Update its location via `Mapview.updateLocation()` that accepts a `Location` as parameter. The look of the default asset can be customized by setting a `MapMarker3DModel` as parameter to `LocationIndicator.setMarker3dModel()`. You can also specify the `MarkerType`: In the future, it may be used to enable different styles of markers for different use cases.

#### New Features

- Introduced _taxi_ routes. Added `TransportMode.TAXI` type and a `TaxiOptions` class to calculate routes optimized for taxis via `RoutingEngine.calculateRoute()`. Note: This is a beta release of this transport mode, so there could be a few bugs and unexpected behaviors.
- Routing: Added `RouteOptions.speedCapInMetersPerSecond` to limit the maximum allowed speed for a vehicle. When set, the route duration will be shorter for car and truck transport modes. For scooter routes it may also affect the route geometry. Other transport modes are ignored.

#### Resolved Issues

- Fixed: Public transit routes do not contain maneuvers. <!-- IOTSDK-9473 -->

#### Known Issues

- Updating an existing `MapMarker` with a completely new image causes the marker to disappear for a brief moment before being drawn with the new image. <!-- IOTSDK-7197 -->
- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- A `Maneuver.polyline` list of `GeoCoordinates` has only one element for the last maneuver of a route. <!-- IOTSDK-6955 -->
- `MapMarker3D` instances are only partly rendered when the camera is positioned too far from earth. <!-- IOTSDK-7136 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.7.0.0

#### Highlights

- Introduced _public transit routing_ with a new `TransitRoutingEngine` that can calculate public transit routes. It uses `TransitWaypoint` type waypoints and a `TransitRouteOptions` class to specify various transit related options. Note that the API is in an early development stage. More features and overall stabilization are planned for the next releases.

#### New Features

- Along with the newly introduced `TransitRoutingEngine` (see above), the following supportive types have been added: `AttributionType` enum, `FarePriceType` enum, `FareReason` enum, `PreActionType` enum, `TransitDepartureStatus` enum, `TransitIncidentType` enum, `TransitIncidentEffect` enum, `TransitMode` enum, `TransitModeFilter` enum, `Agency` class, `Attribution` class, `Fare` class, `FarePrice` class, `PreAction` class, `TransitIncident` class, `TransitDeparture` class, `TransitSectionDetails` class, TransitStop class, and `TransitTransport` class.
- Routing: Introduced a new `Span` class that is accessible from a `Section` on a `Route`. It points to the related _section notices_ to indicate possible route violations. With the `Span` class these violations can now be identified on the `Route` as they contain the length in meters and the geometry.
- Routing: Added additional constructor for `IsolineOptions.Calculation`: `IsolineOptions.Calculation(@NonNull final IsolineRangeType rangeType, @NonNull final List<Integer> rangeValues, @NonNull final IsolineCalculationMode isolineCalculationMode)`.
- Search: Added new method to `SearchEngine` to get place details for a `Suggestion` that contains a `href` String. Use the new `sendRequest()` method for this.

#### API Changes

- Added a new `MapViewLifecycleListener` that replaces the deprecated `MapRepresentable`. It can be added or removed from a `Mapview`. Use this to get notified on the map view's lifecycle.
- Deprecated `MapRepresentable` and the related methods to add or remove it from a `MapView`. Use the newly introduced `MapViewLifecycleListener` instead.
- Removed the previously deprecated `GeoBox.intersects(GeoBox)` and `GeoBox.contains(GeoBox)`.
- Removed the previously deprecated `LocationProvider` and the `LocationListener.onLocationTimeout()` method.
- Removed the previously deprecated `Section.getTransportMode()` method.
- Removed the previously deprecated `GeoCorridor(List<GeoCoordinates>, Double)` constructor.
- Removed the previously deprecated `Place.getCoordinates()`.
- Removed the previously deprecated fields and constructors from `com.here.sdk.core.Color`.

#### Resolved Issues

- Fixed: The opening hours for a `Place` that closes after midnight end at midnight. <!-- IOTSDK-8721 -->

#### Known Issues

- Updating an existing `MapMarker` with a completely new image causes the marker to disappear for a brief moment before being drawn with the new image. <!-- IOTSDK-7197 -->
- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- A `Maneuver.polyline` list of `GeoCoordinates` has only one element for the last maneuver of a route. <!-- IOTSDK-6955 -->
- `MapMarker3D` instances are only partly rendered when the camera is positioned too far from earth. <!-- IOTSDK-7136 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->
- Public transit routes do not contain maneuvers. <!-- IOTSDK-9473 -->

### Version 4.6.5.0

#### New Features

- Added support for political views. `SDKOptions` allow now to specify the `politicalView` string. It's a three letter country code defined by ISO 3166-1 alpha-3. When set, all map data will respect the point of view of this country. Note that this is a beta feature and thus there can be bugs and unexpected behaviour.
- A `Place` can now be serialized or deserialized with `serializeCompact()` and `deserialize()` to or from a `String`.
- Routing: Added `SectionNoticeCode` and `NoticeSeverity` enums, `SectionNotice` class and `Section.getSectionNotices()` method to get informed on possible route violations.
- Isoline Routing:
  - Added `RoutePlaceDirection` enum with values `ARRIVAL` and `DEPARTURE`.
  - Added `isolineDirection` field inside `IsolineOptions.Calculation` structure (with default value of `RoutePlaceDirection.DEPARTURE`)
  - Extended the existing `IsolineOptions.Calculation` constructor to accept the new `RoutePlaceDirection` enum.
  - Added `RouteOptions.arrivalTime` to set an optional time when a travel is expected to end. Note that this parameter is currently only supported for isoline route calculation.

#### API Changes

- Routing: Deprecated the `Notice` class and `NoticeCode` enum along with `Section.getNotices()` method, use the newly introduced `SectionNoticeCode`, `SectionNotice` class and `Section.getSectionNotices()` method instead.
- Search: Deprecated `SearchError.OPTION_NOT_AVAILABLE` enum value, it will be replaced by the existing `SearchError.INVALID_PARAMETER` value.

#### Known Issues

- Updating an existing `MapMarker` with a completely new image causes the marker to disappear for a brief moment before being drawn with the new image. <!-- IOTSDK-7197 -->
- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- A `Maneuver.polyline` list of `GeoCoordinates` has only one element for the last maneuver of a route. <!-- IOTSDK-6955 -->
- `MapMarker3D` instances are only partly rendered when the camera is positioned too far from earth. <!-- IOTSDK-7136 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- The opening hours for a `Place` that closes after midnight end at midnight. <!-- IOTSDK-8721 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.6.4.0

#### New Features

- Routing: Introduced `Waypoint.minCourseDistanceInMeters` to specify an optional distance parameter during which a user can avoid taking actions.
- The size of the viewport can now be retrieved from `MapView` with the new `viewportSize` property that returns `Size2D` in physical pixels.
- Enhanced FlyTo `MapCamera` animations from A to B with target orientation and target distance: `flyTo(@NonNull GeoCoordinates target, double distanceInMeters, @NonNull MapCamera.FlyToOptions animationOptions)`.
- New map styles have been introduced as beta versions.
  - The map styles for `NORMAL_DAY`, `NORMAL_NIGHT`, `HYBRID_DAY` and `HYBRID_NIGHT` will be updated with v4.8.0. The planned new map styles are already accessible under following file names as beta versions:
    - "preview.normal.day.json" - This scheme will update the current `NORMAL_DAY` in v4.8.0.
    - "preview.normal.night.json" - This scheme will update the current `NORMAL_NIGHT` in v4.8.0.
    - "preview.hybrid.day.json" - This scheme will update the current `HYBRID_DAY` in v4.8.0.
    - "preview.hybrid.night.json" - This scheme will update the current `HYBRID_NIGHT` in v4.8.0.
  - The legacy map styles for `NORMAL_DAY`, `NORMAL_NIGHT`, `HYBRID_DAY` and `HYBRID_NIGHT` will still be accessible for v4.8.0 until v4.9.0 under the file names listed below. They will be removed with v4.9.0.
    - "legacy.normal.day.json"
    - "legacy.normal.night.json"
    - "legacy.hybrid.day.json"
    - "legacy.hybrid.night.json"
    - "legacy.grey.day.json"
    - "legacy.grey.night.json"

#### API Changes

- The map styles `MapScheme.greyDay`, `MapScheme.greyNight` have been deprecated and will be removed. Use the `NORMAL_` variants instead.

#### Known Issues

- Updating an existing `MapMarker` with a completely new image causes the marker to disappear for a brief moment before being drawn with the new image. <!-- IOTSDK-7197 -->
- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- A `Maneuver.polyline` list of `GeoCoordinates` has only one element for the last maneuver of a route. <!-- IOTSDK-6955 -->
- `MapMarker3D` instances are only partly rendered when the camera is positioned too far from earth. <!-- IOTSDK-7136 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- The opening hours for a `Place` that closes after midnight end at midnight. <!-- IOTSDK-8721 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.6.3.0

#### New Features

- Added new `WatermarkStyle` enum that defines the style of the HERE watermark logo. The _dark_ watermark should be used for custom styles that are brighter (like daytime) and the _light_ watermark for darker custom schemes (like night or satellite based). Added a new `loadScene()` method to `MapScene` to accept the new enum together with a custom style.
- `MapCamera`: Added `FlyToOptions` to customize the fly-to animation from current target `GeoCoordinates` to a new location. The `durationInMs` parameter defines how long the animation will run, the `bowFactor` defines a relative camera height for the ballistic curve that ranges from -1 < 0 (concave curve) to 0 (constant height) to 0 < 1 (convex curve). The maximum height can be achieved with a `bowFactor` of 1, the minimum with -1. Note that the height is relative to the distance between current target and new target to achieve a constant look regardless of the current zoom level.
- Routing: Added `sideOfStreetHint` property to `Waypoint`. These optional `GeoCoordinates` indicate which side of the street should be used to reach the waypoint. For example, if the location is to the left of the street, the route will prefer using that side in case the street has dividers. Hence, if the street has no dividers, `sideOfStreetHint` is ignored.

#### Known Issues

- Updating an existing `MapMarker` with a completely new image causes the marker to disappear for a brief moment before being drawn with the new image. <!-- IOTSDK-7197 -->
- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- A `Maneuver.polyline` list of `GeoCoordinates` has only one element for the last maneuver of a route. <!-- IOTSDK-6955 -->
- `MapMarker3D` instances are only partly rendered when the camera is positioned too far from earth. <!-- IOTSDK-7136 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- The opening hours for a `Place` that closes after midnight end at midnight. <!-- IOTSDK-8721 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.6.2.0

#### New Features

- Introduced beta versions of new map style combinations for use with `MapScene.loadScene()`: "preview.normal.day.json", "preview.normal.night.json", "preview.hybrid.day.json" and "preview.hybrid.night.json".
- Added new map item type: `MapArrow` elements can now be rendered on the map to indicate a direction. They can be added or removed like other map items via `MapScene`.
- `MapMarker` items can now be made invisible once they overlap each other at certain zoom levels. They contain a new property with `isOverlapAllowed()` and `setOverlapAllowed(boolean)`.

#### API Changes

- The free flow traffic layer is now rendering green traffic flow lines by default.

#### Resolved Issues

- Fixed: When traffic flows are enabled, map gestures may behave slower than expected. <!-- IOTSDK-7257 -->
- Fixed: When `SDKOptions` is created before initialization of `SDKNativeEngine` it may contain a corrupted path. <!-- IOTSDK-8302 -->

#### Known Issues

- Updating an existing `MapMarker` with a completely new image causes the marker to disappear for a brief moment before being drawn with the new image. <!-- IOTSDK-7197 -->
- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- A `Maneuver.polyline` list of `GeoCoordinates` has only one element for the last maneuver of a route. <!-- IOTSDK-6955 -->
- `MapMarker3D` instances are only partly rendered when the camera is positioned too far from earth. <!-- IOTSDK-7136 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- The opening hours for a `Place` that closes after midnight end at midnight. <!-- IOTSDK-8721 -->
- An inner city `Route` for trucks carrying dangerous goods may not result in an error message. <!-- IOTSDK-8521 -->

### Version 4.6.1.0

#### Highlights

- Added new `flyTo()` method to `MapCamera` for basic animations from A to B by setting new target coordinates. The animation can be interrupted by gestures or any programmatical change of the camera's position or orientation.

#### New Features

- Routing: Introduced `ZoneCategory` enum and added `zoneCategories` field to to the `AvoidanceOptions` struct which is a collection of `ZoneCategory`'s.
- EV routing: Introduced `Route.getEVDetails()` which returns the accumulated `evDetails` data for all sections of a route.

#### API Changes

- Routing: The `AvoidanceOptions` constructor requires to set the new field `zoneCategories`.
- Routing: Deprecated `Section.getDeparture()` and `Section.getArrival()`. Instead, use the newly introduced `Section.getDeparturePlace()` and `Section.getArrivalPlace()` to get a `RoutePlace`.
- Deprecated the `Address` fields `stateName`, `countyName`, `streetName` and the related constructors. Instead, use the newly introduced constructor that takes the new fields `state`, `country` and `street`.

#### Resolved Issues

- Fixed: Performing a `CategoryQuery` or a `TextQuery` search no longer returns `SearchError.HTTP_ERROR` when searching in a circle, whose radius is a number with a fraction.

#### Known Issues

- Updating an existing `MapMarker` with a completely new image causes the marker to disappear for a brief moment before being drawn with the new image. <!-- IOTSDK-7197 -->
- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- When traffic flows are enabled, map gestures may behave slower than expected. <!-- IOTSDK-7257 -->
- A `Maneuver.polyline` list of `GeoCoordinates` has only one element for the last maneuver of a route. <!-- IOTSDK-6955 -->
- `MapMarker3D` instances are only partly rendered when the camera is positioned too far from earth. <!-- IOTSDK-7136 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- When `SDKOptions` is created before initialization of `SDKNativeEngine` it may contain a corrupted path. <!-- IOTSDK-8302 -->

### Version 4.6.0.0

#### Highlights

- Devices running older Adreno 330 GPUs are now supported.
- Added _isoline routing_ to calculate the reachable area for the given center coordinates and a range defined in time, distance or energy consumption. Added a new `calculateIsoline()` method to `RoutingEngine`. Added related classes:
  - `IsolineOptions`: Options for isoline calculation.
  - `IsolineRangeType`: Enumeration specifying whether the range type is defined in time, distance or energy consumption.
  - `IsolineCalculationMode`: Specifies how the isoline calculation can be optimized.
  - `Isoline`: Represents a single isoline.
  - `MapMatchedCoordinates`: Contains a pair of user-defined and map-matched coordinates.

#### More New Features

- `MapPolygon` items can now be picked from `MapView`. `PickMapItemsResult` can now include a list of `MapPolygon` items.
- Added `ScooterOptions.allowHighway` property.
<!-- - Users of the exclusive _Skytree Edition_ can load the Japan map scheme for a `MapScene` via `loadScene("japan.ocm.day.json", loadSceneCallback)`. This special map scheme covers the entire world. No other map scheme should be loaded, otherwise the map falls back to the non-exclusive map schemes. By default, the Japan map feature is not available for the regular edition of this release. -->
- Added method to look at a given `GeoBox` at the map view with `void lookAt(@NonNull final GeoBox target, @NonNull final MapCamera.OrientationUpdate orientation, @NonNull final Rectangle2D viewRectangle)`. For example, this can be used to show a route on a certain part of the map view.
- Search: Added `categories` field to `OpeningHours`. It contains `categories` related to specific `OpeningHours`. For example, when a `Place` has multiple opening hours associated with it.
- Added `SDKNativeEngine.dispose()` to release resources. It should be used in cases when it's necessary to create a new instance of `SDKNativeEngine` with the same access key id as previously used.
- Road shields are now rendered by default on the map view.

#### API Changes

- Removed beta status for scooter transport mode.
- Deprecated the `updateGeometry()` method for `MapPolygon`. Use the newly introduced set/get _geometry_ accessors instead to get or set a `GeoPolygon`.
- Deprecated the `updateGeometry()` method for `MapPolyline`. Use the newly introduced set/get _geometry_ accessors instead to get or set a `GeoPolyline`.
- Search: Deprecated the following `Contact` fields `landlinePhoneNumbers`, `mobilePhoneNumbers`, `emailAddresses`, `websiteAddresses`. Use these newly introduced fields instead: `landlinePhones`, `mobilePhones`, `emails`, `websites`. Each holds a list of newly created classes `LandlinePhone`, `MobilePhone`, `EmailAddress`, `WebsiteAddress` - containing a string representation of the item and a list of related `PlaceCategory` values.
- The free flow traffic layer does no longer render the green traffic flow lines. In the future, an API to enable / disable the flow is planned to be introduced.
- The `SDKNativeEngine` now locks access to the map data cache. When another instance of `SDKNativeEngine` is instantiated with the same access key id then now an exception is thrown.
- `MapView`: Added clamping to principal point when the coordinates are outside of the viewport.
- `Maneuver`: Deprecated `roadName`, `roadNameLanguageCode`, `roadNumber`, `nextRoadName`, `nextRoadNameLanguageCode`, `nextRoadNumber`. Added instead `RoadTexts` with `roadTexts` and `nextRoadTexts` and `LocalizedText` and `LocalizedTexts`.

#### Resolved Issues

- Fixed: A `MapPolyline` may be unexpectedly rendered over a `MapMarker`. <!-- IOTSDK-7805 -->

#### Known Issues

- Updating an existing `MapMarker` with a completely new image causes the marker to disappear for a brief moment before being drawn with the new image. <!-- IOTSDK-7197 -->
- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- When traffic flows are enabled, map gestures may behave slower than expected. <!-- IOTSDK-7257 -->
- A `Maneuver.polyline` list of `GeoCoordinates` has only one element for the last maneuver of a route. <!-- IOTSDK-6955 -->
- `MapMarker3D` instances are only partly rendered when the camera is positioned too far from earth. <!-- IOTSDK-7136 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- When `SDKOptions` is created before initialization of `SDKNativeEngine` it may contain a corrupted path. <!-- IOTSDK-8302 -->

### Version 4.5.4.0

#### Highlights

- The supported device specifications have been fine tuned and contain now more granular details on the supported devices. Details can be found in the _About_ section of the Developer Guide for this edition.
- Searching for a `CategoryQuery` within a `GeoCircle` or `GeoBox` is no longer marked as a _beta_ feature.

#### New Features

- Added support for a transform center: The `MapCamera` know allows to set and get a _principal point_ as `Point2D`. This point determines where the target is placed within the map view. With this you can, for example, lower the map's default center as it will affect map transformations such as rotations and tilt.
- Extended walk routing options: Added `PedestrianOptions.walkSpeedInMetersPerSecond` property. Note that this feature is released as _beta_. By setting a walk speed you can calculate pedestrian routes specific for different walk profiles.
- Added new map cache options to `SDKOptions` with `SDKOptions.cacheSizeInBytes` and `SDKOptions.persistentMapStoragePath`. Also available as key in manifest (`com.here.sdk.cache_size_in_bytes`, `com.here.sdk.persistent_map_storage_path`). With this you can control where to store cached map data and it also allows to specify the amount of data you want to reserve for caching.

#### Known Issues

- Updating an existing `MapMarker` with a completely new image causes the marker to disappear for a brief moment before being drawn with the new image. <!-- IOTSDK-7197 -->
- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- When traffic flows are enabled, map gestures may behave slower than expected. <!-- IOTSDK-7257 -->
- A `Maneuver.polyline` list of `GeoCoordinates` has only one element for the last maneuver of a route. <!-- IOTSDK-6955 -->
- `MapMarker3D` instances are only partly rendered when the camera is positioned too far from earth. <!-- IOTSDK-7136 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- A `MapPolyline` may be unexpectedly rendered over a `MapMarker`. <!-- IOTSDK-7805 -->

### Version 4.5.3.0

#### New Features

- Added a `NoticeCode` that describes issues after a `Route` was calculated. For example, when a route should avoid tunnels, but the only possible route needs to pass a tunnel, the `Route` contains a notice that the requested avoidance of tunnels was violated. Therefore, it is recommended to always check a calculated `Route` for possible violations. The `NoticeCode` is part of a `Notice` object. A list of possible `Notice` objects can be accessed per `Section` of a `Route`. The list will be empty, when no violation occurred.
- Addeded the ability to change the anchor point of a `MapMarker` with `Anchor2D`. By default, the marker is centered on the provided location and the anchor is at (0.5, 0.5). An anchor represents a point in a rectangle as a ratio of the marker's image width and height.
- Added search for a `CategoryQuery` within a `GeoCircle` or `GeoBox`. Extended the existing `CategoryQuery` constructors to accept `GeoCircle` or `GeoBox`. Note that this feature is currently in BETA state.

#### Known Issues

- Updating an existing `MapMarker` with a completely new image causes the marker to disappear for a brief moment before being drawn with the new image. <!-- IOTSDK-7197 -->
- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- When traffic flows are enabled, map gestures may behave slower than expected. <!-- IOTSDK-7257 -->
- A `Maneuver.polyline` list of `GeoCoordinates` has only one element for the last maneuver of a route. <!-- IOTSDK-6955 -->
- `MapMarker3D` instances are only partly rendered when the camera is positioned too far from earth. <!-- IOTSDK-7136 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- A `MapPolyline` may be unexpectedly rendered over a `MapMarker`. <!-- IOTSDK-7805 -->

### Version 4.5.2.0

#### Highlights

- Added suppport for scooter route calculation with the new `ScooterOptions`. Note that this is a BETA feature. Using scooter routes for navigation is not yet supported.

#### New Features

- Added new read-only property to `MapPolyline` with `GeoPolyline getGeometry()`.
- Added `DashPattern` class to set dashed line styles for a `MapPolyline`.
- Added the following methods to `MapPolyline` to add support for fill colors when using dashed lines:
  - `Color getDashFillColor()`
  - `void setDashFillColor(@Nullable Color value)`
- Added cumulative orbit method to `MapCamera` to rotate the map around arbitrary view coordinates using relative orientation values with `orbitBy(@NonNull MapCamera.OrientationUpdate delta, @NonNull Point2D origin)`.

#### API Changes

- Cache path to store map data is now unique per access key ID (which is unique per customer). The HERE SDK automatically appends the current version of the cache and the access key ID. If you want to keep existing cache data, it may be required to copy it from `<cache-root>` to `<cache-root>/v1/<access-key-id>`, as the current version of the cache is "v1".
- Deprecated `SDKNativeEngine.setAccessKey(access_key_id, access_key_secret)`. Use `SDKNativeEngine.setAccessKeySecret(access_key_secret)` instead, in combination with setting the access key ID via `SDKOptions` when constructing a new `SDKNativeEngine`.
- Deprecated `LocationUpdateListener`. Use the new `LocationListener` instead.
- Removed deprecated `GeoCircle` constructor that accepts single precision float type for radius.

#### Resolved Issues

- Fixed: Embedded POI markers are not visible for the _hybrid night_ map scheme. <!-- IOTSDK-7494 -->
- Fixed: Pan gestures may receive a _cancel_ event before a _begin_ event. <!-- IOTSDK-7511 -->

#### Known Issues

- Updating an existing `MapMarker` with a completely new image causes the marker to disappear for a brief moment before being drawn with the new image. <!-- IOTSDK-7197 -->
- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- When traffic flows are enabled, map gestures may behave slower than expected. <!-- IOTSDK-7257 -->
- A `Maneuver.polyline` list of `GeoCoordinates` has only one element for the last maneuver of a route. <!-- IOTSDK-6955 -->
- `MapMarker3D` instances are only partly rendered when the camera is positioned too far from earth. <!-- IOTSDK-7136 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->

### Version 4.5.1.0

#### Highlights

- Improved cold startup time on certain devices like Samsung.

#### New Features

- Added new `MapCameralimits` with `void setTargetArea(@Nullable GeoBox value)` and `@Nullable GeoBox getTargetArea()`. This allows to set a target area preventing a user from moving away too much from a desired area of interest.
- Added new `MapCameralimits` for bearing with `void setBearingRange(@NonNull AngleRange value)` and `@NonNull AngleRange getBearingRange()`.
- Introduced `Maneuver.getLengthInMeters()` method to return the length of the maneuver.
- Introduced `SectionTransportMode` enum and `Section.getSectionTransportMode()` method returning an instance of this type indicating now transport modes such as ferries. `Section.getTransportMode()` has been deprecated, use the newly introduced method instead.
- Search: Introduced `SupplierReference` type and `Details.references` property, which holds the list of supplier references to a place.

#### Resolved Issues

- Fixed: Operations on `MapCamera` (`lookAt()`, `zoomBy()`,...) can now be executed already during `onCreate()` and `onResume()` calls. They will be enqueued and executed after `MapView` is fully created and functional.

#### Known Issues

- Updating an existing `MapMarker` with a completely new image causes the marker to disappear for a brief moment before being drawn with the new image. <!-- IOTSDK-7197 -->
- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- When traffic flows are enabled, map gestures may behave slower than expected. <!-- IOTSDK-7257 -->
- A `Maneuver.polyline` list of `GeoCoordinates` has only one element for the last maneuver of a route. <!-- IOTSDK-6955 -->
- `MapMarker3D` instances are only partly rendered when the camera is positioned too far from earth. <!-- IOTSDK-7136 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->
- Embedded POI markers are not visible for the _hybrid night_ map scheme. <!-- IOTSDK-7494 -->
- Pan gestures may receive a _cancel_ event before a _begin_ event. <!-- IOTSDK-7511 -->

### Version 4.5.0.0

#### Highlights

- Added `heresdk-explore-mock-<version>.jar` to release package to enable easy mocking of HERE SDK classes for Unit Tests, check the new _UnitTesting_ example app to see how to use it in your own tests.
- Added route calculation for _electric vehicles_ (EV). It's now possible to calculate the energy consumption per route section according to the given consumption model (supported for electric cars and trucks). Charging stations are automatically added to the calculated route as waypoints to ensure that the electric vehicle doesn't run out of energy along the way (supported for electric cars).

#### New Features

- Added `LogAppender` interface to insert your own log class into the `SDKNativeEngine`. This way you can log HERE SDK messages for various predefined log levels even on release builds.
- Added a scale property to change the size of a `MapMarker3D`.
- Added camera tilt limits with `void MapCameraLimits.setMaxTilt(double degreesFromNadir)` and
`void MapCameraLimits.setMinTilt(double degreesFromNadir)`.
- Added camera zoom limits with `void MapCameraLimits.setMaxZoomLevel(double zoomLevel)` and
`void MapCameraLimits.setMinZoomLevel(double zoomLevel)`.
- Added new methods to calculate routes for _electric vehicles_ (car and trucks are supported):
`RoutingEngine.calculateRoute(List<Waypoint>, EVCarOptions, CalculateRouteCallback)`,
`RoutingEngine.calculateRoute(List<Waypoint>, EVTruckOptions, CalculateRouteCallback)`.
- Added the following classes and fields to support EV routing (see above):
  - `BatterySpecifications` - parameters that describe the electric vehicle's battery.
  - `ChargingConnectorAttributes` - details of the connector that is suggested to be used for charging.
  - `ChargingConnectorType` - enumeration of the available charging connector types.
  - `ChargingStation` - charging station data.
  - `ChargingSupplyType` - enumeration of available charging supply types.
  - `EVCarOptions` - options to specify how a route for an electric car should be calculated.
  - `EVConsumptionModel` - parameters specific for the electric vehicle, which are used to calculate energy consumption on a given route.
  - `EVDetails` - additional information that is available for electric vehicles.
  - `EVTruckOptions` - options to specify how a route for an electric truck should be calculated.
  - `PostActionType` - enumeration of available post action types.
  - `PostAction` - an action that must be done after arrival.
  - `RoutePlaceType` - shows whether the place on the route (such as departure or arrival) is a charging station or a regular place.
  - `Arrival.type` - the type of the arrival place.
  - `Arrival.chargeInKilowattHours` - battery charge at arrival.
  - `Arrival.chargingStation` - charging station data at arrival.
  - `Departure.type` - the type of the departure place.
  - `Departure.chargeInKilowattHours` - battery charge at departure.
  - `Departure.chargingStation` - charging station data at departure.
  - `Section.postActions` - actions that must be done after the arrival.
  - `Section.evDetails` - additional section information that is available for electric vehicles.

#### API Changes

- For custom map styles _HERE Style Editor 0.26_ is required.
- Changed splash screen to be grey instead of black. This improves the experiences on devices where cold start takes longer.
- Removed a deprecated `GeoCoordinates` constructor, use the previously introduced counterpart instead.
- Removed a deprecated `Anchor2D` constructor, use the previously introduced counterpart instead.
- Changed the following methods in `MapMarker`:
  - `Long getDrawOrder()` to `Integer getDrawOrder()`.
  - `void setDrawOrder(Long drawOrder)` to `void setDrawOrder(Integer drawOrder)`.

#### Resolved Issues

- Fixed: After orientation changes coordinate conversions may return incorrect values. <!-- IOTSDK-6162 -->
- Fixed: A category search along a route will crash when the `GeoCorridor.polyline` list parameter is empty. <!-- IOTSDK-7016 -->

#### Known Issues

- Updating an existing `MapMarker` with a completely new image causes the marker to disappear for a brief moment before being drawn with the new image. <!-- IOTSDK-7197 -->
- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- When traffic flows are enabled, map gestures may behave slower than expected. <!-- IOTSDK-7257 -->
- A `Maneuver.polyline` list of `GeoCoordinates` has only one element for the last maneuver of a route. <!-- IOTSDK-6955 -->
- `MapMarker3D` instances are only partly rendered when the camera is positioned too far from earth. <!-- IOTSDK-7136 -->
- The `jamFactor` indicating `TrafficSpeed` is currently calculated linear without taking road types and other parameters into account. <!-- IOTSDK-7368 -->

### Version 4.4.6.0

#### Highlights

- This release focuses on overall stability and performance improvements.

#### Resolved Issues

- Fixed: Map tiles may not load automatically when losing internet connectivity and connectivity gets back, unless the user interacts with the map. <!-- IOTSDK-5727 -->

#### Known Issues

- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- After orientation changes coordinate conversions may return incorrect values. <!-- IOTSDK-6162 -->
- A category search along a route will crash when the `GeoCorridor.polyline` list parameter is empty. <!-- IOTSDK-7016 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->
- When traffic flows are enabled, map gestures may behave slower than expected. <!-- IOTSDK-7257 -->
- A `Maneuver.polyline` list of `GeoCoordinates` has only one element for the last maneuver of a route. <!-- IOTSDK-6955 -->
- `MapMarker3D` instances are only partly rendered when the camera is positioned too far from earth. <!-- IOTSDK-7136 -->

### Version 4.4.5.0

#### New Features

- Added `void setImage(@NonNull MapImage mapImage)` and `MapImage getImage()` to the `MapMarker` class. This allows to change a `MapImage` for a `MapMarker` that is already shown on the map to update its appearance.
- Added `void zoomTo(double zoomLevel)` to the `MapCamera` class to set the zoom level in the range [0,22]. Access the current `zoomLevel` from the camera's `State` property.
- Added `GeoBox GeoBox.containing(@NonNull List<GeoCoordinates> geoCoordinates)` to construct a `GeoBox` from a list of `Geocoordinates`.
- A `CategoryQuery` can now be created from a single `PlaceCategory` with the additional constructor `CategoryQuery(@NonNull PlaceCategory category, @NonNull String filter, @NonNull GeoCoordinates areaCenter)`.

#### Resolved Issues

- Fixed: In rare cases map tiles may flicker when a device is offline and the cache is used. <!-- IOTSDK-6708 -->

#### Known Issues

- The newly introduced zoom level behaves inconsistent across different devices as the shown level of detail depends on the physical screen size of a device. <!-- HARP-8095 -->
- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- After orientation changes coordinate conversions may return incorrect values. <!-- IOTSDK-6162 -->
- Map tiles may not load automatically when losing internet connectivity and connectivity gets back, unless the user interacts with the map. <!-- IOTSDK-5727 -->
- A category search along a route will crash when the `GeoCorridor.polyline` list parameter is empty. <!-- IOTSDK-7016 -->
- `MapViewPin` instances cannot be removed after tilting and panning the map. <!-- IOTSDK-7051 -->

### Version 4.4.4.0

#### Highlights

- Added automatic geometry simplification to `MapPolyline`: Now, the rendered polyline shape is optimized based on the current distance of the camera to earth. While not being visible for the eye, this improves the performance, for example, when rendering longer routes.

#### API Changes

- `targetSdkVersion` and `compileSdkVersion` of the internal `AndroidManifest` used by the HERE SDK have been updated from 28 to 29.

#### Deprecated

- A few methods, fields and constructors of class `here.sdk.Color` have been deprecated. Instead, use the new methods that have been introduced to the class to conform to Android's native `Color` class. The new factory methods and getters use a color component of type `float` with the interval [0,1] - instead of type `short` and [0,255] that was used for the deprecated components.

#### Resolved Issues

- Fixed an issue with flickering street labels after credentials have been changed. <!-- IOTSDK-6714 -->
- Fixed issue with empty IDs for reverse geocoding results: IDs of place results are no longer empty strings and contain now a valid ID. <!-- IOTSDK-5408 -->
- Route calculation: When no truck route is found due to incompatible truck restrictions, the reason is now logged and `RoutingError.NO_ROUTE_FOUND` error is returned. For example, a log may contain: "Potential route would violate truck restriction:{"maxHeight":400}". <!-- IOTSDK-1893 -->

#### Known Issues

- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- After orientation changes coordinate conversions may return incorrect values. <!-- IOTSDK-6162 -->
- Map tiles may not load automatically when losing internet connectivity and connectivity gets back, unless the user interacts with the map. <!-- IOTSDK-5727 -->
- In rare cases map tiles may flicker when a device is offline and the cache is used. <!-- IOTSDK-6708, IOTSDK-6708 -->

### Version 4.4.3.0

#### Highlights

- Kinetic map panning behavior was greatly improved. Now, when swiping the map moves slower which results in a more natural feel.
- Certain areas can now be excluded from route calculation with `AvoidanceOptions` that contain an `avoidAreas` list holding `GeoBox` items which routes should not cross.

#### New Features

- Added optional `Suggestion.getHref()` to get a direct link to discover more details. It is available when the suggestion result type is _category_ or _chain_.
- Added `RoadFeatures.DIFFICULT_TURNS` enum value. Note that it is valid only for truck transport mode.
- Added `MapError.INVALID_STATE` enum value which can be raised when a map scene is in an invalid state after a `MapView` was destroyed.
- Added a new `GeoCorridor` constructor with `radiusInMeters` as _integer_ type - as replacement for the deprecated constructor with `radiusInMeters` as _double_ type, see below.

#### Deprecated

- Deprecated `GeoCorridor` constructor with `radiusInMeters` as _double_ type. Use the newly introduced `GeoCorridor` constructor with `radiusInMeters` as _integer_ type instead, see above.

#### API Changes

- The `AvoidanceOptions(avoidFeatures, avoidCountries)` constructor was extended to allow a list of `GeoBox` items as third parameter.

#### Resolved Issues

- Fixed: When the pick radius for `pickMapItems()` is set to 1000 or higher, an app may crash when picking map polylines. <!-- IOTSDK-6476 -->
- Fixed: `SearchEngine`: `Place.getId()` is empty for reverse geocoding results. <!-- IOTSDK-5408 -->

#### Known Issues

- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- After orientation changes coordinate conversions may return incorrect values. <!-- IOTSDK-6162 -->
- Map tiles may not load automatically when losing internet connectivity and connectivity gets back, unless the user interacts with the map. <!-- IOTSDK-5727 -->
- In rare cases map tiles may flicker when a device is offline. <!-- IOTSDK-6708 -->

### Version 4.4.2.0

#### New Features

- Added `Place.getGeoCoordinates()` method to get the `GeoCoordinates` of a `Place`. Note that only `Place` instances retrieved from a `Suggestion` result may not contain geographic coordinates, hence the returned value is optional.
- Added departure/arrival information to the `Section` of a `Route`:
  - Added `Departure` class with the following fields:
    - `waypointIndex`
    - `originalCoordinates`
    - `mapMatchedCoordinates`
  - Added `Arrival` class with the following fields:
    - `waypointIndex`
    - `originalCoordinates`
    - `mapMatchedCoordinates`
  - Added `Section.get_departure()` method.
  - Added `Section.get_arrival()` method.
- Added `Suggestion.getType()` to get the new `SuggestionType` enum that indicates whether this `Suggestion` is a _place_, a _chain_ like a store, restaurant or bussiness chain - or a `category`.

#### Deprecated

- Deprecated `Place.getCoordinates()` method, use `Place.getGeoCoordinates()` instead. Note that only `Place` instances retrieved from a `Suggestion` result may not contain geographic coordinates, hence the returned value has become optional.

#### Resolved Issues

- Fixed: When the `Route` used to _search along the route_ is too long, now a proper error is returned with `SearchError.ROUTE_TOO_LONG`. <!-- IOTSDK-6403 -->
- Fixed: For places that are obtained from the `Suggestion` class, the geographic coordinates always contain a latitude and a longitude equal to 0. An additional places request is needed to obtain the coordinates. <!-- IOTSDK-6502 -->

#### Known Issues

- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- `SearchEngine`: `Place.getId()` is empty for reverse geocoding results. <!-- IOTSDK-5408 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- After orientation changes coordinate conversions may return incorrect values. <!-- IOTSDK-6162 -->
- When the pick radius for `pickMapItems()` is set to 1000 or higher, an app may crash when picking map polylines. <!-- IOTSDK-6476 -->
- Map tiles may not load automatically when losing internet connectivity and connectivity gets back, unless the user interacts with the map. <!-- IOTSDK-5727 -->

### Version 4.4.1.0

#### New Features

- Traffic flows can now be identified along a `Route`. Introduced `TrafficSpeeds` class to provide traffic speed information over a `Section` polyline. The `Section.getTrafficSpeeds()` method returns a list of `TrafficSpeeds`'s which covers the `Section` polyline.
- Added `SearchError.QUERY_TOO_LONG` and `SearchError.FILTER_TOO_LONG`. These errors will appear if the search query or search filter is too long (over 300 characters).
- Added `Route.getTransportMode()` which returns the original `TransportMode` as requested for the route calculation.

#### Resolved Issues

- Fixed: Fixed memory leaks caused by `PlatformThreading`.

#### Known Issues

- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- `SearchEngine`: `Place.getId()` is empty for reverse geocoding results. <!-- IOTSDK-5408 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- After orientation changes coordinate conversions may return incorrect values. <!-- IOTSDK-6162 -->
- When the pick radius for `pickMapItems()` is set to 1000 or higher, an app may crash when picking map polylines. <!-- IOTSDK-6476 -->
- For places that are obtained from the `Suggestion` class, the geographic coordinates always contain a latitude and a longitude equal to 0. An additional places request is needed to obtain the coordinates. <!-- IOTSDK-6502 -->
- Map tiles may not load automatically when losing internet connectivity and connectivity gets back, unless the user interacts with the map. <!-- IOTSDK-5727 -->

### Version 4.4.0.2

#### Highlights

- New map schemes have been introduced to support satellite images together with vector-based street labels: `HYBRID_DAY` and `HYBRID_NIGHT`.

#### New Features

- Added to the `MapCamera` class the method: `void setTargetOrientation(@NonNull MapCamera.OrientationUpdate orientation)` to set only the target orientation in relation to the camera.
- By default, polylines are rendered in the order as they have been added to the map. This can now be changed at runtime by setting the draw order. It's now also possible to change the width and outline width at runtime. For this, the following methods have been added to the `MapPolyline` class:
  - `void setDrawOrder(int value)` to set the `DrawOrder` for a `MapPolyline`.
  - `int getDrawOrder()` to get the `DrawOrder` for a `MapPolyline`.
  - `void setLineWidth(double value)` to set the `LineWidth` for a `MapPolyline`.
  - `double getLineWidth()` to get the `LineWidth` for a `MapPolyline`.
  - `void setOutlineWidth(double value)` to set the `OutlineWidth` for a `MapPolyline`.
  - `double getOutlineWidth()` to get the `OutlineWidth` for a `MapPolyline`.
- Search for places along a route: Added the `GeoCorridor` option to filter `TextQuery` results when performing an asynchronous search request along a route with the method `TextQuery(@NonNull String query, @NonNull GeoCorridor corridorArea, @NonNull GeoCoordinates areaCenter)`.
- Search for places by category along a route: Added the `CategoryQuery` structure that accepts the `GeoCorridor` option in its constructors with the `filter` parameter `CategoryQuery(@NonNull List<PlaceCategory> categories, @NonNull String filter, @NonNull GeoCorridor corridorArea)` and without the `filter` parameter `CategoryQuery(@NonNull List<PlaceCategory> categories, @NonNull GeoCorridor corridorArea)` to enable category search along a route. This feature is in BETA state.
- Added to the `Details` class the method: `List<PlaceCategory> getPrimaryCategories()` to get a place category from the result of a search query.

#### API Changes

- Reduced the rotation sensitivity of the `Pinch Rotate` gesture. Now, it is easier to zoom in on the map without rotating it.
- Moved the `LocationProvider` and `LocationListener` interfaces from the `com.here.sdk.navigation` to the `com.here.sdk.core` package.

#### Resolved Issues

- Fixed: Rendering order for `MapMarker3D` is not yet supported, so the marker may appear below building footprints. Now, the rendering order for `MapMarker3D` is supported and the marker no longer appears below building footprints. <!--- HARP-9290, IOTSDK-5784 -->
- Fixed several rendering issues related to map items. <!--- IOTSDK-6291 -->

#### Known Issues

- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- `SearchEngine`: `Place.getId()` is empty for reverse geocoding results. <!-- IOTSDK-5408 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- After orientation changes coordinate conversions may return incorrect values. <!-- IOTSDK-6162 -->
- When the pick radius for `pickMapItems()` is set to 1000 or higher, an app may crash when picking map polylines. <!-- IOTSDK-6476 -->
- For places that are obtained from the `Suggestion` class, the geographic coordinates always contain a latitude and a longitude equal to 0. An additional places request is needed to obtain the coordinates. <!-- IOTSDK-6502 -->

### Version 4.3.4.0

#### Highlights

- With this release it is no longer necessary to request the sensitive `EXTERNAL_STORAGE` permission from users. See the related API change below.

#### New Features

- Added the line cap style property to `MapPolyline` with the enum `LineCap` to change polyline ends rendered on the map.
- Added the methods `LineCap getLineCap()` and `void setLineCap(@NonNull LineCap value)` to get and set the `LineCap` of a `MapPolyline`.

#### API Changes

- Removed the `android.permission.READ_EXTERNAL_STORAGE` and `android.permission.WRITE_EXTERNAL_STORAGE` permissions from the SDK manifest file.

#### Known Issues

- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- `SearchEngine`: `Place.getId()` is empty for reverse geocoding results. <!-- IOTSDK-5408 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- Rendering order for `MapMarker3D` is not yet supported, so the marker may appear below building footprints. <!--- HARP-9290 -->
- After orientation changes coordinate conversions may return incorrect values. <!-- IOTSDK-6162 -->

### Version 4.3.3.0

#### New Features

- Added the method `search(@NonNull PlaceIdQuery query, @Nullable LanguageCode languageCode, @NonNull PlaceIdSearchCallback callback)` to perform an asynchronous request to search for a place based on its ID and language code.
- Added the possibility to filter `AddressQuery` results by the `CountryCode` with the method `AddressQuery(@NonNull String query, @NonNull GeoCoordinates areaCenter, @NonNull List<CountryCode> countries)`.
- Added the possibility to filter `TextQuery` results by the `CountryCode` with the method `TextQuery(@NonNull String query, @NonNull GeoCoordinates areaCenter, @NonNull List<CountryCode> countries)`.
- Added the methods `getLineColor()` and `void setLineColor(@NonNull Color value)` to get and set the `LineColor` of a `MapPolyline`.
- Added the methods `getOutlineColor()` and `void setOutlineColor(@NonNull Color value)` to get and set the `OutlineColor` of a `MapPolyline`.

#### Deprecated

- Deprecated the method `search(@NonNull PlaceIdQuery query, @NonNull PlaceIdSearchCallback callback)`. Use the newly introduced `search(@NonNull PlaceIdQuery query, @Nullable LanguageCode languageCode, @NonNull PlaceIdSearchCallback callback)` method instead.

#### Resolved Issues

- Fixed: App crashes when access to memory storage is denied. Now, access to the memory is granted by setting the path to the map cache. <!-- IOTSDK-5841 -->
- Fixed: Heading is ignored during turn-by-turn navigation. Now, Waypoint heading is considered during turn-by-turn navigation. <!-- IOTSDK-5762 -->

#### Known Issues

- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- `SearchEngine`: `Place.getId()` is empty for reverse geocoding results. <!-- IOTSDK-5408 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- Rendering order for `MapMarker3D` is not yet supported, so the marker may appear below building footprints. <!--- HARP-9290 -->

### Version 4.3.2.0

#### New Features

- Added the `ManeuverProgress` class which is accessible from `RouteProgress.maneuverProgress` to indicate progress details to the next and next-next maneuvers during navigation.
- Added the method `MapCamera.getBoundingBox()` to get the currently visible map area encompassed in a `GeoBox`.
- Added the `ViewPin` class to display Android views at a fixed location on the `MapView` with the methods:
  - `ViewPin pinView(@NonNull View view, GeoCoordinates coordinates)` to pin a view on the `MapView`.
  - `void unpinView(@NonNull View view)` to remove a view pinned to the `MapView`.
  - `List<ViewPin> getViewPins()` to get the views pinned on the `MapView`.
- Added the method `void MapCamera.setDistanceToTarget(double distanceInMeters)` to set the distance from the `MapCamera` to the target location on earth.
- Added the methods `void MapView.setPrimaryLanguage(@Nullable LanguageCode languageCode)` and `MapView.getPrimaryLanguage()` to set and get the primary language of the map.
- Added updated support for the `SDKOptions.cachePath` handling. If `SDKOptions.cachePath` is not set, it will be assigned a default path [`Context.getCacheDir().getPath()`]. A custom `cachePath` can be set in the app's manifest file via the `"com.here.sdk.cache_path"` key.

#### Resolved Issues

- Fixed: The `Authentication` callback was not always called on the main thread. Now the callback is guaranteed to be always called on the main thread. <!-- IOTSDK-5338 -->

#### Known Issues

- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- `SearchEngine`: `Place.getId()` is empty for reverse geocoding results. <!-- IOTSDK-5408 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- Rendering order for `MapMarker3D` is not yet supported, so the marker may appear below building footprints. <!--- HARP-9290 -->
- Heading is currently ignored during turn-by-turn navigation. <!-- IOTSDK-5762 -->

### Version 4.3.1.0

#### New Features

- Added the methods `MapMarker.getDrawOrder()` and `MapMarker.setDrawOrder(final long value)` to get and set the draw order of `MapMarkers` on the map.
- Added `MapView.OnReadyListener` with the method `Map.setOnReadyListener(OnReadyListener readyListener)` to set the `ReadyListener`. The listener will notify once the map view has been initialization.
- Added the support for `3D MapMarkers` with the classes `MapMarker3D` and `MapMarker3DModel` to represent and define a 3D shape rendered on the map.
  - Added the methods `void MapScene.addMapMarker3d(@NonNull MapMarker3D marker)` and `void MapScene.removeMapMarker3d(@NonNull MapMarker3D marker)` to add and remove a `3D MapMarker`.
- Added the `Rectangle2D` constructor that accepts type `double` for the origin and size parameters to represent a 2D rectangle.
- Added the `Size2D` constructor that accepts type `double` for the height and width parameters to represent the size of a 2D structure.
- Added the methods `MapPolylines.getMetadata()` and `void setMetadata(@Nullable Metadata value)` to get and set the Metadata for `MapPolylines`.

#### Resolved Issues

- Fixed: `AvoidanceOptions` will be ignored when calculating truck routes. Now, `AvoidanceOptions` are considered when calculating truck routes.

#### Known Issues

- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- `SearchEngine`: `Place.getId()` is empty for reverse geocoding results. <!-- IOTSDK-5408 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->
- Rendering order for `MapMarker3D` is not yet supported, so the marker may appear below building footprints. <!--- HARP-9290 -->

### Version 4.3.0.0

#### New Features

- Added the `GeoCoordinates(double latitude, double longitude, double altitude)` constructor.
- Added the `GeoCircle()` constructor that accepts type `double` for the `radius` parameter.
- Added support for map circles: Added the `GeoPolygon(@NonNull  GeoCircle geoCircle)` constructor, which can then be used to create a `MapPolygon` that has the shape of a circle.
- Added the `Anchor2D()` constructor that accepts type `double` for the  horizontal and vertical parameters.
- Added the `MapView.getPixelScale()` method to get the pixel scale used by `MapView`.
- Added the `MapPolygon.updateGeometry(GeoPolygon geometry)` method to its shape on-the-fly.
- Added outlines for map polylines with `MapPolyline(GeoPolyline geometry, double widthInPixels, Color color, double outlineWidthInPixels, Color outlineColor)`.
- Added `MapView.setWatermarkPosition(WatermarkPlacement placement, int bottomCenterMargin)` to set the watermark's position on the `MapView`.
- Added the `WatermarkPlacement` enum.
- Added the following to the `com.here.sdk.search` package:
  - `AddressQuery` to specify an address query.
  - `CategoryQuery` to specify a query by categories.
  - `Contact` that represents the contact information.
  - `IdQuery` to specify an id query.
  - `OpeningHours` to represent the information on opening hours.
  - `Place` to represent a location object, such as a country, a city, a point of interest(POI) etc.
  - `PlaceCategory` to define a set of most commonly used categories.
  - `ScheduleDetails` to encapsulate schedule details complying with the iCalendar specification.
  - `Suggestion` to represent a suggestion of an address or a place based on a query.
  - `TextQuery` option to specify a text query.
- Added the following methods to `SearchEngine`:
  - `search(query: IdQuery, callback: IdSearchCallback)` to search for a place based on its ID.
  - `search(query: CategoryQuery, callback: SearchCallback)` to search for places based on a list of categories.
- Added the structure `Details` to the `Place` object. It contains following fields:
  - `categories` for the list of categories assigned to the place.
  - `contacts` for the contact list of the place.
  - `openingHours` for the list of information on the opening hours of the place.
- Added the constructor `SDKOptions(@NonNull  String accessKeyId, @NonNull  String accessKeySecret, @NonNull  String cachePath, @NonNull  AuthenticationPreferences authenticationPreferences)` to `SDKOptions` to use the local system time for authentication instead of getting it from the server.

#### API Changes

- Changed type of `GeoCoordinates.altitude` from `float` to `double`.
- Changed type of `MapPolyline()` constructor from `float` to `double` for the `widthInPixels` parameter.
- Changed type of `MapView.pickMapItems()` from `float` to `double` for the `radius` parameter.
- Changed the return type of `Route.getDurationInSeconds()` from `long` to `int`.
- Changed the return type of `Route.getTrafficDelayInSeconds()` from `long` to `int`.
- Changed the return type of `Section.getDurationInSeconds()` from `long` to `int`.
- Changed the return type of `Section.getTrafficDelayInSeconds()` from `long` to `int`.
- Changed the return type of `SectionProgress.remainingDurationInSeconds` from `long` to `int`.
- Changed the return type of `SectionProgress.trafficDelayInSeconds` from `long` to `int`.
- Changed the method in the `PanListener` from `void onPan(@NonNull  GestureState state, @NonNull  Point2D origin, @NonNull  Point2D translation,  float velocity)` to `void onPan(@NonNull  GestureState state, @NonNull  Point2D origin, @NonNull  Point2D translation,  double velocity)`.
- Changed the method in the `PinchRotateListener` from `void onPinchRotate(@NonNull  GestureState state, @NonNull  Point2D pinchOrigin, @NonNull  Point2D rotationOrigin,  float twoFingerDistance, @NonNull  Angle rotation)` to `void onPinchRotate(@NonNull  GestureState state, @NonNull  Point2D pinchOrigin, @NonNull  Point2D rotationOrigin,  double twoFingerDistance, @NonNull  Angle rotation)`.
- Changed the method in the `TwoFingerPanListener` from `void onTwoFingerPan(@NonNull  GestureState state, @NonNull  Point2D origin, @NonNull  Point2D translation,  float velocity)` to `void onTwoFingerPan(@NonNull  GestureState state, @NonNull  Point2D origin, @NonNull  Point2D translation,  float velocity)`.
- Removed the `MapCamera.OrientationUpdate.roll` field.
- Removed the `MapCamera.OrientationUpdate(@Nullable  Double bearing, @Nullable  Double tilt, @Nullable  Double roll)` constructor.
- Removed the `MapMatchedWaypoint` class.
- Removed the `RouteRestrictions` class.
- Removed the `SideOfStreet` enumeration.
- Removed the `Route.getMapMatchedWaypoints()` method.
- Removed the interface `Searchable`.
- Replaced `Suggestion.getSearchable` with `Suggestion.getPlace`.
- Removed the method `SearchOptions(@Nullable Integer maxItems)`.
  - Use `SearchOptions()` instead, as the `languageCode` and `maxItems` are set to null with this constructor.
- Removed the `AutosuggestEngine`, `GeocodingEngine`, and `ReverseGeocodingEngine`. Their functionalities are now integrated into the `SearchEngine` class:
  - Use `SearchEngine.search(TextQuery, SearchOptions, SearchCallback)` to search for `Place` results.
  - Use `SearchEngine.search(AddressQuery, SearchOptions, SearchCallback)` to geocode an address to a geographic coordinate. Now, geocoding is limited to `GeoCoordinates`. `GeoBox` and `GeoCircle` are dropped.
  - Use `SearchEngine.search(GeoCoordinates, SearchOptions, SearchCallback)` to reverse geocode a geographic coordinate to an address.
  - Use `SearchEngine.search(CategoryQuery, SearchOptions, SearchCallback)` to search for `Place` results based on a list of categories.
  - Use `SearchEngine.suggest(TextQuery, SearchOptions, SuggestCallback)` to search for auto suggested `Place` results.
- Replaced `SearchCategory` with `SearchEngine.search(CategoryQuery, Options, SearchCallback)`.
- Replaced the `CategoryId` class with the `PlaceCategory` class.
- Replaced the `SearchResult` class with the `Place` class.
- Replaced the `SearchEngine.Callback`, `GeocodingEngine.Callback`, and the `ReverseGeocodingEngine.Callback` by the `SearchCallback` class.
- Replaced the `AutosuggestEngine.Callback` with the `SuggestCallback` class.
- Removed the following classes and their functionalities:
  - `AutosuggestResultType`
  - `GeocodingResult`
- Removed the `AutosuggestResult` class. Its functionalities have now been moved to the `Suggestion` class.
- Removed the field `textformat` from the `SearchOptions` class.
- Removed the function `SearchOptions.getDefaultOptions()`.
- Removed the following constructors from the `SearchEngine`:
  - `SearchEngine(SearchOptions defaultOptions)`.
  - `SearchEngine(SDKNativeEngine engine, SearchOptions defaultOptions)`.
- Removed the `BicycleOptions` from the transport mode options for route calculation.
- `OptimizationMode.SHORTEST` is no longer supported and now automatically converted to `OptimizationMode.FASTEST` for the transport mode option `TransportMode.PEDESTRIAN`.

#### Deprecated

- Deprecated the `GeoCoordinates(double latitude, double longitude, float altitude)` constructor. Use the `GeoCoordinates(double latitude, double longitude, double altitude)` constructor instead.
- Deprecated the `GeoCircle()` constructor that accepts type `float` for the `radius` parameter. Use the `GeoCircle()` constructor that accepts type `double` for the `radius` parameter instead.
- Deprecated the `Anchor2D()` constructor that accepts type `float` for the horizontal and vertical parameters. Use the `Anchor2D()` constructor that accepts type `double` for the  horizontal and vertical parameters instead.

#### Resolved Issues

- Fixed: Engines will not operate when the time of the device is incorrect. Now, the timestamp of the device is authenticated to enable the engines to operate.
- Fixed: Map marker images may flicker when removing or adding new markers. <!-- IOTSDK-4079 -->
- Fixed: A green or black screen may appear for a few milliseconds when loading a map view. <!-- IOTSDK-4321 -->
- Fixed: Map polylines may disappear when zooming out too far. <!-- IOTSDK-4060 -->
- Fixed: Loading a map scene may be slower for debug builds on devices and simulators. <!-- IOTSDK-4839 -->

#### Known Issues

- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- `SearchEngine`: `Place.getId()` is empty for reverse geocoding results. <!-- IOTSDK-5408 -->
- `AvoidanceOptions` will be ignored when calculating truck routes. <!-- IOTSDK-5336 -->
- Transparency for `MapPolylines` is not supported. <!--- IOTSDK-5364 -->

### Version 4.2.2.0

#### New Features

- Added new built in map schemes: `MapScheme.GREY_DAY` and `MapScheme.GREY_NIGHT` to be used with the `MapScene.loadScene()` function.
- Added two new layer names: `TRAFFIC_FLOW` and `TRAFFIC_INCIDENTS` to the `MapScene.Layers` struct to be used for switching on/off traffic flow and incidents with the `MapScene.setLayerState()` function.
- Added SVG support with `MapImage(@NonNull  String filePath,  long width,  long height)` constructor that supports _SVG Tiny images_.
- Added `MapImage MapImageFactory.fromFile(String filePath, int width, int height)` factory method for creating map images from _SVG Tiny map images_.

#### API Changes

- Removed the deprecated field `OrientationUpdate.azimuth`. Use `OrientationUpdate.bearing` instead.

#### Resolved Issues

- Fixed: Map objects still appear on the wrong map scene after they have been removed. <!-- IOTSDK-4541 -->
- Fixed: Adding or moving a map marker is now done instantly, without a fade in delay. <!-- IOTSDK-4807  -->

#### Known Issues

- Engines will not operate when the device's time is wrong. Also, the map will not be able to show any (vector) tiles. <!-- IOTSDK-2966 -->
- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- Map marker images may flicker when removing or adding new markers. <!-- IOTSDK-4079 -->
- A green or black screen may appear for a few milliseconds when loading a map view. <!-- IOTSDK-4321 -->
- Map polylines may disappear when zooming out too far. <!-- IOTSDK-4060 -->
- Loading a map scene may be slower for debug builds on devices and simulators. <!-- IOTSDK-4839 -->
- Custom map styles will no longer work until converted with a new editor that is not yet released.
<!-- IOTSDK-4564, we wait for new MapLab tool to support Harp 0.11 or higher. -->

### Version 4.2.1.0

#### New Features

- Added `MapCamera.State` to access full information about the camera's state.
- Added `MapPolyline.updateGeometry(@NonNull  GeoPolyline geometry)` to update the polyline shape.
- Added `MapScene.setLayerState(String layerName, LayerState state)` to identify the layer names which are passed to `setLayerState()`.
- Added class `MapCameraObserver` to get updates whenever the map is redrawn after camera parameters change.
- Added methods `MapCamera.addObserver(@NonNull  MapCameraObserver observer)` and `MapCamera.removeObserver(@NonNull  MapCameraObserver observer)` to add and remove an observer to the camera.
- Added `Authentication` API to obtain a valid token that can be used to initiate queries to HERE REST APIs.

#### API Changes

- Replaced enum type `RoadType.STREET` with `RoadType.RURAL` and `RoadType.URBAN`.
- Changed the return annotation for the method `MapView.viewToGeoCoordinates` to `Nullable`.

#### Deprecated

- The field `MapCamera.OrientationUpdate.azimuth` is deprecated. Use the newly introduced `MapCamera.OrientationUpdate.bearing` instead.
- The field `MapCamera.OrientationUpdate.roll` is now deprecated.

#### Resolved Issues

- Fixed: When the map is tilted, map polylines may look incorrect. <!-- IOTSDK-4410 -->

#### Known Issues

- Engines will not operate when the device's time is wrong. Also, the map will not be able to show any (vector) tiles. <!-- IOTSDK-2966 -->
- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- Map marker images may flicker when removing or adding new markers. <!-- IOTSDK-4079 -->
- When loading a map view a green or black screen may appear for a few milliseconds. <!-- IOTSDK-4321 -->
- Map polylines may disappear when zooming out too far. <!-- IOTSDK-4060 -->

### Version 4.2.0.0

#### Highlights

- This is the initial release.

#### Known Issues

- Engines will not operate when the device's time is wrong. Also, the map will not be able to show any (vector) tiles. <!-- IOTSDK-2966 -->
- Map caching may not work as expected for satellite map scheme. Existing tiles may be reloaded. <!-- IOTSDK-4381 -->
- Map marker images may flicker when removing or adding new markers. <!-- IOTSDK-4079 -->
- When loading a map view a green or black screen may appear for a few milliseconds. <!-- IOTSDK-4321 -->
- Map polylines may disappear when zooming out too far. <!-- IOTSDK-4060 -->
- When the map is tilted, map polylines may look incorrect. <!-- IOTSDK-4410 -->
